from management.proactive_scanner import ProactiveScanner
from management.revenue_engine import RevenueEngine
from management.experiment_engine import ExperimentEngine
from management.outreach_queue import OutreachQueue
from database.db import InMemoryStore
from orchestrator import HamedOrchestrator
from agents.base_agent import BaseAgent, AgentResult


class DummyResearchAgent(BaseAgent):
    name = "research_agent"
    capabilities = ["research.find_opportunities"]

    def handle(self, task):
        return AgentResult(agent_name=self.name, success=True, data={
            "results": [{"name": "opportunity 1"}, {"name": "opportunity 2"}],
        })


class DummyHunterAgent(BaseAgent):
    name = "facebook_agent"
    capabilities = ["social.facebook.find_candidates"]

    def handle(self, task):
        return AgentResult(agent_name=self.name, success=True, data={
            "candidates": [{"name": "lead 1"}],
        })


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = "REASON: interested\nMESSAGE: hi there!"
        return R()


class FakeColdOutreachHunter:
    """Avoids depending on the real hunting_pipeline module's LLM calls for this test file."""
    def __init__(self, orchestrator, outreach_queue):
        self.orchestrator = orchestrator
        self.outreach_queue = outreach_queue

    def hunt(self, platform, token, offer_context):
        find_result = self.orchestrator.run({"action": f"social.{platform}.find_candidates", "access_token": token})
        if not find_result.success:
            return []
        queued = []
        for candidate in find_result.data.get("candidates", []):
            item = self.outreach_queue.add(platform, candidate, "hi there!", reasoning="interested")
            queued.append(item)
        return queued


def _build_scanner(with_research=True, with_hunter=True):
    agents = []
    if with_research:
        agents.append(DummyResearchAgent(None))
    if with_hunter:
        agents.append(DummyHunterAgent(None))
    orch = HamedOrchestrator(agents)

    store = InMemoryStore()
    revenue_engine = RevenueEngine(store, daily_goal=1000.0)
    experiment_engine = ExperimentEngine(store)
    outreach_queue = OutreachQueue()
    hunter = FakeColdOutreachHunter(orch, outreach_queue)

    scanner = ProactiveScanner(orch, hunter, revenue_engine, experiment_engine, outreach_queue)
    return scanner, revenue_engine, experiment_engine, outreach_queue


def test_scan_reports_revenue_pace_behind():
    scanner, revenue_engine, _, _ = _build_scanner()
    report = scanner.scan(offer_context={}, platform_tokens={})
    assert report["revenue"]["flag"] == "behind_pace"  # 0 revenue vs 1000 goal


def test_scan_reports_revenue_on_track():
    scanner, revenue_engine, _, _ = _build_scanner()
    revenue_engine.record("product_sale", 600)  # 60% of 1000 goal
    report = scanner.scan(offer_context={}, platform_tokens={})
    assert report["revenue"]["flag"] == "on_track"


def test_scan_surfaces_actionable_experiment_decisions_only():
    scanner, _, experiment_engine, _ = _build_scanner()
    experiment_engine.log_metrics("good_channel", {"sample_size": 100, "conversion_rate": 0.05, "margin": 0.3})
    experiment_engine.log_metrics("new_channel", {"sample_size": 2, "conversion_rate": 0.05, "margin": 0.3})

    report = scanner.scan(offer_context={}, platform_tokens={})
    names = [d["experiment"] for d in report["experiments"]]
    assert "good_channel" in names       # scale decision - actionable
    assert "new_channel" not in names    # keep_running - not actionable, filtered out


def test_scan_finds_research_opportunities_when_query_given():
    scanner, _, _, _ = _build_scanner()
    report = scanner.scan(offer_context={}, platform_tokens={}, research_query="handmade candles Egypt")
    assert len(report["research_opportunities"]) == 2


def test_scan_skips_research_when_no_query():
    scanner, _, _, _ = _build_scanner()
    report = scanner.scan(offer_context={}, platform_tokens={})
    assert report["research_opportunities"] == []


def test_scan_hunts_across_all_configured_platforms():
    scanner, _, _, outreach_queue = _build_scanner()
    report = scanner.scan(offer_context={"description": "we sell candles"}, platform_tokens={"facebook": "tok123"})
    assert report["new_cold_candidates"] == 1
    assert len(outreach_queue.list_pending()) == 1


def test_scan_with_no_platform_tokens_finds_nothing_new():
    scanner, _, _, outreach_queue = _build_scanner()
    report = scanner.scan(offer_context={}, platform_tokens={})
    assert report["new_cold_candidates"] == 0
    assert outreach_queue.list_pending() == []


def test_scan_handles_hunting_failure_on_one_platform_without_crashing():
    scanner, _, _, _ = _build_scanner(with_hunter=False)  # no facebook_agent registered
    report = scanner.scan(offer_context={}, platform_tokens={"facebook": "tok"})
    assert report["new_cold_candidates"] == 0  # hunt() call fails gracefully, logged, not raised


def test_format_summary_produces_readable_text():
    scanner, revenue_engine, experiment_engine, _ = _build_scanner()
    revenue_engine.record("product_sale", 100)
    report = scanner.scan(offer_context={}, platform_tokens={})
    summary = scanner.format_summary(report)
    assert "تقرير المسح الاستباقي" in summary
    assert "الإيراد" in summary
