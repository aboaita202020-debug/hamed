from management.sheets_sync import SheetsSync
from database.db import InMemoryStore
from agents.payment_agent import PaymentAgent
from agents.registry import build_agents, AGENT_CLASSES


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = "x"
        return R()


class FakeSheetsClient:
    """Records what would have been sent to Google Sheets, without any network call."""
    def __init__(self):
        self.synced = {}  # worksheet_name -> records

    def sync_table(self, worksheet_name, records):
        self.synced[worksheet_name] = records
        return len(records)


class FailingSheetsClient:
    def sync_table(self, worksheet_name, records):
        raise RuntimeError("simulated Google API failure")


def test_sheets_sync_pulls_from_store_and_pushes_to_client():
    store = InMemoryStore()
    store.insert("leads", {"name": "ahmed", "budget": 100})
    store.insert("leads", {"name": "sara", "budget": 200})
    store.insert("revenue", {"source": "product_sale", "amount": 50})

    client = FakeSheetsClient()
    sync = SheetsSync(store, client)
    results = sync.sync_all(tables=["leads", "revenue", "deals"])

    assert results["leads"] == 2
    assert results["revenue"] == 1
    assert results["deals"] == 0  # empty table, sync_table never called for it (no records)
    assert len(client.synced["leads"]) == 2


def test_sheets_sync_raises_clear_error_when_not_configured():
    store = InMemoryStore()
    sync = SheetsSync(store, None)
    try:
        sync.sync_all()
        assert False, "should have raised"
    except RuntimeError as e:
        assert "not configured" in str(e)


def test_sheets_sync_reports_failure_without_crashing_other_tables():
    store = InMemoryStore()
    store.insert("leads", {"name": "x"})
    store.insert("revenue", {"amount": 10})

    client = FailingSheetsClient()
    sync = SheetsSync(store, client)
    results = sync.sync_all(tables=["leads", "revenue"])

    assert results["leads"] == -1
    assert results["revenue"] == -1


def test_payment_agent_logs_claims_to_store_when_provided():
    store = InMemoryStore()
    agent = PaymentAgent(FakeMultiBrain(), vodafone_cash_number="0100", store=store)

    created = agent.handle({"action": "payment.create_claim", "amount": 150, "customer_ref": "mona"})
    claim_id = created.data["claim_id"]
    agent.handle({"action": "payment.confirm", "claim_id": claim_id})

    logged = store.all("payments")
    # One row logged at creation, one at confirmation - both should be present.
    assert len(logged) == 2
    assert logged[0]["status"] == "awaiting_confirmation"
    assert logged[1]["status"] == "confirmed"


def test_payment_agent_works_fine_without_a_store():
    agent = PaymentAgent(FakeMultiBrain(), vodafone_cash_number="0100", store=None)
    result = agent.handle({"action": "payment.create_claim", "amount": 100, "customer_ref": "x"})
    assert result.success  # should not crash just because store is None


def test_registry_passes_store_into_payment_agent():
    store = InMemoryStore()
    agents = build_agents(FakeMultiBrain(), store=store)
    payment_agent = next(a for a in agents if a.name == "payment_agent")
    assert payment_agent.store is store
    assert len(agents) == len(AGENT_CLASSES)
