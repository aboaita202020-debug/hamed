from agents.customer_psychology_agent import CustomerPsychologyAgent
from agents.lead_generation_agent import LeadGenerationAgent
from agents.upsell_agent import UpsellAgent
from agents.websiteless_business_agent import WebsitelessBusinessAgent
from agents.registry import build_agents, AGENT_CLASSES
from orchestrator import HamedOrchestrator
from management.board import HamedBoard
from management.revenue_engine import RevenueEngine
from database.db import InMemoryStore


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = f"stub: {prompt[:15]}"
        return R()


def test_psychology_agent_analyzes_objection():
    agent = CustomerPsychologyAgent(FakeMultiBrain())
    result = agent.handle({"action": "psychology.analyze_objection_reason", "conversation": "too expensive"})
    assert result.success
    assert "analysis" in result.data


def test_leadgen_matches_buyer_to_seller_by_category_and_budget():
    agent = LeadGenerationAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "leadgen.find_buyers_for_seller",
        "product": {"category": "electronics", "price": 50},
        "candidate_buyers": [
            {"name": "match", "needs": {"category": "electronics", "max_budget": 100}},
            {"name": "no_match_category", "needs": {"category": "clothing", "max_budget": 100}},
            {"name": "no_match_budget", "needs": {"category": "electronics", "max_budget": 10}},
        ],
    })
    names = [m["name"] for m in result.data["matches"]]
    assert names == ["match"]


def test_upsell_agent_suggests_complementary_bundle():
    agent = UpsellAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "upsell.suggest_bundle",
        "cart": [{"name": "phone", "category": "electronics"}],
        "catalog": [
            {"name": "case", "complements_category": "electronics"},
            {"name": "shirt", "complements_category": "clothing"},
        ],
    })
    names = [p["name"] for p in result.data["bundle_suggestions"]]
    assert names == ["case"]


def test_websiteless_agent_generates_landing_copy():
    agent = WebsitelessBusinessAgent(FakeMultiBrain())
    result = agent.handle({"action": "website.generate_landing_copy", "business": {"name": "test shop"}})
    assert result.success
    assert "landing_copy" in result.data


def test_registry_now_includes_all_new_agents_without_collisions():
    agents = build_agents(FakeMultiBrain())
    assert len(agents) == len(AGENT_CLASSES)
    all_capabilities = [cap for agent in agents for cap in agent.capabilities]
    assert len(all_capabilities) == len(set(all_capabilities))


def test_board_runs_new_deal_pipeline_end_to_end_and_stops_on_qualify_failure():
    agents = build_agents(FakeMultiBrain())
    orch = HamedOrchestrator(agents)
    board = HamedBoard(orch)

    report = board.run_goal("new_deal_pipeline", {
        "candidates": [{"name": "hot", "expressed_interest": True, "budget": 200}],
        "product": {"name": "widget", "price": 150},
        "message": "hi, interested?",
        "min_acceptable_price": 100,
        "customer_offer": 120,
        "max_autonomous_amount": 1000,
    })
    assert len(report.steps) == 5
    assert report.all_succeeded


def test_board_unknown_goal_returns_failed_report():
    agents = build_agents(FakeMultiBrain())
    orch = HamedOrchestrator(agents)
    board = HamedBoard(orch)
    report = board.run_goal("does_not_exist", {})
    assert not report.all_succeeded


def test_revenue_engine_tracks_progress_toward_daily_goal():
    store = InMemoryStore()
    engine = RevenueEngine(store, daily_goal=1000.0, currency="USD")
    engine.record("product_sale", 300)
    engine.record("affiliate_commission", 50)

    report = engine.progress_report()
    assert report["today_total"] == 350
    assert report["remaining"] == 650
    assert report["by_source"]["product_sale"] == 300
    assert report["by_source"]["affiliate_commission"] == 50
