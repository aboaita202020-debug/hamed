from agents.sales_agent import SalesAgent, SALES_PERSONA
from agents.registry import build_agents, AGENT_CLASSES


class RecordingBrain:
    """Records every prompt sent to it so tests can assert on prompt content
    without depending on real LLM output."""
    def __init__(self):
        self.prompts = []

    def ask(self, prompt):
        self.prompts.append(prompt)
        class R:
            text = "stub reply"
        return R()


def test_all_six_capabilities_are_actually_handled_not_just_declared():
    """Regression test for the bug where sales.greet/sales.followup were
    advertised in `capabilities` but fell through to 'Unknown action'."""
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    for action in agent.capabilities:
        result = agent.handle({"action": action, "message": "test", "amount": 10})
        assert result.success or result.requires_approval, f"{action} returned an unhandled failure"


def test_greet_asks_a_question_and_does_not_pitch():
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    agent.handle({"action": "sales.greet", "message": "عايز اعرف عندكم إيه"})
    prompt = brain.prompts[-1]
    assert "don't pitch anything yet" in prompt
    assert SALES_PERSONA in prompt


def test_discover_needs_includes_customer_profile_when_given():
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    agent.handle({
        "action": "sales.discover_needs", "message": "محتاج مساعدة",
        "customer_profile": "price-sensitive, prefers short replies",
    })
    prompt = brain.prompts[-1]
    assert "price-sensitive" in prompt


def test_discover_needs_works_without_customer_profile():
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    result = agent.handle({"action": "sales.discover_needs", "message": "محتاج مساعدة"})
    assert result.success  # should not crash just because profile is missing


def test_present_offer_returns_price_and_uses_persona():
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    result = agent.handle({
        "action": "sales.present_offer", "message": "عايز باقة محتوى",
        "product": {"name": "Content Package", "price": 300},
    })
    assert result.data["price"] == 300
    assert SALES_PERSONA in brain.prompts[-1]


def test_handle_objection_prompt_covers_all_categories():
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    agent.handle({"action": "sales.handle_objection", "message": "غالي عليا"})
    prompt = brain.prompts[-1]
    for category in ["price/value", "trust", "timing", "unclear need", "approval"]:
        assert category in prompt


def test_close_deal_unchanged_behavior_within_limit():
    agent = SalesAgent(RecordingBrain())
    result = agent.handle({"action": "sales.close_deal", "amount": 50, "max_autonomous_amount": 100})
    assert result.success and not result.requires_approval


def test_close_deal_unchanged_behavior_over_limit():
    agent = SalesAgent(RecordingBrain())
    result = agent.handle({"action": "sales.close_deal", "amount": 500, "max_autonomous_amount": 100})
    assert result.requires_approval and not result.success


def test_followup_uses_days_since_contact():
    brain = RecordingBrain()
    agent = SalesAgent(brain)
    agent.handle({"action": "sales.followup", "message": "هرد بعدين", "days_since_contact": 5})
    prompt = brain.prompts[-1]
    assert "5 days" in prompt
    assert "just checking in" in prompt  # instructs the model to avoid this generic phrase


def test_unknown_action_still_fails_cleanly():
    agent = SalesAgent(RecordingBrain())
    result = agent.handle({"action": "sales.not_a_real_action"})
    assert not result.success
    assert "Unknown action" in result.notes


def test_registry_still_builds_sales_agent_correctly():
    class FakeBrain:
        def ask(self, p):
            class R:
                text = "x"
            return R()
    agents = build_agents(FakeBrain())
    sales_agent = next(a for a in agents if a.name == "sales_agent")
    assert len(sales_agent.capabilities) == 6
    assert len(agents) == len(AGENT_CLASSES)
