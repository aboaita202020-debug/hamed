from channels.voice_channel import VoiceChannel, MAX_TURNS_PER_CALL


class FakeTwilioClient:
    """Stands in for twilio.rest.Client so tests never hit the network."""
    def __init__(self, *a, **k):
        self.calls = FakeCallsResource()


class FakeCallsResource:
    def __init__(self):
        self.created = []

    def create(self, to, from_, url):
        self.created.append({"to": to, "from_": from_, "url": url})
        return {"sid": "CA123"}


class FakeOrchestrator:
    def __init__(self, reply="fallback reply"):
        self.reply = reply

    def run(self, task):
        from agents.base_agent import AgentResult
        return AgentResult(agent_name="sales_agent", success=True, data={"reply": self.reply})


class FakeDecisionEngine:
    """Returns a canned trace so voice_channel logic can be tested without an LLM."""
    def __init__(self, reply="decision engine reply", requires_approval=False):
        self.reply = reply
        self.requires_approval = requires_approval

    def run(self, goal, context, max_steps=3):
        from management.decision_engine import DecisionTrace, DecisionStep
        from agents.base_agent import AgentResult

        trace = DecisionTrace(goal=goal)
        if self.requires_approval:
            result = AgentResult(agent_name="sales_agent", success=False, requires_approval=True, data={})
        else:
            result = AgentResult(agent_name="sales_agent", success=True, data={"reply": self.reply})
        trace.steps.append(DecisionStep(reasoning="test", action="sales.something", params={}, result=result))
        return trace


class FakeSelfReflection:
    def __init__(self):
        self.called_with = None

    def reflect(self, trace):
        self.called_with = trace
        return {}


def _make_channel(**kwargs):
    """Builds a VoiceChannel without touching the real twilio SDK."""
    channel = VoiceChannel.__new__(VoiceChannel)  # bypass __init__'s twilio.rest import
    channel.client = FakeTwilioClient()
    channel.from_number = "+15550001111"
    channel.orchestrator = kwargs.get("orchestrator", FakeOrchestrator())
    channel.decision_engine = kwargs.get("decision_engine")
    channel.self_reflection = kwargs.get("self_reflection")
    return channel


def test_initial_twiml_includes_greeting_and_gather():
    channel = _make_channel()
    twiml = channel.initial_twiml("أهلاً")
    assert "أهلاً" in twiml
    assert '<Gather input="speech"' in twiml
    assert 'action="/voice/handle_speech"' in twiml


def test_handle_speech_uses_fallback_orchestrator_without_decision_engine():
    channel = _make_channel(orchestrator=FakeOrchestrator(reply="hello from fallback"))
    twiml = channel.handle_speech_result("مرحبا")
    assert "hello from fallback" in twiml


def test_handle_speech_uses_decision_engine_when_wired():
    channel = _make_channel(decision_engine=FakeDecisionEngine(reply="smart reply"))
    twiml = channel.handle_speech_result("عايز اعرف السعر")
    assert "smart reply" in twiml


def test_handle_speech_reports_approval_needed():
    channel = _make_channel(decision_engine=FakeDecisionEngine(requires_approval=True))
    twiml = channel.handle_speech_result("عايز اشتري بكميه كبيره")
    assert "موافقة" in twiml


def test_handle_speech_calls_self_reflection_after_decision_engine_reply():
    reflection = FakeSelfReflection()
    channel = _make_channel(decision_engine=FakeDecisionEngine(reply="ok"), self_reflection=reflection)
    channel.handle_speech_result("test")
    assert reflection.called_with is not None


def test_handle_speech_empty_input_reprompts_instead_of_crashing():
    channel = _make_channel()
    twiml = channel.handle_speech_result("")
    assert "مسمعتش" in twiml
    assert '<Gather input="speech"' in twiml  # still gives the caller another chance


def test_handle_speech_hangs_up_after_max_turns():
    channel = _make_channel()
    twiml = channel.handle_speech_result("hello", turn_count=MAX_TURNS_PER_CALL)
    assert "<Hangup/>" in twiml
    assert '<Gather' not in twiml  # call actually ends, no more prompting


def test_reprompt_increments_turn_counter_in_next_action_url():
    channel = _make_channel()
    twiml = channel.handle_speech_result("hi", turn_count=2)
    assert "turn=3" in twiml


def test_place_call_uses_from_number_and_full_url():
    channel = _make_channel()
    channel.place_call("+201000000000", "https://example.onrender.com/voice/incoming")
    created = channel.client.calls.created[0]
    assert created["to"] == "+201000000000"
    assert created["from_"] == "+15550001111"
    assert created["url"] == "https://example.onrender.com/voice/incoming"
