from channels.whatsapp_channel import WhatsAppChannel


class FakeTwilioClient:
    def __init__(self, *a, **k):
        self.messages = FakeMessagesResource()


class FakeMessagesResource:
    def __init__(self):
        self.created = []

    def create(self, from_, to, body):
        self.created.append({"from_": from_, "to": to, "body": body})
        return {"sid": "SM123"}


class FakeOrchestrator:
    def __init__(self, success=True, requires_approval=False, reply="fallback reply", notes=""):
        self.success = success
        self.requires_approval = requires_approval
        self.reply = reply
        self.notes = notes

    def run(self, task):
        from agents.base_agent import AgentResult
        return AgentResult(
            agent_name="sales_agent", success=self.success, requires_approval=self.requires_approval,
            data={"reply": self.reply} if self.success else {}, notes=self.notes,
        )


class FakeDecisionEngine:
    def __init__(self, reply="decision engine reply", requires_approval=False, no_result=False):
        self.reply = reply
        self.requires_approval = requires_approval
        self.no_result = no_result

    def run(self, goal, context, max_steps=4):
        from management.decision_engine import DecisionTrace, DecisionStep
        from agents.base_agent import AgentResult

        trace = DecisionTrace(goal=goal)
        if self.no_result:
            return trace  # no steps at all - simulates "couldn't decide anything"
        if self.requires_approval:
            result = AgentResult(agent_name="sales_agent", success=False, requires_approval=True, data={})
        else:
            result = AgentResult(agent_name="sales_agent", success=True, data={"reply": self.reply})
        trace.steps.append(DecisionStep(reasoning="test", action="sales.something", params={}, result=result))
        return trace


class FakeSelfReflection:
    def __init__(self):
        self.called = False

    def reflect(self, trace):
        self.called = True
        return {}


def _make_channel(**kwargs):
    channel = WhatsAppChannel.__new__(WhatsAppChannel)  # bypass __init__'s twilio.rest import
    channel.client = FakeTwilioClient()
    channel.from_number = "+15550001111"
    channel.orchestrator = kwargs.get("orchestrator", FakeOrchestrator())
    channel.decision_engine = kwargs.get("decision_engine")
    channel.self_reflection = kwargs.get("self_reflection")
    return channel


def test_handle_incoming_uses_fallback_without_decision_engine():
    channel = _make_channel(orchestrator=FakeOrchestrator(reply="hello from fallback"))
    reply = channel.handle_incoming("+201000000000", "hi")
    assert reply == "hello from fallback"


def test_handle_incoming_uses_decision_engine_when_wired():
    channel = _make_channel(decision_engine=FakeDecisionEngine(reply="smart whatsapp reply"))
    reply = channel.handle_incoming("+201000000000", "عايز اعرف السعر")
    assert reply == "smart whatsapp reply"


def test_handle_incoming_reports_approval_needed():
    channel = _make_channel(decision_engine=FakeDecisionEngine(requires_approval=True))
    reply = channel.handle_incoming("+201000000000", "عايز اشتري بكميه كبيره")
    assert "موافقتي" in reply


def test_handle_incoming_falls_back_when_decision_engine_finds_nothing():
    channel = _make_channel(
        decision_engine=FakeDecisionEngine(no_result=True),
        orchestrator=FakeOrchestrator(reply="fixed fallback"),
    )
    reply = channel.handle_incoming("+201000000000", "test")
    assert reply == "fixed fallback"


def test_handle_incoming_calls_self_reflection():
    reflection = FakeSelfReflection()
    channel = _make_channel(decision_engine=FakeDecisionEngine(reply="ok"), self_reflection=reflection)
    channel.handle_incoming("+201000000000", "test")
    assert reflection.called


def test_handle_incoming_no_decision_engine_reports_orchestrator_failure_notes():
    channel = _make_channel(orchestrator=FakeOrchestrator(success=False, notes="something broke"))
    reply = channel.handle_incoming("+201000000000", "test")
    assert "something broke" in reply


def test_send_message_uses_whatsapp_prefixed_numbers():
    channel = _make_channel()
    channel.send_message("+201000000000", "hello!")
    created = channel.client.messages.created[0]
    assert created["from_"] == "whatsapp:+15550001111"
    assert created["to"] == "whatsapp:+201000000000"
    assert created["body"] == "hello!"
