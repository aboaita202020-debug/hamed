from agents.video_content_agent import VideoContentAgent
from agents.registry import build_agents, AGENT_CLASSES
from integrations.heygen_client import build_heygen_client, HeyGenClient


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = "STUB SCRIPT"
        return R()


class FakeHeyGenClientSuccess:
    def generate_video(self, script, avatar_id, voice_id):
        return {"status": "completed", "video_url": "https://videos.example.com/abc123.mp4"}


class FakeHeyGenClientFailure:
    def generate_video(self, script, avatar_id, voice_id):
        return {"status": "failed", "reason": "avatar not found"}


class FakeHeyGenClientRaises:
    def generate_video(self, script, avatar_id, voice_id):
        raise RuntimeError("network error")


class FakeConfigNoHeygen:
    HEYGEN_API_KEY = None


class FakeConfigWithHeygen:
    HEYGEN_API_KEY = "hg_test_key"


def test_generate_ugc_video_free_manual_path_without_heygen():
    agent = VideoContentAgent(FakeMultiBrain(), heygen_client=None)
    result = agent.handle({"action": "video.generate_ugc_video", "product": {"name": "candle"}})
    assert result.success
    assert result.data["mode"] == "manual_free"
    assert "script" in result.data
    assert "heygen.com" in result.data["instructions"]


def test_generate_ugc_video_automated_path_on_success():
    agent = VideoContentAgent(FakeMultiBrain(), heygen_client=FakeHeyGenClientSuccess())
    result = agent.handle({"action": "video.generate_ugc_video", "product": {"name": "candle"}})
    assert result.success
    assert result.data["mode"] == "automated"
    assert result.data["video_url"] == "https://videos.example.com/abc123.mp4"


def test_generate_ugc_video_reports_failure_from_heygen():
    agent = VideoContentAgent(FakeMultiBrain(), heygen_client=FakeHeyGenClientFailure())
    result = agent.handle({"action": "video.generate_ugc_video", "product": {"name": "candle"}})
    assert not result.success
    assert "avatar not found" in result.notes
    assert "script" in result.data  # script is still returned even on failure


def test_generate_ugc_video_handles_client_exception_gracefully():
    agent = VideoContentAgent(FakeMultiBrain(), heygen_client=FakeHeyGenClientRaises())
    result = agent.handle({"action": "video.generate_ugc_video", "product": {"name": "candle"}})
    assert not result.success
    assert "network error" in result.notes


def test_existing_script_and_storyboard_actions_still_work():
    agent = VideoContentAgent(FakeMultiBrain())
    r1 = agent.handle({"action": "video.write_script", "product": {"name": "x"}})
    r2 = agent.handle({"action": "video.suggest_storyboard", "product": {"name": "x"}})
    assert r1.success and "script" in r1.data
    assert r2.success and "storyboard" in r2.data


def test_build_heygen_client_returns_none_when_not_configured():
    assert build_heygen_client(FakeConfigNoHeygen()) is None


def test_build_heygen_client_returns_client_when_configured():
    client = build_heygen_client(FakeConfigWithHeygen())
    assert isinstance(client, HeyGenClient)
    assert client.api_key == "hg_test_key"


def test_registry_wires_heygen_client_into_video_agent():
    fake_client = FakeHeyGenClientSuccess()
    agents = build_agents(FakeMultiBrain(), heygen_client=fake_client)
    video_agent = next(a for a in agents if a.name == "video_content_agent")
    assert video_agent.heygen_client is fake_client
    assert len(agents) == len(AGENT_CLASSES)


def test_registry_video_agent_works_without_heygen_client():
    agents = build_agents(FakeMultiBrain())
    video_agent = next(a for a in agents if a.name == "video_content_agent")
    assert video_agent.heygen_client is None
