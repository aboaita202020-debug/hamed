from agents.testimonials_agent import TestimonialsAgent
from agents.registry import build_agents, AGENT_CLASSES
from database.db import InMemoryStore


class FakeMultiBrain:
    def __init__(self, text="stub reply"):
        self.text = text

    def ask(self, prompt):
        class R:
            pass
        r = R()
        r.text = self.text
        return r


def test_request_feedback_asks_permission_explicitly():
    brain = FakeMultiBrain()
    agent = TestimonialsAgent(brain, store=InMemoryStore())
    agent.handle({"action": "testimonial.request_feedback", "context": "the content package"})
    # We can't inspect the prompt directly here (FakeMultiBrain doesn't record it),
    # but a dedicated persona test below checks that.


def test_record_requires_store():
    agent = TestimonialsAgent(FakeMultiBrain(), store=None)
    result = agent.handle({"action": "testimonial.record", "customer_ref": "x", "text": "great!"})
    assert not result.success


def test_record_requires_customer_ref_and_text():
    agent = TestimonialsAgent(FakeMultiBrain(), store=InMemoryStore())
    result = agent.handle({"action": "testimonial.record", "customer_ref": "", "text": ""})
    assert not result.success


def test_permission_defaults_to_false_not_assumed():
    store = InMemoryStore()
    agent = TestimonialsAgent(FakeMultiBrain(), store=store)
    result = agent.handle({"action": "testimonial.record", "customer_ref": "x", "text": "nice"})
    assert result.data["permission_granted"] is False


def test_unapproved_testimonial_excluded_from_list():
    store = InMemoryStore()
    agent = TestimonialsAgent(FakeMultiBrain(), store=store)
    agent.handle({"action": "testimonial.record", "customer_ref": "no_consent", "text": "good", "permission_granted": False})
    result = agent.handle({"action": "testimonial.list_approved"})
    assert result.data["testimonials"] == []


def test_approved_testimonial_included_in_list():
    store = InMemoryStore()
    agent = TestimonialsAgent(FakeMultiBrain(), store=store)
    agent.handle({"action": "testimonial.record", "customer_ref": "yes_consent", "text": "great service", "permission_granted": True})
    result = agent.handle({"action": "testimonial.list_approved"})
    assert len(result.data["testimonials"]) == 1
    assert result.data["testimonials"][0]["customer_ref"] == "yes_consent"


def test_list_approved_without_store_returns_empty_not_error():
    agent = TestimonialsAgent(FakeMultiBrain(), store=None)
    result = agent.handle({"action": "testimonial.list_approved"})
    assert result.success
    assert result.data["testimonials"] == []


def test_format_for_marketing_with_no_approved_testimonials_returns_none():
    agent = TestimonialsAgent(FakeMultiBrain(), store=InMemoryStore())
    result = agent.handle({"action": "testimonial.format_for_marketing"})
    assert result.success
    assert result.data["real_proof"] is None


def test_format_for_marketing_filters_by_business_context():
    store = InMemoryStore()
    agent = TestimonialsAgent(FakeMultiBrain(), store=store)
    agent.handle({
        "action": "testimonial.record", "customer_ref": "cafe_owner", "text": "loved it",
        "permission_granted": True, "business_context": "cafe",
    })
    agent.handle({
        "action": "testimonial.record", "customer_ref": "clinic_owner", "text": "very professional",
        "permission_granted": True, "business_context": "clinic",
    })

    result = agent.handle({"action": "testimonial.format_for_marketing", "business_context": "clinic"})
    assert "clinic_owner" in result.data["real_proof"]
    assert "very professional" in result.data["real_proof"]


def test_format_for_marketing_falls_back_to_most_recent_when_no_context_match():
    store = InMemoryStore()
    agent = TestimonialsAgent(FakeMultiBrain(), store=store)
    agent.handle({
        "action": "testimonial.record", "customer_ref": "someone", "text": "good stuff",
        "permission_granted": True, "business_context": "unrelated_niche",
    })
    result = agent.handle({"action": "testimonial.format_for_marketing", "business_context": "totally_different"})
    assert result.data["real_proof"] is not None  # falls back rather than returning nothing


def test_unknown_action_fails_cleanly():
    agent = TestimonialsAgent(FakeMultiBrain(), store=InMemoryStore())
    result = agent.handle({"action": "testimonial.not_real"})
    assert not result.success
    assert "Unknown action" in result.notes


def test_registry_wires_store_into_testimonials_agent():
    store = InMemoryStore()
    agents = build_agents(FakeMultiBrain(), store=store)
    testimonials_agent = next(a for a in agents if a.name == "testimonials_agent")
    assert testimonials_agent.store is store
    assert len(agents) == len(AGENT_CLASSES)


def test_registry_no_capability_collisions_after_adding_testimonials_agent():
    agents = build_agents(FakeMultiBrain())
    all_caps = [c for a in agents for c in a.capabilities]
    assert len(all_caps) == len(set(all_caps))
