from agents.sales_agent import SalesAgent
from agents.purchasing_agent import PurchasingAgent
from agents.negotiation_agent import NegotiationAgent
from agents.research_agent import ResearchAgent


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = f"[stub reply for]: {prompt[:20]}"
        return R()


def test_sales_agent_closes_deal_within_limit():
    agent = SalesAgent(FakeMultiBrain())
    result = agent.handle({"action": "sales.close_deal", "amount": 50, "max_autonomous_amount": 100})
    assert result.success
    assert not result.requires_approval


def test_sales_agent_requires_approval_above_limit():
    agent = SalesAgent(FakeMultiBrain())
    result = agent.handle({"action": "sales.close_deal", "amount": 500, "max_autonomous_amount": 100})
    assert result.requires_approval
    assert not result.success


def test_purchasing_agent_ranks_suppliers_by_total_cost():
    agent = PurchasingAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "purchasing.compare_suppliers",
        "suppliers": [
            {"name": "A", "price": 100, "shipping": 10, "fees": 5},
            {"name": "B", "price": 90, "shipping": 5, "fees": 5},
        ],
    })
    assert result.success
    assert result.data["best"]["name"] == "B"


def test_purchasing_agent_flags_high_risk_deal():
    agent = PurchasingAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "purchasing.evaluate_deal",
        "purchase_cost": 90, "shipping": 5, "fees": 5,
        "expected_sale_price": 100,
        "max_autonomous_amount": 1000,
    })
    assert result.data["risk"] == "high"
    assert result.data["decision"] == "reject"


def test_negotiation_agent_counters_low_offer():
    agent = NegotiationAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "negotiation.evaluate_offer",
        "asking_price": 100, "min_acceptable_price": 80, "offer": 60,
    })
    assert result.data["decision"] == "counter"
    assert result.data["counter_offer"] == 70


def test_research_agent_ranks_leads_by_value_times_probability():
    agent = ResearchAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "research.rank_leads",
        "leads": [
            {"name": "low", "estimated_value": 100, "close_probability": 0.1},
            {"name": "high", "estimated_value": 100, "close_probability": 0.9},
        ],
    })
    assert result.data["ranked_leads"][0]["name"] == "high"
