import importlib
import os
import sys

sys.path.insert(0, ".")


def _reload_config_with_env(**env_vars):
    """Reloads config.py with a controlled set of env vars, restoring the
    real environment afterward so tests don't leak state into each other."""
    keys_to_clear = [
        "TELEGRAM_BOT_TOKEN", "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
        "DEEPSEEK_API_KEY", "GEMINI_API_KEY", "GROQ_API_KEY", "KIMI_API_KEY",
    ]
    saved = {k: os.environ.get(k) for k in keys_to_clear}
    for k in keys_to_clear:
        os.environ.pop(k, None)
    os.environ.update(env_vars)

    import config as config_module
    importlib.reload(config_module)

    for k, v in saved.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v

    return config_module


def test_validate_fails_with_only_telegram_token_no_brain():
    config_module = _reload_config_with_env(TELEGRAM_BOT_TOKEN="test")
    assert config_module.config.validate() is False


def test_validate_passes_with_gemini_only_no_openai_needed():
    config_module = _reload_config_with_env(TELEGRAM_BOT_TOKEN="test", GEMINI_API_KEY="test")
    assert config_module.config.validate() is True


def test_validate_passes_with_groq_only_no_openai_needed():
    config_module = _reload_config_with_env(TELEGRAM_BOT_TOKEN="test", GROQ_API_KEY="test")
    assert config_module.config.validate() is True


def test_validate_still_fails_without_telegram_token_even_with_brain_key():
    config_module = _reload_config_with_env(GEMINI_API_KEY="test")
    assert config_module.config.validate() is False


def test_available_brains_lists_free_options_first():
    config_module = _reload_config_with_env(
        TELEGRAM_BOT_TOKEN="test", GEMINI_API_KEY="g", GROQ_API_KEY="q", OPENAI_API_KEY="o",
    )
    brains = config_module.config.available_brains()
    assert brains == ["gemini", "groq", "openai"]


def test_available_brains_empty_when_none_configured():
    config_module = _reload_config_with_env(TELEGRAM_BOT_TOKEN="test")
    assert config_module.config.available_brains() == []


# Restore the real config module state for any tests that run after this file.
import config  # noqa: E402
importlib.reload(config)
