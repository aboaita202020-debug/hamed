from agents.negotiation_agent import NegotiationAgent, NEGOTIATION_PERSONA
from agents.marketing_agent import MarketingAgent, MARKETING_PERSONA
from agents.purchasing_agent import PurchasingAgent, PURCHASING_PERSONA
from agents.registry import build_agents, AGENT_CLASSES


class RecordingBrain:
    def __init__(self):
        self.prompts = []

    def ask(self, prompt):
        self.prompts.append(prompt)
        class R:
            text = "stub reply"
        return R()


# ---------- NegotiationAgent ----------

def test_negotiation_counter_offer_proposes_a_trade_not_just_a_number():
    brain = RecordingBrain()
    agent = NegotiationAgent(brain)
    agent.handle({"action": "negotiation.counter_offer", "offer": 60, "min_acceptable_price": 80})
    prompt = brain.prompts[-1]
    assert NEGOTIATION_PERSONA in prompt
    assert "trade" in prompt.lower()


def test_negotiation_counter_offer_includes_customer_profile_when_given():
    brain = RecordingBrain()
    agent = NegotiationAgent(brain)
    agent.handle({
        "action": "negotiation.counter_offer", "offer": 60, "min_acceptable_price": 80,
        "customer_profile": "price-sensitive but loyal",
    })
    assert "price-sensitive but loyal" in brain.prompts[-1]


def test_negotiation_evaluate_offer_logic_unchanged():
    agent = NegotiationAgent(RecordingBrain())
    result = agent.handle({
        "action": "negotiation.evaluate_offer", "asking_price": 100, "min_acceptable_price": 80, "offer": 60,
    })
    assert result.data["counter_offer"] == 70.0  # same math as before the refactor


# ---------- MarketingAgent ----------

def test_marketing_ad_copy_bans_fake_proof_when_none_given():
    brain = RecordingBrain()
    agent = MarketingAgent(brain)
    agent.handle({"action": "marketing.write_ad_copy", "product": {"name": "x"}, "platform": "instagram"})
    prompt = brain.prompts[-1]
    assert MARKETING_PERSONA in prompt
    assert "do not invent any" in prompt.lower()


def test_marketing_ad_copy_references_real_proof_when_given():
    brain = RecordingBrain()
    agent = MarketingAgent(brain)
    agent.handle({
        "action": "marketing.write_ad_copy", "product": {"name": "x"}, "platform": "instagram",
        "real_proof": "5 real customers so far, all repeat buyers",
    })
    assert "5 real customers so far" in brain.prompts[-1]


def test_marketing_content_calendar_generates_angle_per_day():
    brain = RecordingBrain()
    agent = MarketingAgent(brain)
    result = agent.handle({
        "action": "marketing.suggest_content_calendar", "days": 3, "topics": ["a", "b"],
    })
    assert len(result.data["calendar"]) == 3
    assert all("angle" in day for day in result.data["calendar"])
    assert len(brain.prompts) == 3  # one think() call per day


# ---------- PurchasingAgent ----------

def test_purchasing_negotiate_with_supplier_uses_persona_and_proposes_trade():
    brain = RecordingBrain()
    agent = PurchasingAgent(brain)
    result = agent.handle({
        "action": "purchasing.negotiate_with_supplier",
        "supplier_offer": {"price": 10, "payment_terms": "50% upfront"},
        "target_terms": {"price": 8, "payment_terms": "net 30"},
    })
    assert result.success
    prompt = brain.prompts[-1]
    assert PURCHASING_PERSONA in prompt
    assert "trade" in prompt.lower()


def test_purchasing_deterministic_actions_unchanged():
    agent = PurchasingAgent(RecordingBrain())
    result = agent.handle({
        "action": "purchasing.compare_suppliers",
        "suppliers": [
            {"name": "A", "price": 100, "shipping": 10, "fees": 5},
            {"name": "B", "price": 90, "shipping": 5, "fees": 5},
        ],
    })
    assert result.data["best"]["name"] == "B"


def test_purchasing_unknown_action_still_fails_cleanly():
    agent = PurchasingAgent(RecordingBrain())
    result = agent.handle({"action": "purchasing.not_real"})
    assert not result.success
    assert "Unknown action" in result.notes


# ---------- Registry-level sanity ----------

def test_registry_still_builds_all_agents_with_no_collisions_after_upgrades():
    class FakeBrain:
        def ask(self, p):
            class R:
                text = "x"
            return R()
    agents = build_agents(FakeBrain())
    assert len(agents) == len(AGENT_CLASSES)
    all_caps = [c for a in agents for c in a.capabilities]
    assert len(all_caps) == len(set(all_caps))
    purchasing_agent = next(a for a in agents if a.name == "purchasing_agent")
    assert "purchasing.negotiate_with_supplier" in purchasing_agent.capabilities
