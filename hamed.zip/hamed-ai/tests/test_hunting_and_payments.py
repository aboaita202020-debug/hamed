from agents.payment_agent import PaymentAgent
from agents.registry import build_agents, AGENT_CLASSES
from orchestrator import HamedOrchestrator
from management.outreach_queue import OutreachQueue
from management.hunting_pipeline import ColdOutreachHunter


class FakeMultiBrain:
    def __init__(self, response_text="REASON: good fit\nMESSAGE: hi there!"):
        self.response_text = response_text

    def ask(self, prompt):
        class R:
            pass
        r = R()
        r.text = self.response_text
        return r


class FakeConfig:
    VODAFONE_CASH_NUMBER = "01040900623"


def test_payment_agent_requires_configured_number():
    agent = PaymentAgent(FakeMultiBrain(), vodafone_cash_number="")
    result = agent.handle({"action": "payment.create_claim", "amount": 100})
    assert not result.success


def test_payment_agent_creates_claim_with_instructions():
    agent = PaymentAgent(FakeMultiBrain(), vodafone_cash_number="01040900623")
    result = agent.handle({"action": "payment.create_claim", "amount": 250, "customer_ref": "ahmed"})
    assert result.success
    assert "01040900623" in result.data["instructions"]
    assert result.data["status"] == "awaiting_confirmation"


def test_payment_agent_confirm_flow():
    agent = PaymentAgent(FakeMultiBrain(), vodafone_cash_number="01040900623")
    created = agent.handle({"action": "payment.create_claim", "amount": 100, "customer_ref": "x"})
    claim_id = created.data["claim_id"]

    confirmed = agent.handle({"action": "payment.confirm", "claim_id": claim_id})
    assert confirmed.success
    assert confirmed.data["status"] == "confirmed"

    pending = agent.handle({"action": "payment.list_pending"})
    assert pending.data["pending"] == []


def test_payment_agent_reject_flow():
    agent = PaymentAgent(FakeMultiBrain(), vodafone_cash_number="01040900623")
    created = agent.handle({"action": "payment.create_claim", "amount": 100, "customer_ref": "x"})
    claim_id = created.data["claim_id"]
    rejected = agent.handle({"action": "payment.reject", "claim_id": claim_id, "note": "no transfer seen"})
    assert rejected.data["status"] == "rejected"


def test_registry_builds_payment_agent_with_config_number():
    agents = build_agents(FakeMultiBrain(), config=FakeConfig())
    payment_agents = [a for a in agents if a.name == "payment_agent"]
    assert len(payment_agents) == 1
    assert payment_agents[0].vodafone_cash_number == "01040900623"
    assert len(agents) == len(AGENT_CLASSES)


def test_registry_builds_payment_agent_without_config():
    agents = build_agents(FakeMultiBrain())  # no config passed
    payment_agent = next(a for a in agents if a.name == "payment_agent")
    assert payment_agent.vodafone_cash_number == ""


def test_outreach_queue_add_list_approve_reject():
    q = OutreachQueue()
    item = q.add(platform="facebook", candidate={"name": "x"}, draft_message="hi", reasoning="looks interested")
    assert len(q.list_pending()) == 1

    approved = q.approve(item.id)
    assert approved.status == "approved"
    assert q.list_pending() == []

    q2 = OutreachQueue()
    item2 = q2.add(platform="facebook", candidate={"name": "y"}, draft_message="hi", reasoning="x")
    rejected = q2.reject(item2.id)
    assert rejected.status == "rejected"


def test_outreach_queue_mark_sent_only_after_approval():
    q = OutreachQueue()
    item = q.add(platform="whatsapp", candidate={"phone": "123"}, draft_message="hi", reasoning="x")
    # Not approved yet - mark_sent should have no effect.
    assert q.mark_sent(item.id).status == "pending"
    q.approve(item.id)
    assert q.mark_sent(item.id).status == "sent"


def test_outreach_queue_formats_admin_notification():
    q = OutreachQueue()
    item = q.add(platform="instagram", candidate={"name": "sara"}, draft_message="hello!", reasoning="asked about product")
    notification = q.format_admin_notification(item)
    assert "instagram" in notification
    assert f"/approve {item.id}" in notification
    assert f"/reject {item.id}" in notification


def test_cold_outreach_hunter_queues_drafted_candidates():
    class HunterAgent:
        name = "facebook_agent"
        capabilities = ["social.facebook.find_candidates"]

        def handle(self, task):
            from agents.base_agent import AgentResult
            return AgentResult(agent_name=self.name, success=True, data={
                "candidates": [{"name": "Mona", "interest": "asked about pricing"}],
            })

    orch = HamedOrchestrator([HunterAgent()])
    brain = FakeMultiBrain("REASON: asked about pricing recently\nMESSAGE: Hi Mona, saw you were curious - happy to help!")
    queue = OutreachQueue()
    hunter = ColdOutreachHunter(orch, brain, queue)

    queued = hunter.hunt("facebook", "fake_token", {"description": "we sell handmade candles"})
    assert len(queued) == 1
    assert queued[0].draft_message == "Hi Mona, saw you were curious - happy to help!"
    assert queued[0].reasoning == "asked about pricing recently"
    assert len(queue.list_pending()) == 1


def test_cold_outreach_hunter_returns_empty_when_find_fails():
    class FailingHunterAgent:
        name = "facebook_agent"
        capabilities = ["social.facebook.find_candidates"]

        def handle(self, task):
            from agents.base_agent import AgentResult
            return AgentResult(agent_name=self.name, success=False, notes="No OAuth token")

    orch = HamedOrchestrator([FailingHunterAgent()])
    hunter = ColdOutreachHunter(orch, FakeMultiBrain(), OutreachQueue())
    queued = hunter.hunt("facebook", "", {})
    assert queued == []
