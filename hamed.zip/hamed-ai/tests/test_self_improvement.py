from management.strategy_params import StrategyParams
from management.self_improvement_engine import SelfImprovementEngine
from learning.learning_council import LearningCouncil
from database.db import InMemoryStore
from agents.negotiation_agent import NegotiationAgent
from agents.customer_psychology_agent import CustomerPsychologyAgent
from agents.registry import build_agents, AGENT_CLASSES


class FakeMultiBrain:
    def __init__(self, response_text="stub response"):
        self.response_text = response_text

    def ask(self, prompt):
        class R:
            pass
        r = R()
        r.text = self.response_text
        return r


# ---------- StrategyParams ----------

def test_strategy_params_get_returns_default_when_unset():
    store = InMemoryStore()
    params = StrategyParams(store)
    assert params.get("negotiation.concession_ratio", 0.5) == 0.5


def test_strategy_params_set_then_get_returns_latest_value():
    store = InMemoryStore()
    params = StrategyParams(store)
    params.set("negotiation.concession_ratio", 0.6, reason="test")
    params.set("negotiation.concession_ratio", 0.7, reason="test2")
    assert params.get("negotiation.concession_ratio") == 0.7


def test_strategy_params_history_keeps_every_change():
    store = InMemoryStore()
    params = StrategyParams(store)
    params.set("k", 1, reason="a")
    params.set("k", 2, reason="b")
    history = params.history("k")
    assert len(history) == 2
    assert history[0]["reason"] == "a"
    assert history[1]["reason"] == "b"


# ---------- NegotiationAgent tunable concession ----------

def test_negotiation_agent_uses_default_ratio_without_strategy_params():
    agent = NegotiationAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "negotiation.evaluate_offer",
        "asking_price": 100, "min_acceptable_price": 80, "offer": 60,
    })
    assert result.data["counter_offer"] == 70.0
    assert result.data["concession_ratio_used"] == 0.5


def test_negotiation_agent_reads_tuned_ratio_from_strategy_params():
    store = InMemoryStore()
    params = StrategyParams(store)
    params.set("negotiation.concession_ratio", 0.8, reason="test - concede more")

    agent = NegotiationAgent(FakeMultiBrain(), strategy_params=params)
    result = agent.handle({
        "action": "negotiation.evaluate_offer",
        "asking_price": 100, "min_acceptable_price": 80, "offer": 60,
    })
    # concession_ratio=0.8 -> counter = offer + (min_acceptable-offer)*(1-0.8)
    # = 60 + 20*0.2 = 64
    assert result.data["counter_offer"] == 64.0
    assert result.data["concession_ratio_used"] == 0.8


# ---------- CustomerPsychologyAgent accumulating profiles ----------

def test_psychology_profile_requires_store():
    agent = CustomerPsychologyAgent(FakeMultiBrain(), store=None)
    result = agent.handle({"action": "psychology.update_customer_profile", "customer_ref": "x", "conversation": "hi"})
    assert not result.success


def test_psychology_profile_accumulates_across_calls():
    store = InMemoryStore()
    agent = CustomerPsychologyAgent(FakeMultiBrain("price sensitive, prefers short replies"), store=store)

    agent.handle({
        "action": "psychology.update_customer_profile",
        "customer_ref": "cust_1", "conversation": "too expensive",
    })
    result = agent.handle({
        "action": "psychology.update_customer_profile",
        "customer_ref": "cust_1", "conversation": "still thinking about it",
    })
    assert result.success
    profiles = [e for e in store.all("customer_profiles") if e["customer_ref"] == "cust_1"]
    assert len(profiles) == 2  # both interactions logged, accumulating history


def test_psychology_get_profile_returns_latest():
    store = InMemoryStore()
    agent = CustomerPsychologyAgent(FakeMultiBrain("profile v1"), store=store)
    agent.handle({"action": "psychology.update_customer_profile", "customer_ref": "cust_2", "conversation": "x"})

    agent2 = CustomerPsychologyAgent(FakeMultiBrain("profile v2"), store=store)
    agent2.handle({"action": "psychology.update_customer_profile", "customer_ref": "cust_2", "conversation": "y"})

    result = agent.handle({"action": "psychology.get_customer_profile", "customer_ref": "cust_2"})
    assert result.data["has_history"]
    assert result.data["profile"] == "profile v2"


def test_psychology_get_profile_no_history_for_new_customer():
    store = InMemoryStore()
    agent = CustomerPsychologyAgent(FakeMultiBrain(), store=store)
    result = agent.handle({"action": "psychology.get_customer_profile", "customer_ref": "never_seen"})
    assert not result.data["has_history"]
    assert result.data["profile"] is None


# ---------- SelfImprovementEngine ----------

def test_self_improvement_increases_concession_when_close_rate_low():
    store = InMemoryStore()
    params = StrategyParams(store)
    council = LearningCouncil(store)

    # Simulate 10 close_deal attempts, only 1 succeeding (10% close rate).
    for i in range(9):
        store.insert("agent_results", {
            "task": {"action": "sales.close_deal"},
            "result": {"agent_name": "sales_agent", "success": False},
        })
    store.insert("agent_results", {
        "task": {"action": "sales.close_deal"},
        "result": {"agent_name": "sales_agent", "success": True},
    })

    engine = SelfImprovementEngine(council, params, store=store)
    summary = engine.run_cycle()

    assert params.get("negotiation.concession_ratio") == 0.55  # nudged up from default 0.5
    assert any("concession_ratio" in c for c in summary["changes_made"])


def test_self_improvement_decreases_concession_when_close_rate_high():
    store = InMemoryStore()
    params = StrategyParams(store)
    council = LearningCouncil(store)

    for i in range(9):
        store.insert("agent_results", {
            "task": {"action": "sales.close_deal"},
            "result": {"agent_name": "sales_agent", "success": True},
        })
    store.insert("agent_results", {
        "task": {"action": "sales.close_deal"},
        "result": {"agent_name": "sales_agent", "success": False},
    })

    engine = SelfImprovementEngine(council, params, store=store)
    summary = engine.run_cycle()

    assert params.get("negotiation.concession_ratio") == 0.45  # nudged down from default 0.5


def test_self_improvement_respects_bounds():
    store = InMemoryStore()
    params = StrategyParams(store)
    params.set("negotiation.concession_ratio", 0.8)  # already at upper bound
    council = LearningCouncil(store)

    for i in range(10):
        store.insert("agent_results", {
            "task": {"action": "sales.close_deal"},
            "result": {"agent_name": "sales_agent", "success": False},
        })

    engine = SelfImprovementEngine(council, params, store=store)
    engine.run_cycle()
    assert params.get("negotiation.concession_ratio") == 0.8  # did not exceed bound


def test_self_improvement_does_nothing_without_deal_data():
    store = InMemoryStore()
    params = StrategyParams(store)
    council = LearningCouncil(store)
    engine = SelfImprovementEngine(council, params, store=store)
    summary = engine.run_cycle()
    assert summary["changes_made"] == []


def test_self_improvement_flags_underperforming_agent():
    store = InMemoryStore()
    params = StrategyParams(store)
    council = LearningCouncil(store)

    for i in range(6):
        store.insert("agent_results", {
            "task": {"action": "x"},
            "result": {"agent_name": "flaky_agent", "success": i < 1},  # 1/6 success
        })

    engine = SelfImprovementEngine(council, params, store=store)
    summary = engine.run_cycle()
    assert params.get("agent_flag.flaky_agent") == "needs_review"
    assert any("flaky_agent" in c for c in summary["changes_made"])


def test_self_improvement_logs_to_store():
    store = InMemoryStore()
    params = StrategyParams(store)
    council = LearningCouncil(store)
    engine = SelfImprovementEngine(council, params, store=store)
    engine.run_cycle()
    assert len(store.all("improvement_log")) == 1


# ---------- Registry wiring ----------

def test_registry_wires_strategy_params_into_negotiation_agent():
    store = InMemoryStore()
    params = StrategyParams(store)
    agents = build_agents(FakeMultiBrain(), store=store, strategy_params=params)
    negotiation_agent = next(a for a in agents if a.name == "negotiation_agent")
    assert negotiation_agent.strategy_params is params
    assert len(agents) == len(AGENT_CLASSES)


def test_registry_wires_store_into_psychology_agent():
    store = InMemoryStore()
    agents = build_agents(FakeMultiBrain(), store=store)
    psych_agent = next(a for a in agents if a.name == "customer_psychology_agent")
    assert psych_agent.store is store
