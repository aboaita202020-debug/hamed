import pytest
from brains.multi_brain import MultiBrain, BrainProvider


def test_falls_back_to_next_provider_on_failure():
    def failing_call(prompt):
        raise RuntimeError("RateLimitError")

    def working_call(prompt):
        return f"claude response to: {prompt}"

    brain = MultiBrain([
        BrainProvider("openai", failing_call),
        BrainProvider("claude", working_call),
    ])

    result = brain.ask("hello")
    assert result.provider == "claude"
    assert result.attempts == ["openai", "claude"]
    assert "claude response" in result.text


def test_first_provider_success_no_fallback_needed():
    def working_call(prompt):
        return "ok"

    def should_not_be_called(prompt):
        raise AssertionError("should not reach second provider")

    brain = MultiBrain([
        BrainProvider("openai", working_call),
        BrainProvider("claude", should_not_be_called),
    ])

    result = brain.ask("hi")
    assert result.provider == "openai"
    assert result.attempts == ["openai"]


def test_all_providers_failing_raises_clear_error():
    def failing_call(prompt):
        raise RuntimeError("boom")

    brain = MultiBrain([
        BrainProvider("openai", failing_call),
        BrainProvider("claude", failing_call),
    ])

    with pytest.raises(RuntimeError, match="All configured AI brains failed"):
        brain.ask("hi")


def test_disabled_provider_is_skipped_like_a_failure():
    def working_call(prompt):
        return "ok"

    brain = MultiBrain([
        BrainProvider("openai", lambda p: "unused", enabled=False),
        BrainProvider("claude", working_call),
    ])

    result = brain.ask("hi")
    assert result.provider == "claude"
