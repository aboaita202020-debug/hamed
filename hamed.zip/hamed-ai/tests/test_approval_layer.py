from approvals.approval_layer import ApprovalLayer
from agents.base_agent import AgentResult


def test_result_not_requiring_approval_passes_through_untouched():
    layer = ApprovalLayer()
    result = AgentResult(agent_name="x", success=True, data={"a": 1})
    processed = layer.process(result)
    assert processed is result
    assert layer.list_pending() == []


def test_result_requiring_approval_is_queued():
    layer = ApprovalLayer()
    result = AgentResult(agent_name="x", success=False, requires_approval=True, data={"amount": 500})
    processed = layer.process(result)
    assert processed.data["status"] == "pending_approval"
    assert len(layer.list_pending()) == 1


def test_approve_and_reject_change_status():
    layer = ApprovalLayer()
    result = AgentResult(agent_name="x", success=False, requires_approval=True, data={"amount": 500})
    processed = layer.process(result)
    approval_id = processed.data["approval_id"]

    layer.approve(approval_id)
    assert layer.list_pending() == []
