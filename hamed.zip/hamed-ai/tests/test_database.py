import os
import tempfile

from database.db import InMemoryStore, SqliteStore, build_store


def test_in_memory_store_basic_insert_and_all():
    store = InMemoryStore()
    store.insert("leads", {"name": "ahmed"})
    assert store.all("leads") == [{"name": "ahmed"}]
    assert store.all("nonexistent") == []


def test_sqlite_store_persists_across_reconnects():
    path = tempfile.mktemp(suffix=".db")
    try:
        store1 = SqliteStore(path)
        store1.insert("agent_results", {"agent": "sales_agent", "success": True})
        store1.insert("agent_results", {"agent": "purchasing_agent", "success": False})

        store2 = SqliteStore(path)  # simulates restarting the process
        results = store2.all("agent_results")
        assert len(results) == 2
        assert results[0]["agent"] == "sales_agent"
        assert results[1]["success"] is False
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_sqlite_store_returns_empty_list_for_unknown_table():
    path = tempfile.mktemp(suffix=".db")
    try:
        store = SqliteStore(path)
        assert store.all("never_inserted_into") == []
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_sqlite_store_rejects_unsafe_table_names():
    path = tempfile.mktemp(suffix=".db")
    try:
        store = SqliteStore(path)
        try:
            store.insert("bad;name", {"x": 1})
            assert False, "should have raised"
        except ValueError:
            pass
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_build_store_returns_in_memory_when_no_database_url():
    class FakeConfig:
        has_database = False
    store = build_store(FakeConfig())
    assert isinstance(store, InMemoryStore)


def test_build_store_returns_sqlite_for_sqlite_url():
    path = tempfile.mktemp(suffix=".db")
    try:
        class FakeConfig:
            has_database = True
            DATABASE_URL = f"sqlite:///{path}"
        store = build_store(FakeConfig())
        assert isinstance(store, SqliteStore)
        store.insert("test", {"ok": True})
        assert store.all("test") == [{"ok": True}]
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_build_store_raises_clear_error_for_unsupported_scheme():
    class FakeConfig:
        has_database = True
        DATABASE_URL = "postgresql://user:pass@localhost/db"
    try:
        build_store(FakeConfig())
        assert False, "should have raised NotImplementedError"
    except NotImplementedError as e:
        assert "sqlite:///" in str(e)
