import json

from orchestrator import HamedOrchestrator
from agents.base_agent import BaseAgent, AgentResult
from management.decision_engine import AutonomousDecisionEngine
from management.self_reflection import SelfReflection
from database.db import InMemoryStore


class DummyAgent(BaseAgent):
    name = "dummy"
    capabilities = ["dummy.step_one", "dummy.step_two", "dummy.big_spend"]

    def handle(self, task):
        action = task.get("action")
        if action == "dummy.step_one":
            return AgentResult(agent_name=self.name, success=True, data={"progress": "step1 done"})
        if action == "dummy.step_two":
            return AgentResult(agent_name=self.name, success=True, data={"progress": "step2 done"})
        if action == "dummy.big_spend":
            return AgentResult(agent_name=self.name, success=False, requires_approval=True,
                                data={"amount": 999}, notes="Too big to run autonomously")
        return AgentResult(agent_name=self.name, success=False, notes="unknown")


class ScriptedBrain:
    """Returns canned responses in order, one per .ask() call."""
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = 0

    def ask(self, prompt):
        class R:
            pass
        r = R()
        if self.calls < len(self.responses):
            r.text = self.responses[self.calls]
        else:
            r.text = self.responses[-1]
        self.calls += 1
        return r


def _orchestrator():
    return HamedOrchestrator([DummyAgent(None)])


def test_engine_executes_valid_actions_until_goal_achieved():
    responses = [
        json.dumps({"reasoning": "start with step one", "action": "dummy.step_one", "params": {}, "goal_achieved": False}),
        json.dumps({"reasoning": "now step two", "action": "dummy.step_two", "params": {}, "goal_achieved": False}),
        json.dumps({"reasoning": "done", "action": None, "params": {}, "goal_achieved": True}),
    ]
    brain = ScriptedBrain(responses)
    engine = AutonomousDecisionEngine(_orchestrator(), brain)
    trace = engine.run("finish both steps", {}, max_steps=5)

    assert trace.goal_achieved
    assert len(trace.steps) == 3
    assert trace.steps[0].action == "dummy.step_one"
    assert trace.steps[1].action == "dummy.step_two"


def test_engine_stops_on_unknown_action_instead_of_guessing():
    responses = [
        json.dumps({"reasoning": "try something not registered", "action": "dummy.does_not_exist", "params": {}, "goal_achieved": False}),
    ]
    brain = ScriptedBrain(responses)
    engine = AutonomousDecisionEngine(_orchestrator(), brain)
    trace = engine.run("goal", {}, max_steps=5)

    assert not trace.goal_achieved
    assert "unknown/disallowed action" in trace.stopped_reason


def test_engine_stops_when_approval_required():
    responses = [
        json.dumps({"reasoning": "try the big spend", "action": "dummy.big_spend", "params": {}, "goal_achieved": False}),
    ]
    brain = ScriptedBrain(responses)
    engine = AutonomousDecisionEngine(_orchestrator(), brain)
    trace = engine.run("spend a lot", {}, max_steps=5)

    assert not trace.goal_achieved
    assert "approval" in trace.stopped_reason
    assert trace.steps[-1].result.requires_approval


def test_engine_respects_max_steps():
    # Always proposes step_one, never declares the goal achieved.
    response = json.dumps({"reasoning": "keep trying", "action": "dummy.step_one", "params": {}, "goal_achieved": False})
    brain = ScriptedBrain([response])
    engine = AutonomousDecisionEngine(_orchestrator(), brain)
    trace = engine.run("infinite goal", {}, max_steps=3)

    assert not trace.goal_achieved
    assert len(trace.steps) == 3
    assert "max_steps" in trace.stopped_reason


def test_parse_decision_handles_markdown_fenced_json():
    fenced = "```json\n" + json.dumps({"reasoning": "x", "action": None, "goal_achieved": True}) + "\n```"
    parsed = AutonomousDecisionEngine._parse_decision(fenced)
    assert parsed["goal_achieved"] is True


def test_parse_decision_falls_back_gracefully_on_garbage():
    parsed = AutonomousDecisionEngine._parse_decision("not json at all, sorry")
    assert parsed["action"] is None
    assert parsed["goal_achieved"] is False


def test_decision_trace_logged_to_store():
    store = InMemoryStore()
    responses = [json.dumps({"reasoning": "done immediately", "action": None, "goal_achieved": True})]
    brain = ScriptedBrain(responses)
    engine = AutonomousDecisionEngine(_orchestrator(), brain, store=store)
    engine.run("goal", {}, max_steps=3)

    logged = store.all("decision_traces")
    assert len(logged) == 1
    assert logged[0]["goal_achieved"] is True


def test_self_reflection_produces_and_logs_reflection():
    store = InMemoryStore()
    responses = [json.dumps({"reasoning": "done", "action": None, "goal_achieved": True})]
    brain = ScriptedBrain(responses)
    engine = AutonomousDecisionEngine(_orchestrator(), brain)
    trace = engine.run("goal", {}, max_steps=3)

    reflection_brain = ScriptedBrain(["This worked well, nothing to change."])
    reflection = SelfReflection(reflection_brain, store=store)
    result = reflection.reflect(trace)

    assert "reflection" in result
    assert len(store.all("reflections")) == 1
