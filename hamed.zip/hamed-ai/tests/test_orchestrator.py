from orchestrator import HamedOrchestrator
from agents.base_agent import BaseAgent, AgentResult


class DummyAgent(BaseAgent):
    name = "dummy"
    capabilities = ["dummy.echo"]

    def handle(self, task):
        return AgentResult(agent_name=self.name, success=True, data={"echo": task.get("message")})


class ExplodingAgent(BaseAgent):
    name = "exploding"
    capabilities = ["dummy.explode"]

    def handle(self, task):
        raise ValueError("kaboom")


def test_routes_task_to_correct_agent():
    orch = HamedOrchestrator([DummyAgent(None)])
    result = orch.run({"action": "dummy.echo", "message": "hi"})
    assert result.success
    assert result.data["echo"] == "hi"


def test_unknown_action_returns_failure_not_exception():
    orch = HamedOrchestrator([DummyAgent(None)])
    result = orch.run({"action": "does.not.exist"})
    assert not result.success
    assert "No agent registered" in result.notes


def test_agent_exception_is_caught_and_reported():
    orch = HamedOrchestrator([ExplodingAgent(None)])
    result = orch.run({"action": "dummy.explode"})
    assert not result.success
    assert "kaboom" in result.notes


def test_on_task_complete_hook_is_called():
    calls = []
    orch = HamedOrchestrator([DummyAgent(None)])
    orch.on_task_complete(lambda task, result: calls.append((task, result)))
    orch.run({"action": "dummy.echo", "message": "x"})
    assert len(calls) == 1


def test_available_capabilities_lists_all_registered_actions():
    orch = HamedOrchestrator([DummyAgent(None), ExplodingAgent(None)])
    caps = orch.available_capabilities()
    assert "dummy.echo" in caps
    assert "dummy.explode" in caps
