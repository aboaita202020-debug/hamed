from agents.affiliate_agent import AffiliateAgent
from agents.marketing_agent import MarketingAgent
from agents.education_agents import ProductEducationAgent, FaqEducationAgent
from agents.social_media_agents import FacebookAgent, InstagramAgent
from agents.registry import build_agents, AGENT_CLASSES
from orchestrator import HamedOrchestrator
from database.db import InMemoryStore
from learning.learning_council import LearningCouncil
from research_team.client_research_team import ClientResearchTeam


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = f"stub: {prompt[:15]}"
        return R()


def test_affiliate_agent_ranks_programs_by_expected_payout():
    agent = AffiliateAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "affiliate.find_programs",
        "candidate_programs": [
            {"name": "low", "commission_rate": 0.05, "avg_order_value": 100},
            {"name": "high", "commission_rate": 0.2, "avg_order_value": 100},
        ],
    })
    assert result.success
    assert result.data["ranked_programs"][0]["name"] == "high"


def test_affiliate_agent_calculates_commission():
    agent = AffiliateAgent(FakeMultiBrain())
    result = agent.handle({"action": "affiliate.calc_commission", "sale_amount": 200, "commission_rate": 0.1})
    assert result.data["commission"] == 20.0


def test_marketing_agent_builds_content_calendar():
    agent = MarketingAgent(FakeMultiBrain())
    result = agent.handle({"action": "marketing.suggest_content_calendar", "days": 3, "topics": ["a", "b"]})
    assert len(result.data["calendar"]) == 3


def test_education_agents_answer_their_own_action_only():
    product_agent = ProductEducationAgent(FakeMultiBrain())
    faq_agent = FaqEducationAgent(FakeMultiBrain())

    ok = product_agent.handle({"action": "education.product", "subject": "x"})
    wrong = product_agent.handle({"action": "education.faq", "subject": "x"})
    assert ok.success
    assert not wrong.success

    ok2 = faq_agent.handle({"action": "education.faq", "subject": "x"})
    assert ok2.success


def test_social_media_agent_requires_oauth_token():
    fb = FacebookAgent(FakeMultiBrain())
    no_token = fb.handle({"action": "social.facebook.find_candidates"})
    with_token = fb.handle({"action": "social.facebook.find_candidates", "access_token": "abc"})
    assert not no_token.success
    assert with_token.success


def test_social_media_agents_are_isolated_per_platform():
    fb = FacebookAgent(FakeMultiBrain())
    ig = InstagramAgent(FakeMultiBrain())
    # facebook agent shouldn't handle instagram actions
    result = fb.handle({"action": "social.instagram.find_candidates", "access_token": "x"})
    assert not result.success


def test_registry_builds_all_agents_without_errors():
    agents = build_agents(FakeMultiBrain())
    assert len(agents) == len(AGENT_CLASSES)
    all_capabilities = [cap for agent in agents for cap in agent.capabilities]
    assert len(all_capabilities) == len(set(all_capabilities)), "capability collision between agents"


def test_learning_council_reports_no_data_initially():
    store = InMemoryStore()
    council = LearningCouncil(store)
    analysis = council.analyze()
    assert analysis["close_rate"] is None


def test_learning_council_computes_success_rate_per_agent():
    store = InMemoryStore()
    store.insert("agent_results", {"task": {"action": "sales.close_deal"}, "result": {"agent_name": "sales_agent", "success": True}})
    store.insert("agent_results", {"task": {"action": "sales.close_deal"}, "result": {"agent_name": "sales_agent", "success": False}})
    council = LearningCouncil(store)
    analysis = council.analyze()
    assert analysis["by_agent"]["sales_agent"]["total"] == 2
    assert analysis["by_agent"]["sales_agent"]["success_rate"] == 0.5
    assert analysis["close_rate"] == 0.5


def test_client_research_team_qualifies_and_ranks():
    agents = build_agents(FakeMultiBrain())
    orch = HamedOrchestrator(agents)
    team = ClientResearchTeam(orch)
    result = team.qualify_and_rank([
        {"name": "cold", "expressed_interest": False, "budget": 0},
        {"name": "hot", "expressed_interest": True, "budget": 500},
    ])
    assert result["qualified_count"] == 1
    assert result["ranked_leads"][0]["name"] == "hot"
