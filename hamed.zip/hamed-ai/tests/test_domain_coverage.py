from agents.video_content_agent import VideoContentAgent
from agents.import_export_agent import ImportExportAgent
from agents.manufacturing_agent import ManufacturingAgent
from agents.freelance_agent import FreelanceServicesAgent
from agents.partnership_marketplace_agent import PartnershipMarketplaceAgent
from agents.market_competitor_agent import MarketCompetitorAgent
from agents.product_builder_agent import ProductBuilderAgent
from agents.verification_agent import VerificationAgent
from agents.websiteless_business_agent import WebsitelessBusinessAgent
from agents.registry import build_agents, AGENT_CLASSES
from management.experiment_engine import ExperimentEngine
from management.venture_studio import VentureStudio
from database.db import InMemoryStore


class FakeMultiBrain:
    def ask(self, prompt):
        class R:
            text = f"stub: {prompt[:15]}"
        return R()


def test_video_agent_writes_script():
    agent = VideoContentAgent(FakeMultiBrain())
    result = agent.handle({"action": "video.write_script", "product": {"name": "x"}, "platform": "tiktok"})
    assert result.success and "script" in result.data


def test_store_catalog_generation_on_websiteless_agent():
    agent = WebsitelessBusinessAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "store.generate_product_catalog_page",
        "business": {"name": "shop"},
        "products": [{"name": "item"}],
    })
    assert result.success and "catalog_copy" in result.data


def test_import_export_estimates_landed_cost():
    agent = ImportExportAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "trade.estimate_landed_cost",
        "unit_cost": 10, "freight": 2, "insurance": 1, "estimated_duty_rate_pct": 10, "other_fees": 1,
    })
    # dutiable = 13, duty = 1.3, landed = 13 + 1.3 + 1 = 15.3
    assert result.data["landed_cost"] == 15.3
    assert "customs broker" in result.notes


def test_manufacturing_ranks_factories():
    agent = ManufacturingAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "manufacturing.evaluate_factory",
        "factories": [
            {"name": "cheap_low_rating", "unit_cost": 5, "moq": 100, "rating": 2},
            {"name": "best", "unit_cost": 5, "moq": 100, "rating": 5},
        ],
    })
    assert result.data["ranked_factories"][0]["name"] == "best"


def test_manufacturing_estimates_volume_discount():
    agent = ManufacturingAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "manufacturing.estimate_unit_cost",
        "base_unit_cost": 10, "base_volume": 100, "order_volume": 100,
    })
    assert result.data["estimated_unit_cost"] == 10.0
    assert result.data["discount_applied"] == 0


def test_freelance_matches_talent_by_skill_and_budget():
    agent = FreelanceServicesAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "freelance.match_talent_to_project",
        "project": {"required_skills": ["python", "ml"], "max_budget": 50},
        "candidates": [
            {"name": "fits", "skills": ["python", "ml"], "rate": 40},
            {"name": "over_budget", "skills": ["python", "ml"], "rate": 999},
            {"name": "irrelevant", "skills": ["welding"], "rate": 10},
        ],
    })
    names = [m["name"] for m in result.data["matches"]]
    assert "fits" in names
    assert "irrelevant" not in names


def test_partnership_agent_scores_and_recommends():
    agent = PartnershipMarketplaceAgent(FakeMultiBrain())
    strong = agent.handle({
        "action": "partnership.evaluate_partner",
        "partner": {"audience_overlap_pct": 80, "reliability_score": 5, "complementary": True},
    })
    weak = agent.handle({
        "action": "partnership.evaluate_partner",
        "partner": {"audience_overlap_pct": 0, "reliability_score": 0, "complementary": False},
    })
    assert strong.data["recommendation"] == "pursue"
    assert weak.data["recommendation"] == "pass"


def test_market_agent_estimates_market_size():
    agent = MarketCompetitorAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "market.estimate_market_size",
        "total_population": 1_000_000, "target_segment_pct": 10, "avg_annual_spend": 50,
    })
    assert result.data["addressable_customers"] == 100_000
    assert result.data["estimated_market_size"] == 5_000_000


def test_product_builder_validates_idea():
    agent = ProductBuilderAgent(FakeMultiBrain())
    result = agent.handle({"action": "product.validate_idea", "idea": {"name": "x"}})
    assert result.success and "validation" in result.data


def test_verification_agent_flags_high_risk_deal():
    agent = VerificationAgent(FakeMultiBrain())
    result = agent.handle({
        "action": "verify.check_deal_risk",
        "amount": 500, "is_new_counterparty": True, "urgency_pressure": True,
        "new_counterparty_review_threshold": 200,
    })
    assert result.data["risk_level"] == "high"
    assert result.requires_approval


def test_verification_agent_low_risk_for_normal_deal():
    agent = VerificationAgent(FakeMultiBrain())
    result = agent.handle({"action": "verify.check_deal_risk", "amount": 50, "is_new_counterparty": False})
    assert result.data["risk_level"] == "low"
    assert not result.requires_approval


def test_registry_includes_all_new_agents_without_collisions():
    agents = build_agents(FakeMultiBrain())
    assert len(agents) == len(AGENT_CLASSES)
    all_capabilities = [cap for agent in agents for cap in agent.capabilities]
    assert len(all_capabilities) == len(set(all_capabilities))


def test_experiment_engine_recommends_kill_on_poor_metrics():
    store = InMemoryStore()
    engine = ExperimentEngine(store)
    engine.log_metrics("bad_channel", {"sample_size": 100, "conversion_rate": 0.001, "margin": 0.01})
    result = engine.evaluate("bad_channel")
    assert result["decision"] == "kill"


def test_experiment_engine_recommends_scale_on_good_metrics():
    store = InMemoryStore()
    engine = ExperimentEngine(store)
    engine.log_metrics("good_channel", {"sample_size": 100, "conversion_rate": 0.05, "margin": 0.3})
    result = engine.evaluate("good_channel")
    assert result["decision"] == "scale"


def test_experiment_engine_waits_for_more_data_on_small_sample():
    store = InMemoryStore()
    engine = ExperimentEngine(store)
    engine.log_metrics("new_channel", {"sample_size": 3, "conversion_rate": 0.05, "margin": 0.3})
    result = engine.evaluate("new_channel")
    assert result["decision"] == "keep_running"


def test_venture_studio_tracks_separate_ventures():
    store = InMemoryStore()
    studio = VentureStudio(store, default_daily_goal=100.0)
    studio.record_revenue("venture_a", "product_sale", 60)
    studio.record_revenue("venture_b", "affiliate", 30)

    report = studio.portfolio_report()
    totals = {r["venture"]: r["today_total"] for r in report}
    assert totals["venture_a"] == 60
    assert totals["venture_b"] == 30
