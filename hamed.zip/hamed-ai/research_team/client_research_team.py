"""
Client Research Team.

Per the spec: research the customer -> qualify -> estimate purchase
probability -> rank leads -> prep outreach strategy. This composes the
existing ResearchAgent + CustomerHunterAgent rather than duplicating logic.
"""
from typing import Any, Dict, List


class ClientResearchTeam:
    def __init__(self, orchestrator):
        self.orchestrator = orchestrator

    def qualify_and_rank(self, candidates: List[Dict[str, Any]]) -> Dict[str, Any]:
        qualify_result = self.orchestrator.run({
            "action": "hunter.qualify",
            "candidates": candidates,
        })
        qualified = qualify_result.data.get("qualified", []) if qualify_result.success else []

        # Add a naive estimated_value/close_probability if not already present,
        # so ranking always has something to sort on.
        for c in qualified:
            c.setdefault("estimated_value", c.get("budget", 0))
            c.setdefault("close_probability", 0.5 if c.get("expressed_interest") else 0.2)

        rank_result = self.orchestrator.run({
            "action": "research.rank_leads",
            "leads": qualified,
        })

        return {
            "qualified_count": len(qualified),
            "ranked_leads": rank_result.data.get("ranked_leads", []) if rank_result.success else qualified,
        }

    def prep_outreach_strategy(self, lead: Dict[str, Any]) -> str:
        prompt = (
            f"Given this lead's info, suggest a short, specific outreach opening "
            f"message strategy (channel + first line), not a full script: {lead}"
        )
        # Reuses any agent's `think` helper via the orchestrator's research agent
        # would require agent access; simplest path is to expose think() on team level:
        return prompt  # left for the caller to pass into an agent/brain; kept text-only here
