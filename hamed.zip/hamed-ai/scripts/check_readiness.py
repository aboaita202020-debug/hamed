#!/usr/bin/env python3
"""
Readiness check — run this BEFORE deploying, per the project philosophy:
"ما نرفعش المشروع قبل ما نعمل Test كامل" (don't ship before full testing).

Usage:
    python scripts/check_readiness.py

Checks, in order:
  1. Required env vars are set (TELEGRAM_BOT_TOKEN, OPENAI_API_KEY)
  2. Every core module imports cleanly (catches ImportError-type bugs
     BEFORE they show up at 3am in production logs)
  3. Which optional integrations are configured (DB, brains, Twilio,
     Vodafone Cash, admin chat) - informational, never blocking
  4. Telegram bot token is valid (live check via getMe - skipped
     gracefully if there's no network access)
  5. The full agent registry builds with zero capability collisions

Exit code 0 = safe to deploy. Exit code 1 = fix the printed issues first.
"""
import os
import sys
import urllib.request
import urllib.error
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

CHECK, CROSS, WARN = "✅", "❌", "⚠️ "


def check_required_env() -> bool:
    print("\n1) Required environment variables")
    from config import config, REQUIRED_VARS, BRAIN_KEY_VARS
    ok = True
    for var in REQUIRED_VARS:
        present = bool(getattr(config, var))
        print(f"   {CHECK if present else CROSS} {var}")
        ok = ok and present

    has_brain = any(getattr(config, v) for v in BRAIN_KEY_VARS)
    configured_brain_vars = [v for v in BRAIN_KEY_VARS if getattr(config, v)]
    if has_brain:
        print(f"   {CHECK} AI brain key present: {configured_brain_vars}")
    else:
        print(f"   {CROSS} No AI brain key set - need at least one of: {BRAIN_KEY_VARS}")
        print(f"   {WARN} Free options: GEMINI_API_KEY (ai.google.dev) or GROQ_API_KEY (console.groq.com)")
    ok = ok and has_brain
    return ok


def check_imports() -> bool:
    print("\n2) Core module imports")
    modules = [
        "config", "brains.multi_brain", "agents.registry", "orchestrator",
        "approvals.approval_layer", "database.db", "learning.learning_council",
        "research_team.client_research_team", "management.board",
        "management.revenue_engine", "management.experiment_engine",
        "management.venture_studio", "management.decision_engine",
        "management.self_reflection", "management.outreach_queue",
        "management.hunting_pipeline", "channels.whatsapp_channel",
        "channels.voice_channel", "agents.payment_agent",
    ]
    ok = True
    for mod in modules:
        try:
            __import__(mod)
            print(f"   {CHECK} {mod}")
        except Exception as e:  # noqa: BLE001
            print(f"   {CROSS} {mod} -> {e}")
            ok = False
    return ok


def check_optional_integrations() -> None:
    print("\n3) Optional integrations (informational only)")
    from config import config
    brains = config.available_brains()
    print(f"   {CHECK if brains else WARN} AI brains configured: {brains or '(none - bot will not respond!)'}")
    print(f"   {CHECK if config.has_database else WARN} Database: "
          f"{'sqlite/persistent' if config.has_database else 'in-memory (data lost on restart)'}")
    print(f"   {CHECK if config.has_twilio else WARN} Twilio (WhatsApp/Voice channels): "
          f"{'configured' if config.has_twilio else 'not configured'}")
    print(f"   {CHECK if config.has_vodafone_cash else WARN} Vodafone Cash payment number: "
          f"{'configured' if config.has_vodafone_cash else 'not configured'}")
    print(f"   {CHECK if config.has_admin_chat else WARN} Admin Telegram chat id (for /hunt, /approve): "
          f"{'configured' if config.has_admin_chat else 'not set - cold outreach approval commands will be silent'}")


def check_telegram_token_live() -> bool:
    print("\n4) Telegram bot token (live check)")
    from config import config
    if not config.TELEGRAM_BOT_TOKEN:
        print(f"   {CROSS} No token to check.")
        return False
    url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/getMe"
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read())
        if data.get("ok"):
            username = data["result"].get("username")
            print(f"   {CHECK} Token valid - bot is @{username}")
            return True
        print(f"   {CROSS} Telegram rejected the token: {data}")
        return False
    except urllib.error.URLError as e:
        print(f"   {WARN} Could not reach Telegram (no network access here?) - skipping live check: {e}")
        return True  # don't fail the whole check just because this sandbox has no network
    except Exception as e:  # noqa: BLE001
        print(f"   {CROSS} Unexpected error checking token: {e}")
        return False


def check_agent_registry() -> bool:
    print("\n5) Agent registry integrity")
    try:
        from agents.registry import build_agents, AGENT_CLASSES

        class _NullBrain:
            def ask(self, prompt):
                class R:
                    text = ""
                return R()

        agents = build_agents(_NullBrain())
        all_caps = [c for a in agents for c in a.capabilities]
        collisions = len(all_caps) != len(set(all_caps))
        print(f"   {CHECK if not collisions else CROSS} {len(agents)} agents, {len(all_caps)} capabilities, "
              f"{'no collisions' if not collisions else 'COLLISION DETECTED'}")
        return len(agents) == len(AGENT_CLASSES) and not collisions
    except Exception as e:  # noqa: BLE001
        print(f"   {CROSS} Registry failed to build: {e}")
        return False


def main():
    print("=" * 60)
    print("Hamed AI — Pre-Launch Readiness Check")
    print("=" * 60)

    results = {
        "required_env": check_required_env(),
        "imports": check_imports(),
        "agent_registry": check_agent_registry(),
    }
    check_optional_integrations()  # informational, doesn't affect exit code
    results["telegram_token"] = check_telegram_token_live()

    print("\n" + "=" * 60)
    all_ok = all(results.values())
    if all_ok:
        print(f"{CHECK} All critical checks passed. Safe to run: python bot.py")
    else:
        failed = [k for k, v in results.items() if not v]
        print(f"{CROSS} Fix these before deploying: {failed}")
    print("=" * 60)

    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
