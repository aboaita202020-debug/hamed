"""
Dashboard + Health endpoints, matching the spec's
http://127.0.0.1:8000/dashboard and /health. Also mounts the WhatsApp and
Voice webhooks when those channels are configured, so Twilio has an actual
URL to call.
"""
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, PlainTextResponse


def build_app(config, orchestrator, approval_layer, revenue_engine=None, store=None,
              whatsapp_channel=None, voice_channel=None):
    app = FastAPI(title="Hamed AI")

    if whatsapp_channel is not None:
        @app.post("/webhooks/whatsapp")
        async def whatsapp_webhook(request: Request):
            # Twilio posts form-encoded fields: From="whatsapp:+201...", Body="..."
            form = await request.form()
            from_number = str(form.get("From", "")).replace("whatsapp:", "")
            body = str(form.get("Body", ""))
            reply_text = whatsapp_channel.handle_incoming(from_number, body)
            whatsapp_channel.send_message(from_number, reply_text)
            return PlainTextResponse("", status_code=200)

    if voice_channel is not None:
        @app.post("/voice/incoming")
        async def voice_incoming():
            return PlainTextResponse(voice_channel.initial_twiml(), media_type="application/xml")

        @app.post("/voice/handle_speech")
        async def voice_handle_speech(request: Request):
            form = await request.form()
            speech_text = str(form.get("SpeechResult", ""))
            turn_count = int(request.query_params.get("turn", "0"))
            twiml = voice_channel.handle_speech_result(speech_text, turn_count=turn_count)
            return PlainTextResponse(twiml, media_type="application/xml")

    @app.get("/health")
    def health():
        return {
            "status": "ok",
            "message": "Hamed AI - START WITH DIAGNOSTICS",
            "brains_configured": config.available_brains(),
            "database": "connected" if config.has_database else "in-memory",
            "twilio": config.has_twilio,
            "paymob": config.has_paymob,
            "whatsapp_webhook": "/webhooks/whatsapp" if whatsapp_channel is not None else None,
            "voice_webhook": "/voice/incoming" if voice_channel is not None else None,
        }

    @app.get("/dashboard", response_class=HTMLResponse)
    def dashboard():
        capabilities = orchestrator.available_capabilities()
        pending = approval_layer.list_pending()
        brains = config.available_brains()

        capability_rows = "".join(f"<li>{c}</li>" for c in capabilities) or "<li>(none)</li>"
        pending_rows = "".join(
            f"<li>#{p.id} - {p.agent_name} - {p.data} - {p.notes}</li>" for p in pending
        ) or "<li>No pending approvals</li>"
        brain_rows = " → ".join(brains) if brains else "(none configured)"

        revenue_html = ""
        if revenue_engine is not None:
            r = revenue_engine.progress_report()
            by_source_rows = "".join(f"<li>{k}: {v} {revenue_engine.currency}</li>" for k, v in r["by_source"].items()) or "<li>No revenue logged yet</li>"
            revenue_html = f"""
              <h2>Revenue Engine — Today</h2>
              <p><b>{r['today_total']} / {r['daily_goal']} {revenue_engine.currency}</b> ({r['progress_pct']}%)</p>
              <ul>{by_source_rows}</ul>
            """

        decisions_html = ""
        if store is not None:
            traces = store.all("decision_traces")[-10:]
            reflections = store.all("reflections")[-10:]
            trace_rows = "".join(
                f"<li>goal_achieved={t['goal_achieved']} steps={t['step_count']} - {t['stopped_reason']}</li>"
                for t in traces
            ) or "<li>No autonomous runs logged yet</li>"
            reflection_rows = "".join(
                f"<li>{r['reflection']}</li>" for r in reflections
            ) or "<li>No reflections logged yet</li>"
            decisions_html = f"""
              <h2>Autonomous Decision Runs (latest 10)</h2>
              <ul>{trace_rows}</ul>
              <h2>Self-Reflections (latest 10)</h2>
              <ul>{reflection_rows}</ul>
            """

        return f"""
        <html>
        <head><title>Hamed AI Dashboard</title></head>
        <body style="font-family: sans-serif; max-width: 800px; margin: 40px auto;">
          <h1>🧠 Hamed AI Dashboard</h1>
          <p><b>Active brains (fallback order):</b> {brain_rows}</p>
          {revenue_html}
          {decisions_html}
          <h2>Available Capabilities ({len(capabilities)})</h2>
          <ul>{capability_rows}</ul>
          <h2>Pending Approvals</h2>
          <ul>{pending_rows}</ul>
          <p><a href="/health">Health check</a></p>
        </body>
        </html>
        """

    return app
