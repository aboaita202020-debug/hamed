"""
Learning Council.

Per the spec: Agents -> Results -> Analysis -> Learning -> Improved Strategy.
This module doesn't retrain any model - it mines the logged agent_results
for simple, explainable signals (win rate by price point, by channel, by
agent) that a human (or a future policy layer) can act on. Wire it to
`orchestrator.on_task_complete` via `store.insert("agent_results", ...)`,
which `bot.py` already does.
"""
from collections import defaultdict
from typing import Any, Dict, List


class LearningCouncil:
    def __init__(self, store):
        self.store = store

    def analyze(self) -> Dict[str, Any]:
        results: List[Dict[str, Any]] = self.store.all("agent_results")
        if not results:
            return {"summary": "No data yet.", "by_agent": {}, "close_rate": None}

        by_agent = defaultdict(lambda: {"total": 0, "success": 0})
        closed_deals = 0
        total_deal_attempts = 0

        for entry in results:
            result = entry.get("result", {})
            agent_name = result.get("agent_name", "unknown")
            by_agent[agent_name]["total"] += 1
            if result.get("success"):
                by_agent[agent_name]["success"] += 1

            task = entry.get("task", {})
            if task.get("action") == "sales.close_deal":
                total_deal_attempts += 1
                if result.get("success"):
                    closed_deals += 1

        by_agent_rates = {
            name: {
                "total": stats["total"],
                "success_rate": round(stats["success"] / stats["total"], 3) if stats["total"] else 0,
            }
            for name, stats in by_agent.items()
        }

        close_rate = round(closed_deals / total_deal_attempts, 3) if total_deal_attempts else None

        return {
            "summary": f"{len(results)} logged results across {len(by_agent)} agents.",
            "by_agent": by_agent_rates,
            "close_rate": close_rate,
        }

    def recommendations(self) -> List[str]:
        """Very simple heuristic recommendations - replace/extend as real data accumulates."""
        analysis = self.analyze()
        recs = []
        for agent_name, stats in analysis.get("by_agent", {}).items():
            if stats["total"] >= 5 and stats["success_rate"] < 0.4:
                recs.append(
                    f"'{agent_name}' has a low success rate ({stats['success_rate']:.0%}) "
                    f"over {stats['total']} tasks - review its prompts/logic."
                )
        if analysis.get("close_rate") is not None and analysis["close_rate"] < 0.2:
            recs.append(
                f"Deal close rate is low ({analysis['close_rate']:.0%}) - "
                f"consider adjusting pricing strategy or objection handling."
            )
        return recs or ["Not enough data yet for strategy recommendations."]
