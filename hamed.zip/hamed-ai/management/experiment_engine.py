"""
Experiment Engine: tracks a business experiment (a product, channel, or
offer being tested) against simple go/no-go thresholds, and recommends
Scale / Iterate / Kill. Deliberately simple and explainable - replace the
thresholds with real unit-economics targets as you learn what "good" means
for your business.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class Experiment:
    name: str
    metrics: Dict[str, float] = field(default_factory=dict)
    status: str = "running"  # running | scale | iterate | kill


class ExperimentEngine:
    def __init__(self, store):
        self.store = store

    def log_metrics(self, experiment_name: str, metrics: Dict[str, float]) -> None:
        self.store.insert("experiments", {"name": experiment_name, "metrics": metrics})

    def _latest_metrics(self, experiment_name: str) -> Dict[str, float]:
        entries = [e for e in self.store.all("experiments") if e["name"] == experiment_name]
        return entries[-1]["metrics"] if entries else {}

    def evaluate(
        self,
        experiment_name: str,
        min_sample_size: int = 20,
        min_conversion_rate: float = 0.02,
        min_margin: float = 0.15,
    ) -> Dict[str, Any]:
        metrics = self._latest_metrics(experiment_name)
        sample_size = metrics.get("sample_size", 0)
        conversion_rate = metrics.get("conversion_rate", 0)
        margin = metrics.get("margin", 0)

        if sample_size < min_sample_size:
            decision = "keep_running"
            reason = f"Only {sample_size} samples so far - need at least {min_sample_size} to decide."
        elif conversion_rate >= min_conversion_rate and margin >= min_margin:
            decision = "scale"
            reason = f"Conversion {conversion_rate:.1%} and margin {margin:.1%} both clear the bar."
        elif conversion_rate >= min_conversion_rate * 0.5 or margin >= min_margin * 0.5:
            decision = "iterate"
            reason = "Some signal but below the scale bar - worth one more iteration before killing."
        else:
            decision = "kill"
            reason = f"Conversion {conversion_rate:.1%} and margin {margin:.1%} are both too low."

        return {
            "experiment": experiment_name,
            "decision": decision,
            "reason": reason,
            "metrics": metrics,
        }

    def all_experiments(self) -> List[str]:
        return sorted({e["name"] for e in self.store.all("experiments")})
