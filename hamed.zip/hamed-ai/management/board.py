"""
Board of Directors / Management Layer.

Per the spec: Hamed CEO/Orchestrator -> Management Layer -> Specialist
Agents -> Execution Tools. This module sits ABOVE the orchestrator: it takes
a high-level business goal and breaks it into a sequence of concrete agent
tasks, running them through the orchestrator one by one and collecting
results. It does not replace HamedOrchestrator - it composes it.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List

from agents.base_agent import AgentResult


@dataclass
class GoalReport:
    goal: str
    steps: List[Dict[str, Any]] = field(default_factory=list)  # [{task, result}]

    @property
    def all_succeeded(self) -> bool:
        return all(s["result"].success for s in self.steps)

    @property
    def needs_approval(self) -> bool:
        return any(s["result"].requires_approval for s in self.steps)


class HamedBoard:
    """
    Ships with one built-in playbook (`new_deal_pipeline`) covering the core
    Find -> Research -> Offer -> Negotiate -> Close flow from the spec.
    Add more playbooks the same way as your real workflows solidify -
    each one is just a list of tasks to run in order.
    """
    def __init__(self, orchestrator):
        self.orchestrator = orchestrator

    def run_goal(self, goal_name: str, context: Dict[str, Any]) -> GoalReport:
        playbook = self._playbooks().get(goal_name)
        if playbook is None:
            return GoalReport(goal=goal_name, steps=[{
                "task": {},
                "result": AgentResult(agent_name="board", success=False,
                                       notes=f"Unknown goal/playbook: {goal_name}"),
            }])

        report = GoalReport(goal=goal_name)
        for build_task in playbook:
            task = build_task(context, report)
            result = self.orchestrator.run(task)
            report.steps.append({"task": task, "result": result})
            # Feed each step's output data back into context so later steps can use it.
            context.setdefault("_history", []).append(result.data)
            if not result.success and not result.requires_approval:
                break  # stop the pipeline on a hard failure; approval-pending steps continue
        return report

    def _playbooks(self):
        return {
            "new_deal_pipeline": [
                lambda ctx, rpt: {
                    "action": "hunter.qualify",
                    "candidates": ctx.get("candidates", []),
                },
                lambda ctx, rpt: {
                    "action": "research.rank_leads",
                    "leads": rpt.steps[-1]["result"].data.get("qualified", []),
                },
                lambda ctx, rpt: {
                    "action": "sales.present_offer",
                    "message": ctx.get("message", ""),
                    "product": ctx.get("product", {}),
                },
                lambda ctx, rpt: {
                    "action": "negotiation.evaluate_offer",
                    "asking_price": ctx.get("product", {}).get("price", 0),
                    "min_acceptable_price": ctx.get("min_acceptable_price", 0),
                    "offer": ctx.get("customer_offer", 0),
                },
                lambda ctx, rpt: {
                    "action": "sales.close_deal",
                    "amount": ctx.get("customer_offer", 0),
                    "max_autonomous_amount": ctx.get("max_autonomous_amount", 100),
                },
            ],
        }
