"""
Self-Reflection: closes the "think -> act -> observe" loop by having Hamed
look back at what it just did and extract a short, concrete lesson, instead
of just moving on. Lessons are logged so the Learning Council (and a human)
can see patterns across many runs, not just one.
"""
import logging
from typing import Any, Dict

from management.decision_engine import DecisionTrace

logger = logging.getLogger("hamed.reflection")


class SelfReflection:
    def __init__(self, multi_brain, store=None):
        self.multi_brain = multi_brain
        self.store = store

    def reflect(self, trace: DecisionTrace) -> Dict[str, Any]:
        prompt = f"""Review this autonomous run and give a short, honest reflection.
Do not be encouraging by default - be specific and useful.

{trace.summary()}

Answer in 2-3 short sentences covering:
1) Did this actually move toward the goal, or just look busy?
2) One concrete thing to do differently next time (or "nothing, it worked" if genuinely true).
"""
        try:
            reflection_text = self.multi_brain.ask(prompt).text
        except Exception as e:  # noqa: BLE001
            logger.warning("Reflection: brain call failed: %s", e)
            reflection_text = f"(reflection unavailable - brain call failed: {e})"

        reflection = {
            "goal": trace.goal,
            "goal_achieved": trace.goal_achieved,
            "step_count": len(trace.steps),
            "reflection": reflection_text,
        }

        if self.store is not None:
            self.store.insert("reflections", reflection)

        return reflection
