"""
StrategyParams: tunable behavior knobs (e.g. how much Negotiation concedes,
how cautious Verification is) that live OUTSIDE agent code so the
Self-Improvement Engine can adjust them based on real results, without
anyone editing Python files.

Built on the same append-only store every other table in this project uses
(agent_results, decision_traces, payments, ...) - `set()` just inserts a new
row, `get()` returns the most recent value for that key. This keeps a full
history of every adjustment for free, which doubles as an audit log of
"why did Hamed start behaving differently on this date".
"""
from typing import Any


class StrategyParams:
    def __init__(self, store):
        self.store = store

    def get(self, key: str, default: Any = None) -> Any:
        entries = [e for e in self.store.all("strategy_params") if e["key"] == key]
        if not entries:
            return default
        return entries[-1]["value"]

    def set(self, key: str, value: Any, reason: str = "") -> None:
        self.store.insert("strategy_params", {"key": key, "value": value, "reason": reason})

    def history(self, key: str):
        return [e for e in self.store.all("strategy_params") if e["key"] == key]
