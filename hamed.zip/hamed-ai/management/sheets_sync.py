"""
SheetsSync: bridges the internal store (leads, deals, revenue, payments,
agent_results, decision_traces) to a human-readable Google Sheet.

Deliberately manual/on-demand (`sync_all()` called from a Telegram command)
rather than syncing on every single event - free-tier Google Sheets API has
per-minute quotas, and a business owner checking a spreadsheet once in a
while doesn't need real-time updates anyway.
"""
import logging
from typing import Dict, List

logger = logging.getLogger("hamed.sheets_sync")

DEFAULT_TABLES = ["leads", "deals", "revenue", "payments", "agent_results", "decision_traces"]


class SheetsSync:
    def __init__(self, store, sheets_client):
        self.store = store
        self.sheets_client = sheets_client

    def sync_all(self, tables: List[str] = None) -> Dict[str, int]:
        if self.sheets_client is None:
            raise RuntimeError("Google Sheets is not configured - set GOOGLE_SHEETS_CREDENTIALS_JSON and GOOGLE_SHEET_ID.")

        tables = tables or DEFAULT_TABLES
        results: Dict[str, int] = {}
        for table in tables:
            records = self.store.all(table)
            try:
                synced = self.sheets_client.sync_table(table, records)
                results[table] = synced
            except Exception as e:  # noqa: BLE001
                logger.warning("Failed syncing table '%s' to Sheets: %s", table, e)
                results[table] = -1  # -1 signals "failed", distinct from "0 records"
        return results
