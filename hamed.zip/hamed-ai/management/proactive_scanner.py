"""
Proactive Opportunity Scanner: the piece that makes Hamed act WITHOUT
waiting for someone to message first.

Runs on a timer (see bot.py) and checks, in one pass, every kind of deal
Hamed is built to find:
  - Revenue pace (are we behind the daily goal?)
  - Experiments that are ready for a Scale/Iterate/Kill decision
  - Open research opportunities (Opportunity Hunter)
  - Cold candidates on every social platform with a configured access token

Cold-outreach candidates still go through the OutreachQueue (one-tap human
approval before contacting a stranger) - see management/outreach_queue.py
for why that line never moves, no matter how "proactive" this scanner gets.
Everything else in this report is pure information for you to act on, or
for the AutonomousDecisionEngine to act on automatically when it's a
reactive response to someone who already engaged.
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger("hamed.proactive_scanner")


class ProactiveScanner:
    def __init__(self, orchestrator, cold_outreach_hunter, revenue_engine, experiment_engine, outreach_queue):
        self.orchestrator = orchestrator
        self.cold_outreach_hunter = cold_outreach_hunter
        self.revenue_engine = revenue_engine
        self.experiment_engine = experiment_engine
        self.outreach_queue = outreach_queue

    def scan(self, offer_context: Dict[str, Any], platform_tokens: Dict[str, str],
             research_query: str = "") -> Dict[str, Any]:
        report: Dict[str, Any] = {}

        report["revenue"] = self._check_revenue_pace()
        report["experiments"] = self._check_experiments()
        report["research_opportunities"] = self._check_research(research_query)
        report["new_cold_candidates"] = self._hunt_all_platforms(offer_context, platform_tokens)

        return report

    def _check_revenue_pace(self) -> Dict[str, Any]:
        progress = self.revenue_engine.progress_report()
        behind_pace = progress["progress_pct"] is not None and progress["progress_pct"] < 50
        return {**progress, "flag": "behind_pace" if behind_pace else "on_track"}

    def _check_experiments(self) -> List[Dict[str, Any]]:
        decisions = []
        for name in self.experiment_engine.all_experiments():
            decision = self.experiment_engine.evaluate(name)
            if decision["decision"] != "keep_running":
                decisions.append(decision)  # only surface actionable ones
        return decisions

    def _check_research(self, query: str) -> List[Dict[str, Any]]:
        if not query:
            return []
        result = self.orchestrator.run({"action": "research.find_opportunities", "query": query})
        return result.data.get("results", []) if result.success else []

    def _hunt_all_platforms(self, offer_context: Dict[str, Any], platform_tokens: Dict[str, str]) -> int:
        total_queued = 0
        for platform, token in platform_tokens.items():
            try:
                queued = self.cold_outreach_hunter.hunt(platform, token, offer_context)
                total_queued += len(queued)
            except Exception as e:  # noqa: BLE001
                logger.warning("Proactive scan on %s failed: %s", platform, e)
        return total_queued

    def format_summary(self, report: Dict[str, Any]) -> str:
        lines = ["🔍 تقرير المسح الاستباقي"]

        rev = report["revenue"]
        lines.append(f"💰 الإيراد: {rev['today_total']}/{rev['daily_goal']} ({rev['flag']})")

        if report["experiments"]:
            lines.append("🔬 قرارات تجارب جاهزة:")
            for d in report["experiments"]:
                lines.append(f"  - {d['experiment']}: {d['decision']} ({d['reason']})")

        if report["research_opportunities"]:
            lines.append(f"🔎 فرص بحث جديدة: {len(report['research_opportunities'])}")

        if report["new_cold_candidates"]:
            lines.append(f"🎯 مرشحين جدد للتواصل (مستنيين موافقتك): {report['new_cold_candidates']} - استخدمي /pending")
        else:
            lines.append("🎯 مفيش مرشحين جدد دلوقتي.")

        return "\n".join(lines)
