"""
Venture Studio: manages a portfolio of ventures (product lines, side
businesses, market experiments) side by side, using RevenueEngine and
ExperimentEngine per venture, and surfaces a portfolio-level view so you
can see which ventures to double down on.
"""
from typing import Any, Dict, List

from management.revenue_engine import RevenueEngine
from management.experiment_engine import ExperimentEngine


class VentureStudio:
    def __init__(self, store, default_daily_goal: float = 100.0, currency: str = "USD"):
        self.store = store
        self.default_daily_goal = default_daily_goal
        self.currency = currency
        self._ventures: Dict[str, Dict[str, Any]] = {}

    def register_venture(self, name: str, daily_goal: float = None) -> None:
        self._ventures[name] = {
            "revenue_engine": RevenueEngine(
                self.store, daily_goal=daily_goal or self.default_daily_goal, currency=self.currency
            ),
        }

    def _venture(self, name: str) -> Dict[str, Any]:
        if name not in self._ventures:
            self.register_venture(name)
        return self._ventures[name]

    def record_revenue(self, venture_name: str, source: str, amount: float, note: str = "") -> None:
        # Namespace the revenue source per venture so the shared RevenueEngine/store
        # doesn't mix numbers across ventures.
        self._venture(venture_name)["revenue_engine"].record(f"{venture_name}:{source}", amount, note)

    def portfolio_report(self) -> List[Dict[str, Any]]:
        report = []
        for name, venture in self._ventures.items():
            engine: RevenueEngine = venture["revenue_engine"]
            full_progress = engine.progress_report()
            venture_sources = {
                k.split(":", 1)[1]: v for k, v in full_progress["by_source"].items()
                if k.startswith(f"{name}:")
            }
            venture_today = sum(
                v for k, v in full_progress["by_source"].items() if k.startswith(f"{name}:")
            )
            report.append({
                "venture": name,
                "today_total": round(venture_today, 2),
                "daily_goal": engine.daily_goal,
                "by_source": venture_sources,
            })
        return sorted(report, key=lambda v: v["today_total"], reverse=True)
