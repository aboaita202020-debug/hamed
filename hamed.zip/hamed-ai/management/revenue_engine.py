"""
Revenue Engine: tracks income from every source the spec lists (product
sales, brokerage, affiliate commissions, services, etc.) and reports
progress toward the daily revenue goal.
"""
from datetime import datetime, timezone
from typing import Any, Dict, List


class RevenueEngine:
    def __init__(self, store, daily_goal: float = 1000.0, currency: str = "USD"):
        self.store = store
        self.daily_goal = daily_goal
        self.currency = currency

    def record(self, source: str, amount: float, note: str = "") -> None:
        """
        `source` examples: 'product_sale', 'brokerage', 'affiliate_commission',
        'lead_generation_fee', 'ai_marketing_service', 'content_service'.
        """
        self.store.insert("revenue", {
            "source": source,
            "amount": amount,
            "note": note,
            "currency": self.currency,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

    def today_total(self) -> float:
        today = datetime.now(timezone.utc).date().isoformat()
        return sum(
            r["amount"] for r in self.store.all("revenue")
            if r["timestamp"].startswith(today)
        )

    def breakdown_by_source(self) -> Dict[str, float]:
        totals: Dict[str, float] = {}
        for r in self.store.all("revenue"):
            totals[r["source"]] = totals.get(r["source"], 0) + r["amount"]
        return totals

    def progress_report(self) -> Dict[str, Any]:
        today = self.today_total()
        return {
            "today_total": round(today, 2),
            "daily_goal": self.daily_goal,
            "progress_pct": round(min(today / self.daily_goal, 1.0) * 100, 1) if self.daily_goal else None,
            "remaining": round(max(self.daily_goal - today, 0), 2),
            "by_source": {k: round(v, 2) for k, v in self.breakdown_by_source().items()},
        }
