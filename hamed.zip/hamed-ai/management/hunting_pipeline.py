"""
Cold Outreach Hunter: the actual "قنص الفرص" flow, wired safely.

1. Search for candidates via the platform-specific social media agent
   (find_candidates - requires a real OAuth access_token; returns [] otherwise).
2. Draft a personalized opening message for each candidate.
3. Queue every draft in the OutreachQueue instead of sending it - a human
   taps approve/reject once (see bot.py's /pending, /approve, /reject).

This is what makes Hamed's hunting genuinely autonomous end-to-end EXCEPT
for the very last "contact a stranger" step, which stays a one-tap human
decision - see management/outreach_queue.py for why that line exists.
"""
import logging
from typing import Any, Dict, List

from management.outreach_queue import OutreachQueue, OutreachItem

logger = logging.getLogger("hamed.hunting")


class ColdOutreachHunter:
    def __init__(self, orchestrator, multi_brain, outreach_queue: OutreachQueue):
        self.orchestrator = orchestrator
        self.multi_brain = multi_brain
        self.outreach_queue = outreach_queue

    def hunt(self, platform: str, access_token: str, offer_context: Dict[str, Any]) -> List[OutreachItem]:
        find_result = self.orchestrator.run({
            "action": f"social.{platform}.find_candidates",
            "access_token": access_token,
        })

        if not find_result.success:
            logger.info("Hunting on %s produced no candidates: %s", platform, find_result.notes)
            return []

        candidates = find_result.data.get("candidates", [])
        queued: List[OutreachItem] = []

        for candidate in candidates:
            draft, reasoning = self._draft_message(candidate, offer_context)
            item = self.outreach_queue.add(
                platform=platform, candidate=candidate, draft_message=draft, reasoning=reasoning,
            )
            queued.append(item)

        return queued

    def _draft_message(self, candidate: Dict[str, Any], offer_context: Dict[str, Any]) -> (str, str):
        prompt = (
            f"A potential customer public profile summary: {candidate}. "
            f"We offer: {offer_context}. "
            f"Write ONE short, non-spammy, personalized opening message referencing "
            f"something specific about them, and explain in one line why they might "
            f"be a good fit. Respond as: REASON: <why this candidate>\\nMESSAGE: <the message>"
        )
        text = self.multi_brain.ask(prompt).text
        reason, message = self._split_reason_message(text)
        return message, reason

    @staticmethod
    def _split_reason_message(text: str) -> (str, str):
        reason, message = "", text
        for line in text.splitlines():
            if line.upper().startswith("REASON:"):
                reason = line.split(":", 1)[1].strip()
            elif line.upper().startswith("MESSAGE:"):
                message = line.split(":", 1)[1].strip()
        return reason, message
