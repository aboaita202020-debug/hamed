"""
Outreach Queue — the safety gate between "Hamed found a cold lead" and
"Hamed actually messages a stranger".

This is deliberately separate from ApprovalLayer (which gates by MONEY
amount). This one gates by CONSENT: has this person already interacted
with you (replied, commented, messaged first)? If yes, Hamed can act
autonomously (see bot.py's Telegram handler + AutonomousDecisionEngine).
If no - it's a cold contact - it goes through here first.

Why this exists instead of just sending: unsolicited bulk messaging is
how social/messaging accounts get banned within hours, and in many
places it's regulated as spam. A one-tap approval keeps Hamed's
"hunting" fully autonomous right up to the final send, while keeping a
human decision on whether THIS particular stranger gets contacted.
"""
import itertools
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

_id_counter = itertools.count(1)


@dataclass
class OutreachItem:
    id: int
    platform: str
    candidate: Dict[str, Any]
    draft_message: str
    reasoning: str = ""
    status: str = "pending"  # pending | approved | rejected | sent


class OutreachQueue:
    def __init__(self):
        self._items: Dict[int, OutreachItem] = {}

    def add(self, platform: str, candidate: Dict[str, Any], draft_message: str, reasoning: str = "") -> OutreachItem:
        item_id = next(_id_counter)
        item = OutreachItem(
            id=item_id, platform=platform, candidate=candidate,
            draft_message=draft_message, reasoning=reasoning,
        )
        self._items[item_id] = item
        return item

    def list_pending(self) -> List[OutreachItem]:
        return [i for i in self._items.values() if i.status == "pending"]

    def approve(self, item_id: int) -> Optional[OutreachItem]:
        item = self._items.get(item_id)
        if item and item.status == "pending":
            item.status = "approved"
        return item

    def reject(self, item_id: int) -> Optional[OutreachItem]:
        item = self._items.get(item_id)
        if item and item.status == "pending":
            item.status = "rejected"
        return item

    def mark_sent(self, item_id: int) -> Optional[OutreachItem]:
        item = self._items.get(item_id)
        if item and item.status == "approved":
            item.status = "sent"
        return item

    def format_admin_notification(self, item: OutreachItem) -> str:
        return (
            f"🎯 فرصة جديدة على {item.platform} (#{item.id})\n"
            f"السبب: {item.reasoning}\n"
            f"المرشح: {item.candidate}\n"
            f"مسودة الرسالة: {item.draft_message}\n\n"
            f"للموافقة: /approve {item.id}\nللرفض: /reject {item.id}"
        )
