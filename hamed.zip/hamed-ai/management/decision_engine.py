"""
Autonomous Decision Engine ("التفكير الذاتي واتخاذ القرارات").

This is what turns Hamed from "a fixed playbook runner" (HamedBoard) into
something that can look at an open-ended goal, decide FOR ITSELF what to do
next, act, observe the result, and decide again - a ReAct-style loop:

    Think -> Act -> Observe -> Think again -> ... -> Done / Blocked / Stuck

It never invents new agent actions - every decision is validated against
`orchestrator.available_capabilities()` before it's run, so "thinking for
itself" still can't call something that doesn't exist or bypass the
Approval Layer (a decision that requires_approval stops the loop instead of
being silently retried).
"""
import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from agents.base_agent import AgentResult

logger = logging.getLogger("hamed.decision_engine")


@dataclass
class DecisionStep:
    reasoning: str
    action: Optional[str]
    params: Dict[str, Any]
    result: Optional[AgentResult] = None


@dataclass
class DecisionTrace:
    goal: str
    steps: List[DecisionStep] = field(default_factory=list)
    stopped_reason: str = ""
    goal_achieved: bool = False

    def summary(self) -> str:
        lines = [f"Goal: {self.goal}", f"Stopped: {self.stopped_reason}"]
        for i, step in enumerate(self.steps, 1):
            outcome = "success" if step.result and step.result.success else "failed/pending"
            lines.append(f"  {i}. [{step.action}] {step.reasoning[:80]} -> {outcome}")
        return "\n".join(lines)


class AutonomousDecisionEngine:
    def __init__(self, orchestrator, multi_brain, store=None):
        self.orchestrator = orchestrator
        self.multi_brain = multi_brain
        self.store = store  # optional - if set, every trace is logged for the Learning Council

    def run(self, goal: str, context: Dict[str, Any], max_steps: int = 8) -> DecisionTrace:
        trace = DecisionTrace(goal=goal)
        history_summary: List[str] = []

        for step_num in range(1, max_steps + 1):
            decision = self._decide_next_action(goal, context, history_summary)

            if decision.get("goal_achieved"):
                trace.goal_achieved = True
                trace.stopped_reason = "Model reports the goal is achieved."
                trace.steps.append(DecisionStep(
                    reasoning=decision.get("reasoning", ""), action=None, params={}
                ))
                break

            action = decision.get("action")
            params = decision.get("params", {}) or {}
            reasoning = decision.get("reasoning", "")

            if not action:
                trace.stopped_reason = "Model returned no action and did not claim the goal was achieved."
                break

            if action not in self.orchestrator.available_capabilities():
                trace.stopped_reason = f"Model proposed unknown/disallowed action '{action}' - stopping rather than guessing."
                trace.steps.append(DecisionStep(reasoning=reasoning, action=action, params=params))
                break

            task = {"action": action, **params}
            result = self.orchestrator.run(task)
            step = DecisionStep(reasoning=reasoning, action=action, params=params, result=result)
            trace.steps.append(step)

            history_summary.append(
                f"Step {step_num}: tried '{action}' because \"{reasoning}\" -> "
                f"{'succeeded' if result.success else 'failed'}"
                f"{' (pending approval)' if result.requires_approval else ''}"
                f" data={result.data} notes={result.notes}"
            )

            if result.requires_approval:
                trace.stopped_reason = f"Step {step_num} needs human approval before continuing autonomously."
                break

            if not result.success:
                trace.stopped_reason = f"Step {step_num} failed and the loop stops rather than looping blindly: {result.notes}"
                # Give the model one more turn to see the failure and decide whether
                # to adapt - but only if there's budget left. Otherwise stop here.
                if step_num >= max_steps:
                    break
                continue

        else:
            trace.stopped_reason = f"Reached max_steps ({max_steps}) without the model declaring the goal achieved."

        if self.store is not None:
            self.store.insert("decision_traces", {
                "goal": trace.goal,
                "stopped_reason": trace.stopped_reason,
                "goal_achieved": trace.goal_achieved,
                "step_count": len(trace.steps),
            })

        return trace

    def _decide_next_action(
        self, goal: str, context: Dict[str, Any], history_summary: List[str]
    ) -> Dict[str, Any]:
        capabilities = self.orchestrator.available_capabilities()
        history_text = "\n".join(history_summary) if history_summary else "(no actions taken yet)"

        prompt = f"""You are Hamed's decision-making core. You have a goal and a fixed set of
tools (capabilities) you're allowed to call - nothing else.

GOAL: {goal}

CONTEXT: {json.dumps(context, ensure_ascii=False, default=str)}

AVAILABLE CAPABILITIES (you may ONLY use one of these as "action"):
{json.dumps(capabilities, ensure_ascii=False)}

HISTORY SO FAR:
{history_text}

Decide the single next best action to move toward the goal, or say the goal
is already achieved. Respond with ONLY a JSON object, no other text, no
markdown fences:
{{"reasoning": "short reason for this choice", "action": "capability.name or null", "params": {{}}, "goal_achieved": false}}
"""
        try:
            response_text = self.multi_brain.ask(prompt).text
        except Exception as e:  # noqa: BLE001
            logger.warning("Decision engine: all brains failed: %s", e)
            return {"reasoning": f"Brain call failed: {e}", "action": None, "goal_achieved": False}

        return self._parse_decision(response_text)

    @staticmethod
    def _parse_decision(text: str) -> Dict[str, Any]:
        """Robustly extract a JSON object even if the model added stray text/fences."""
        cleaned = text.strip()
        cleaned = re.sub(r"^```(json)?", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()

        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        candidate = match.group(0) if match else cleaned

        try:
            parsed = json.loads(candidate)
            if not isinstance(parsed, dict):
                raise ValueError("Decision JSON is not an object")
            parsed.setdefault("reasoning", "")
            parsed.setdefault("action", None)
            parsed.setdefault("params", {})
            parsed.setdefault("goal_achieved", False)
            return parsed
        except Exception as e:  # noqa: BLE001
            logger.warning("Decision engine: could not parse model output as JSON: %s | text=%r", e, text)
            return {
                "reasoning": f"Could not parse a valid decision from the model output: {text[:200]}",
                "action": None,
                "params": {},
                "goal_achieved": False,
            }
