"""
Self-Improvement Engine: the actual "auto-tuning" loop.

    LearningCouncil (analyzes past results)
            -> SelfImprovementEngine (decides what to adjust, within safe bounds)
            -> StrategyParams (stores the new value)
            -> agents read StrategyParams next time they act
            -> new results flow back into LearningCouncil
            -> repeat

This is deliberately RULE-BASED, not another LLM call deciding blindly -
tuning a business's pricing behavior from a model's free-form guess would be
reckless. Every adjustment has an explicit, explainable rule and a hard cap,
and every change is logged with WHY it happened (see StrategyParams.set's
`reason` field) so a human can always see and reverse what Hamed changed
about its own behavior.

Run this periodically (e.g. once a day via the /improve admin command, or a
cron job hitting the same function) - it doesn't need to run on every message.
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger("hamed.self_improvement")

# Hard bounds - the engine will never push a parameter outside these ranges,
# no matter how strong the signal, to avoid runaway or reckless adjustments.
BOUNDS = {
    "negotiation.concession_ratio": (0.2, 0.8),
}
STEP = 0.05  # how much a single improvement cycle can move a ratio parameter


class SelfImprovementEngine:
    def __init__(self, learning_council, strategy_params, store=None):
        self.learning_council = learning_council
        self.strategy_params = strategy_params
        self.store = store

    def run_cycle(self) -> Dict[str, Any]:
        analysis = self.learning_council.analyze()
        changes: List[str] = []

        changes += self._tune_negotiation(analysis)
        changes += self._flag_underperforming_agents(analysis)

        summary = {
            "analysis_summary": analysis.get("summary", ""),
            "close_rate": analysis.get("close_rate"),
            "changes_made": changes,
        }

        if self.store is not None:
            self.store.insert("improvement_log", summary)

        return summary

    def _tune_negotiation(self, analysis: Dict[str, Any]) -> List[str]:
        close_rate = analysis.get("close_rate")
        if close_rate is None:
            return []  # not enough deal data yet - don't guess

        key = "negotiation.concession_ratio"
        current = float(self.strategy_params.get(key, 0.5))
        low, high = BOUNDS[key]
        changes: List[str] = []

        if close_rate < 0.2 and current < high:
            new_value = round(min(current + STEP, high), 2)
            reason = f"Close rate is low ({close_rate:.0%}) - conceding a bit more to close more deals."
            self.strategy_params.set(key, new_value, reason=reason)
            changes.append(f"{key}: {current} -> {new_value} ({reason})")

        elif close_rate > 0.7 and current > low:
            new_value = round(max(current - STEP, low), 2)
            reason = f"Close rate is high ({close_rate:.0%}) - holding firmer to protect margin."
            self.strategy_params.set(key, new_value, reason=reason)
            changes.append(f"{key}: {current} -> {new_value} ({reason})")

        return changes

    def _flag_underperforming_agents(self, analysis: Dict[str, Any]) -> List[str]:
        changes: List[str] = []
        for agent_name, stats in analysis.get("by_agent", {}).items():
            if stats["total"] >= 5 and stats["success_rate"] < 0.4:
                key = f"agent_flag.{agent_name}"
                already_flagged = self.strategy_params.get(key)
                if not already_flagged:
                    reason = (
                        f"Success rate {stats['success_rate']:.0%} over {stats['total']} tasks "
                        f"- flagged for human review, not auto-disabled."
                    )
                    self.strategy_params.set(key, "needs_review", reason=reason)
                    changes.append(f"{key}: flagged needs_review ({reason})")
        return changes
