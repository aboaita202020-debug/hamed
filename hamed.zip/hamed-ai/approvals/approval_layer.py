"""
Safety / Approval Layer.

Rule from the spec: routine operational tasks run autonomously; major
financial decisions wait for explicit user approval. This module is the
single gate every agent result passes through before being treated as final.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List
import itertools

from agents.base_agent import AgentResult

_id_counter = itertools.count(1)


@dataclass
class PendingApproval:
    id: int
    agent_name: str
    data: Dict[str, Any]
    notes: str
    status: str = "pending"  # pending | approved | rejected


class ApprovalLayer:
    def __init__(self):
        self._pending: Dict[int, PendingApproval] = {}

    def process(self, result: AgentResult) -> AgentResult:
        """Intercepts any AgentResult that requires_approval and queues it."""
        if not result.requires_approval:
            return result

        approval_id = next(_id_counter)
        pending = PendingApproval(
            id=approval_id, agent_name=result.agent_name, data=result.data, notes=result.notes
        )
        self._pending[approval_id] = pending
        result.data = {**result.data, "approval_id": approval_id, "status": "pending_approval"}
        return result

    def list_pending(self) -> List[PendingApproval]:
        return [p for p in self._pending.values() if p.status == "pending"]

    def approve(self, approval_id: int) -> PendingApproval:
        p = self._pending[approval_id]
        p.status = "approved"
        return p

    def reject(self, approval_id: int) -> PendingApproval:
        p = self._pending[approval_id]
        p.status = "rejected"
        return p
