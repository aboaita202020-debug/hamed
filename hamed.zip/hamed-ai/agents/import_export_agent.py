from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class ImportExportAgent(BaseAgent):
    """
    Estimates landed cost for cross-border trade and flags markets worth
    exploring. This is a planning tool, not legal/customs advice - real
    duty rates, HS codes, and compliance requirements must be confirmed
    with a licensed customs broker or the destination country's official
    tariff schedule before committing to a shipment.
    """
    name = "import_export_agent"
    capabilities = ["trade.estimate_landed_cost", "trade.suggest_export_markets"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "trade.estimate_landed_cost":
            unit_cost = task.get("unit_cost", 0)
            freight = task.get("freight", 0)
            insurance = task.get("insurance", 0)
            duty_rate_pct = task.get("estimated_duty_rate_pct", 0)  # user-supplied estimate
            other_fees = task.get("other_fees", 0)

            dutiable_value = unit_cost + freight + insurance
            estimated_duty = dutiable_value * (duty_rate_pct / 100)
            landed_cost = dutiable_value + estimated_duty + other_fees

            return AgentResult(
                agent_name=self.name,
                success=True,
                data={
                    "dutiable_value": round(dutiable_value, 2),
                    "estimated_duty": round(estimated_duty, 2),
                    "landed_cost": round(landed_cost, 2),
                },
                notes="Duty rate is a user-supplied estimate - confirm the real "
                      "HS code and duty rate with a licensed customs broker.",
            )

        if action == "trade.suggest_export_markets":
            product = task.get("product", {})
            prompt = (
                f"Given this product, suggest 3 export markets worth researching "
                f"and one reason each (demand, low competition, trade agreement, etc.), "
                f"as a starting point for further research - not a compliance judgment: {product}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"suggestions": reply})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
