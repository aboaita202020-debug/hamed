"""
Payment Agent — Vodafone Cash (manual confirmation).

Reality check baked into the design: a personal/business Vodafone Cash
number has no public API for Hamed to verify a transfer automatically.
Real-time automatic confirmation needs Vodafone's merchant/aggregator
integration (or a gateway like Paymob/Fawry), which requires business
registration - not something this agent can fake.

So this agent does the honest version: it gives the customer the number
and a reference code, records the claim as "awaiting confirmation", and
notifies the business owner (you) to manually confirm once you see the
transfer notification on your phone. One `payment.confirm` call from you
(or your admin bot command) marks it paid and unblocks the order.
"""
import itertools
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List

from agents.base_agent import BaseAgent, AgentResult

logger = logging.getLogger("hamed.payment_agent")
_ref_counter = itertools.count(1001)


@dataclass
class PaymentClaim:
    id: int
    amount: float
    customer_ref: str
    status: str = "awaiting_confirmation"  # awaiting_confirmation | confirmed | rejected
    note: str = ""


class PaymentAgent(BaseAgent):
    name = "payment_agent"
    capabilities = ["payment.create_claim", "payment.confirm", "payment.reject", "payment.list_pending"]

    def __init__(self, multi_brain, vodafone_cash_number: str = "", store=None):
        super().__init__(multi_brain)
        self.vodafone_cash_number = vodafone_cash_number
        self.store = store  # optional - lets payment claims show up in Google Sheets sync
        self._claims: Dict[int, PaymentClaim] = {}

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "payment.create_claim":
            return self._create_claim(task)
        if action == "payment.confirm":
            return self._set_status(task, "confirmed")
        if action == "payment.reject":
            return self._set_status(task, "rejected")
        if action == "payment.list_pending":
            pending = [c for c in self._claims.values() if c.status == "awaiting_confirmation"]
            return AgentResult(agent_name=self.name, success=True, data={"pending": [vars(c) for c in pending]})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _create_claim(self, task: Dict[str, Any]) -> AgentResult:
        if not self.vodafone_cash_number:
            return AgentResult(
                agent_name=self.name, success=False,
                notes="VODAFONE_CASH_NUMBER not configured - cannot create a payment claim.",
            )
        amount = task.get("amount", 0)
        customer_ref = task.get("customer_ref", "")
        claim_id = next(_ref_counter)
        claim = PaymentClaim(id=claim_id, amount=amount, customer_ref=customer_ref)
        self._claims[claim_id] = claim
        self._log_to_store(claim)

        instructions = (
            f"حوّل {amount} جنيه على فودافون كاش رقم {self.vodafone_cash_number}، "
            f"واكتب في الرسالة كود المرجع #{claim_id}. بعد التحويل هيتراجع الدفع ويتأكد الطلب."
        )
        return AgentResult(
            agent_name=self.name, success=True,
            data={"claim_id": claim_id, "instructions": instructions, "status": claim.status},
            notes="Awaiting manual confirmation from the business owner - no auto-verification available.",
        )

    def _set_status(self, task: Dict[str, Any], status: str) -> AgentResult:
        claim_id = task.get("claim_id")
        claim = self._claims.get(claim_id)
        if not claim:
            return AgentResult(agent_name=self.name, success=False, notes=f"No claim found with id {claim_id}")
        claim.status = status
        claim.note = task.get("note", "")
        self._log_to_store(claim)
        return AgentResult(agent_name=self.name, success=True, data={"claim_id": claim_id, "status": status})

    def _log_to_store(self, claim: PaymentClaim) -> None:
        if self.store is not None:
            self.store.insert("payments", dict(vars(claim)))
