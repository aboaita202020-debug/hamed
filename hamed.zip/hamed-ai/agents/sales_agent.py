from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult

# Shared persona instruction, prepended to every sales prompt. This is what
# actually makes Hamed sound like a professional service salesperson instead
# of a generic chatbot: consultative (understands before pitching),
# value-first (outcomes over features - critical for services since there's
# no physical product to point at), and never uses fabricated urgency or
# scarcity - trust is the entire product when you're selling a service.
SALES_PERSONA = (
    "You are Hamed, a professional services salesperson. Your approach: "
    "understand the customer's real situation before pitching, speak in terms "
    "of outcomes and results (not just features), sound confident and warm "
    "but never pushy or desperate, and never invent fake urgency, fake scarcity, "
    "or fake social proof - if you don't have a real detail (a real testimonial, "
    "a real limited slot), don't imply one. Match the customer's language and tone."
)


class SalesAgent(BaseAgent):
    name = "sales_agent"
    capabilities = [
        "sales.greet",
        "sales.discover_needs",
        "sales.present_offer",
        "sales.handle_objection",
        "sales.close_deal",
        "sales.followup",
    ]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        customer_message = task.get("message", "")
        customer_profile = task.get("customer_profile", "")  # optional - from CustomerPsychologyAgent

        if action == "sales.greet":
            return self._greet(task, customer_message)

        if action == "sales.discover_needs":
            return self._discover_needs(customer_message, customer_profile)

        if action == "sales.present_offer":
            return self._present_offer(task, customer_message, customer_profile)

        if action == "sales.handle_objection":
            return self._handle_objection(customer_message, customer_profile)

        if action == "sales.close_deal":
            return self._close_deal(task)

        if action == "sales.followup":
            return self._followup(task, customer_message)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _greet(self, task: Dict[str, Any], customer_message: str) -> AgentResult:
        business_context = task.get("business_context", "")
        prompt = (
            f"{SALES_PERSONA}\n"
            f"A new customer just reached out. Their message: '{customer_message}'. "
            f"Business context: {business_context}. "
            f"Write a short, warm opening that acknowledges what they said and asks "
            f"ONE clarifying question to understand their need - don't pitch anything yet."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})

    def _discover_needs(self, customer_message: str, customer_profile: str) -> AgentResult:
        profile_note = f"What we know about this customer so far: {customer_profile}" if customer_profile else ""
        prompt = (
            f"{SALES_PERSONA}\n"
            f"Customer said: '{customer_message}'. {profile_note}\n"
            f"Before presenting anything, you need to understand: what specific "
            f"problem are they trying to solve, what have they tried before, and "
            f"what would success look like for them. Ask ONE focused, natural "
            f"question that moves this forward - not a generic 'how can I help'."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})

    def _present_offer(self, task: Dict[str, Any], customer_message: str, customer_profile: str) -> AgentResult:
        product = task.get("product", {})
        price = product.get("price", 0)
        profile_note = f"What we know about this customer: {customer_profile}" if customer_profile else ""
        prompt = (
            f"{SALES_PERSONA}\n"
            f"Customer said: '{customer_message}'. {profile_note}\n"
            f"Present this service/offer, framed around the specific outcome it "
            f"gives THIS customer, not a generic feature list: {product}. "
            f"Structure: (1) one line connecting to what they said they need, "
            f"(2) the concrete outcome/result they'll get, (3) a soft next step "
            f"(a question, not a hard close). Keep it short."
        )
        reply = self.think(prompt)
        return AgentResult(
            agent_name=self.name,
            success=True,
            data={"reply": reply, "price": price},
        )

    def _handle_objection(self, customer_message: str, customer_profile: str) -> AgentResult:
        profile_note = f"What we know about this customer: {customer_profile}" if customer_profile else ""
        prompt = (
            f"{SALES_PERSONA}\n"
            f"Customer objection: '{customer_message}'. {profile_note}\n"
            f"First, silently identify the REAL underlying category of this "
            f"objection (price/value, trust, timing, unclear need, or needs "
            f"someone else's approval) - then respond using the right technique "
            f"for that category:\n"
            f"- price/value -> reframe around ROI/outcome, don't just concede on price\n"
            f"- trust -> offer a concrete reassurance (guarantee, trial, references) "
            f"if genuinely available; otherwise be transparent about being new\n"
            f"- timing -> find out the REAL blocker, offer one small next step "
            f"that doesn't require a full commitment now\n"
            f"- unclear need -> go back to clarifying their actual problem\n"
            f"- needs approval -> offer to help them make the case internally\n"
            f"Write ONLY the customer-facing reply (not your internal category "
            f"analysis), short and natural, moving the conversation forward "
            f"without being pushy."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})

    def _close_deal(self, task: Dict[str, Any]) -> AgentResult:
        amount = float(task.get("amount", 0))
        max_autonomous = task.get("max_autonomous_amount", 100)
        if amount > max_autonomous:
            # Big financial decisions go to the Approval Layer, per the spec.
            return AgentResult(
                agent_name=self.name,
                success=False,
                requires_approval=True,
                data={"amount": amount},
                notes=f"Deal amount {amount} exceeds autonomous limit {max_autonomous}.",
            )
        return AgentResult(
            agent_name=self.name,
            success=True,
            data={"amount": amount, "status": "closed"},
        )

    def _followup(self, task: Dict[str, Any], customer_message: str) -> AgentResult:
        days_since_contact = task.get("days_since_contact", 0)
        prompt = (
            f"{SALES_PERSONA}\n"
            f"This customer went quiet {days_since_contact} days ago after: '{customer_message}'. "
            f"Write a short, low-pressure follow-up that adds a small new piece of "
            f"value or a specific question - not just 'just checking in'."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})
