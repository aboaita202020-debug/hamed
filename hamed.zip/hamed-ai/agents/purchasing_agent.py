from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult

# Same principle as Sales/Negotiation/Marketing personas: a professional
# buyer negotiates on TOTAL cost of ownership (price + terms + reliability),
# not just unit price, and builds a relationship worth repeat business -
# never bluffs about volume or competing suppliers that don't actually exist.
PURCHASING_PERSONA = (
    "You are Hamed, a professional procurement negotiator representing the "
    "buyer. Negotiate on total value: price, payment terms, delivery time, "
    "and quality guarantees - not price alone. Propose trades (e.g. faster "
    "payment for a discount, or a trial order before a larger commitment). "
    "Never bluff about order volume or competing suppliers that don't exist - "
    "a supplier relationship built on a discovered lie ends fast and badly."
)


class PurchasingAgent(BaseAgent):
    """
    Implements the decision chain from the spec:
    Purchase Cost -> Shipping -> Fees -> Total Cost -> Expected Sale Price
    -> Profit -> Risk -> Decision
    """
    name = "purchasing_agent"
    capabilities = [
        "purchasing.compare_suppliers",
        "purchasing.evaluate_deal",
        "purchasing.negotiate_with_supplier",
    ]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "purchasing.compare_suppliers":
            suppliers: List[Dict[str, Any]] = task.get("suppliers", [])
            scored = [self._score_supplier(s) for s in suppliers]
            scored.sort(key=lambda s: s["total_cost"])
            best = scored[0] if scored else None
            return AgentResult(
                agent_name=self.name,
                success=True,
                data={"ranked_suppliers": scored, "best": best},
            )

        if action == "purchasing.evaluate_deal":
            eval_result = self._evaluate_deal(task)
            requires_approval = eval_result["total_cost"] > task.get(
                "max_autonomous_amount", 100
            )
            return AgentResult(
                agent_name=self.name,
                success=True,
                requires_approval=requires_approval,
                data=eval_result,
                notes="Exceeds autonomous purchase limit" if requires_approval else "",
            )

        if action == "purchasing.negotiate_with_supplier":
            return self._negotiate_with_supplier(task)

        return AgentResult(
            agent_name=self.name, success=False, notes=f"Unknown action: {action}"
        )

    def _negotiate_with_supplier(self, task: Dict[str, Any]) -> AgentResult:
        supplier_offer = task.get("supplier_offer", {})
        target_terms = task.get("target_terms", {})
        prompt = (
            f"{PURCHASING_PERSONA}\n"
            f"Supplier's current offer: {supplier_offer}. What we'd ideally like "
            f"instead: {target_terms}. Write a short message to the supplier "
            f"proposing better terms, framed as a trade (not just 'lower your "
            f"price'), that keeps the relationship collaborative."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})

    @staticmethod
    def _score_supplier(supplier: Dict[str, Any]) -> Dict[str, Any]:
        cost = supplier.get("price", 0)
        shipping = supplier.get("shipping", 0)
        fees = supplier.get("fees", 0)
        total_cost = cost + shipping + fees
        return {**supplier, "total_cost": total_cost}

    @staticmethod
    def _evaluate_deal(task: Dict[str, Any]) -> Dict[str, Any]:
        cost = task.get("purchase_cost", 0)
        shipping = task.get("shipping", 0)
        fees = task.get("fees", 0)
        total_cost = cost + shipping + fees
        expected_sale_price = task.get("expected_sale_price", 0)
        profit = expected_sale_price - total_cost
        margin = (profit / expected_sale_price) if expected_sale_price else 0

        # Simple risk heuristic - replace with a real model as data accumulates.
        if margin >= 0.3:
            risk = "low"
        elif margin >= 0.1:
            risk = "medium"
        else:
            risk = "high"

        return {
            "total_cost": total_cost,
            "expected_sale_price": expected_sale_price,
            "profit": profit,
            "margin": round(margin, 3),
            "risk": risk,
            "decision": "proceed" if risk != "high" else "reject",
        }
