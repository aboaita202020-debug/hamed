from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult

# Same principle as Sales/Negotiation personas: real copywriting technique
# (Problem-Agitate-Solution, not just adjectives), and an explicit ban on
# fabricated numbers/claims/reviews - a small business's ad copy is often the
# only thing a stranger sees before deciding to trust them; a single
# discovered lie (a fake "500+ happy customers" with zero customers yet)
# costs far more than the ad ever gains.
MARKETING_PERSONA = (
    "You are Hamed, a professional marketing copywriter for small businesses. "
    "Use real copywriting structure: name the problem the customer has, make "
    "them feel understood, then present the specific solution and a clear "
    "next step. NEVER invent statistics, customer counts, reviews, awards, or "
    "results that weren't given to you - if no real numbers were provided, "
    "write around the offer's real value instead of making one up."
)


class MarketingAgent(BaseAgent):
    """Ad copy, social captions, and content-calendar suggestions."""
    name = "marketing_agent"
    capabilities = ["marketing.write_ad_copy", "marketing.suggest_content_calendar"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "marketing.write_ad_copy":
            return self._write_ad_copy(task)

        if action == "marketing.suggest_content_calendar":
            return self._suggest_content_calendar(task)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _write_ad_copy(self, task: Dict[str, Any]) -> AgentResult:
        product = task.get("product", {})
        platform = task.get("platform", "generic")
        real_proof = task.get("real_proof", "")  # e.g. an actual testimonial/result, if any exists
        proof_note = f"You may reference this REAL proof point: {real_proof}" if real_proof else \
            "No real proof points were given - do not invent any."

        prompt = (
            f"{MARKETING_PERSONA}\n"
            f"Write a short ad for platform '{platform}' promoting this "
            f"product/service: {product}. {proof_note} "
            f"Match the tone typical of {platform} ads. Keep it concise."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"ad_copy": reply})

    def _suggest_content_calendar(self, task: Dict[str, Any]) -> AgentResult:
        days = task.get("days", 7)
        topics = task.get("topics", [])
        business_context = task.get("business_context", "")

        calendar = []
        for i in range(days):
            topic = topics[i % len(topics)] if topics else "general update"
            prompt = (
                f"{MARKETING_PERSONA}\n"
                f"Business context: {business_context}. Today's content topic: '{topic}'. "
                f"Give ONE short, specific content angle/hook for this day (one line, "
                f"not a full post) - something concrete, not a generic restatement of the topic."
            )
            angle = self.think(prompt)
            calendar.append({"day": i + 1, "topic": topic, "angle": angle})

        return AgentResult(agent_name=self.name, success=True, data={"calendar": calendar})
