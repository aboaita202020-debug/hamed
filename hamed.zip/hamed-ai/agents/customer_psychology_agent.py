from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class CustomerPsychologyAgent(BaseAgent):
    """
    Studies buyer behavior: why deals are won or lost, what motivates a
    purchase, and how to build trust. Feeds insights back to Sales/
    Negotiation agents and to the Learning Council.

    With a `store` wired in, this agent also builds an ACCUMULATING profile
    per customer (keyed by customer_ref/chat_id) across every interaction -
    not just a one-off analysis. That's the difference between "analyze this
    one conversation" and "remember what we've learned about this specific
    person over the last 5 conversations", which is what actually lets Hamed
    personalize instead of repeating the same generic reply forever.
    """
    name = "customer_psychology_agent"
    capabilities = [
        "psychology.analyze_objection_reason",
        "psychology.detect_buying_signals",
        "psychology.explain_loss_reason",
        "psychology.update_customer_profile",
        "psychology.get_customer_profile",
    ]

    def __init__(self, multi_brain, store=None):
        super().__init__(multi_brain)
        self.store = store  # optional - profile accumulation needs persistence

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        conversation = task.get("conversation", "")

        if action == "psychology.analyze_objection_reason":
            prompt = (
                f"Analyze this customer objection and identify the likely underlying "
                f"reason (price, trust, timing, need, authority): {conversation}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"analysis": reply})

        if action == "psychology.detect_buying_signals":
            prompt = (
                f"List any buying signals present in this conversation "
                f"(urgency, specific questions about delivery/price, etc.): {conversation}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"signals": reply})

        if action == "psychology.explain_loss_reason":
            outcome = task.get("outcome", "lost")
            prompt = (
                f"Given this conversation, the deal was {outcome}. "
                f"Give a short, specific, non-generic explanation of the most likely "
                f"reason, and one concrete change to try next time: {conversation}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"explanation": reply})

        if action == "psychology.update_customer_profile":
            return self._update_profile(task)

        if action == "psychology.get_customer_profile":
            return self._get_profile(task)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _update_profile(self, task: Dict[str, Any]) -> AgentResult:
        if self.store is None:
            return AgentResult(
                agent_name=self.name, success=False,
                notes="No store wired in - customer profiles need persistence to accumulate.",
            )
        customer_ref = task.get("customer_ref")
        if not customer_ref:
            return AgentResult(agent_name=self.name, success=False, notes="customer_ref is required.")

        conversation = task.get("conversation", "")
        outcome = task.get("outcome", "")
        previous = self._latest_profile(customer_ref)

        prompt = (
            f"Update this customer's psychology profile based on a new interaction.\n"
            f"PREVIOUS PROFILE (empty if first time): {previous}\n"
            f"NEW CONVERSATION: {conversation}\n"
            f"OUTCOME (if any): {outcome}\n"
            f"Write a short updated profile covering: price sensitivity (low/med/high), "
            f"communication style preference, main objections seen so far, and trust level. "
            f"Keep it to 3-4 short lines, merging with the previous profile rather than "
            f"starting over."
        )
        updated_profile_text = self.think(prompt)

        self.store.insert("customer_profiles", {
            "customer_ref": customer_ref,
            "profile": updated_profile_text,
        })
        return AgentResult(agent_name=self.name, success=True, data={"profile": updated_profile_text})

    def _get_profile(self, task: Dict[str, Any]) -> AgentResult:
        customer_ref = task.get("customer_ref")
        profile = self._latest_profile(customer_ref) if self.store else None
        return AgentResult(
            agent_name=self.name, success=True,
            data={"profile": profile, "has_history": profile is not None},
        )

    def _latest_profile(self, customer_ref: str):
        if self.store is None or not customer_ref:
            return None
        entries = [e for e in self.store.all("customer_profiles") if e["customer_ref"] == customer_ref]
        return entries[-1]["profile"] if entries else None
