"""
Social Media Agents (5, per the spec's minimum).

Each is platform-specific and assumes the account was connected via that
platform's OFFICIAL OAuth/Business Login flow - no passwords are ever
stored or handled here. `access_token` must come from a real OAuth exchange.
Actual API calls are left as clearly-marked stubs: wire in the official
Graph API / Business API client for each platform once you have App Review
approval and the right permissions - this avoids the automation looking
like scraping or unsolicited bulk messaging, which would violate each
platform's terms of service.
"""
from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class _SocialMediaBase(BaseAgent):
    platform = "generic"

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        if action == f"social.{self.platform}.find_candidates":
            return self._find_candidates(task)
        if action == f"social.{self.platform}.analyze_profile":
            return self._analyze_profile(task)
        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _find_candidates(self, task: Dict[str, Any]) -> AgentResult:
        access_token = task.get("access_token")
        if not access_token:
            return AgentResult(
                agent_name=self.name, success=False,
                notes=f"No OAuth access_token for {self.platform}. Connect the account first.",
            )
        # Real implementation: call the platform's official Business/Graph API here.
        return AgentResult(agent_name=self.name, success=True, data={"candidates": []})

    def _analyze_profile(self, task: Dict[str, Any]) -> AgentResult:
        profile = task.get("profile", {})
        prompt = (
            f"Given this {self.platform} public profile summary, estimate whether "
            f"they're a plausible customer and why (one short paragraph): {profile}"
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"analysis": reply})


class FacebookAgent(_SocialMediaBase):
    name = "facebook_agent"
    platform = "facebook"
    capabilities = ["social.facebook.find_candidates", "social.facebook.analyze_profile"]


class InstagramAgent(_SocialMediaBase):
    name = "instagram_agent"
    platform = "instagram"
    capabilities = ["social.instagram.find_candidates", "social.instagram.analyze_profile"]


class TikTokAgent(_SocialMediaBase):
    name = "tiktok_agent"
    platform = "tiktok"
    capabilities = ["social.tiktok.find_candidates", "social.tiktok.analyze_profile"]


class LinkedInAgent(_SocialMediaBase):
    name = "linkedin_agent"
    platform = "linkedin"
    capabilities = ["social.linkedin.find_candidates", "social.linkedin.analyze_profile"]


class TwitterAgent(_SocialMediaBase):
    name = "twitter_agent"
    platform = "twitter"
    capabilities = ["social.twitter.find_candidates", "social.twitter.analyze_profile"]
