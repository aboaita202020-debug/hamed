from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class MarketCompetitorAgent(BaseAgent):
    """
    Analyzes competitors and rough market sizing. Pull real numbers via the
    Research Agent's web-search hook when available; this agent focuses on
    structuring the analysis and reasoning about it.
    """
    name = "market_competitor_agent"
    capabilities = ["market.analyze_competitor", "market.estimate_market_size"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "market.analyze_competitor":
            competitor = task.get("competitor", {})
            prompt = (
                f"Analyze this competitor: {competitor}. Cover: their likely "
                f"strengths, weaknesses, pricing position, and one gap we could "
                f"exploit. Keep it concise and specific, not generic."
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"analysis": reply})

        if action == "market.estimate_market_size":
            total_population = task.get("total_population", 0)
            target_pct = task.get("target_segment_pct", 0) / 100
            avg_spend = task.get("avg_annual_spend", 0)
            addressable_customers = total_population * target_pct
            market_size = addressable_customers * avg_spend
            return AgentResult(
                agent_name=self.name, success=True,
                data={
                    "addressable_customers": round(addressable_customers),
                    "estimated_market_size": round(market_size, 2),
                },
                notes="Rough top-down estimate - validate with real segment data before relying on it.",
            )

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
