"""
Registry of all Specialist Agents.

To scale from ~5 agents toward the 80+ target in the spec:
1. Create agents/your_new_agent.py with a class inheriting BaseAgent.
2. Import it below and add one line to AGENT_CLASSES.
The Orchestrator never needs to change - it routes by capability string.
"""
from agents.sales_agent import SalesAgent
from agents.purchasing_agent import PurchasingAgent
from agents.negotiation_agent import NegotiationAgent
from agents.research_agent import ResearchAgent
from agents.customer_hunter_agent import CustomerHunterAgent
from agents.affiliate_agent import AffiliateAgent
from agents.marketing_agent import MarketingAgent
from agents.customer_psychology_agent import CustomerPsychologyAgent
from agents.testimonials_agent import TestimonialsAgent
from agents.lead_generation_agent import LeadGenerationAgent
from agents.upsell_agent import UpsellAgent
from agents.websiteless_business_agent import WebsitelessBusinessAgent
from agents.video_content_agent import VideoContentAgent
from agents.import_export_agent import ImportExportAgent
from agents.manufacturing_agent import ManufacturingAgent
from agents.freelance_agent import FreelanceServicesAgent
from agents.partnership_marketplace_agent import PartnershipMarketplaceAgent
from agents.market_competitor_agent import MarketCompetitorAgent
from agents.product_builder_agent import ProductBuilderAgent
from agents.verification_agent import VerificationAgent
from agents.payment_agent import PaymentAgent
from agents.education_agents import (
    ProductEducationAgent,
    OnboardingEducationAgent,
    FaqEducationAgent,
    ObjectionEducationAgent,
    MarketEducationAgent,
)
from agents.social_media_agents import (
    FacebookAgent,
    InstagramAgent,
    TikTokAgent,
    LinkedInAgent,
    TwitterAgent,
)

AGENT_CLASSES = [
    SalesAgent,
    PurchasingAgent,
    NegotiationAgent,
    ResearchAgent,
    CustomerHunterAgent,
    AffiliateAgent,
    MarketingAgent,
    CustomerPsychologyAgent,
    TestimonialsAgent,
    LeadGenerationAgent,
    UpsellAgent,
    WebsitelessBusinessAgent,
    VideoContentAgent,
    ImportExportAgent,
    ManufacturingAgent,
    FreelanceServicesAgent,
    PartnershipMarketplaceAgent,
    MarketCompetitorAgent,
    ProductBuilderAgent,
    VerificationAgent,
    PaymentAgent,
    # Education (5)
    ProductEducationAgent,
    OnboardingEducationAgent,
    FaqEducationAgent,
    ObjectionEducationAgent,
    MarketEducationAgent,
    # Social Media (5)
    FacebookAgent,
    InstagramAgent,
    TikTokAgent,
    LinkedInAgent,
    TwitterAgent,
    # Add more here as you build them, following the same one-class-per-file pattern.
]


def build_agents(multi_brain, config=None, store=None, strategy_params=None, heygen_client=None):
    """
    Instantiate every registered agent with the shared multi-brain.
    `config` is optional and only consulted for agents that need extra,
    non-brain configuration (currently just PaymentAgent's Vodafone Cash number).
    `store` is optional and lets PaymentAgent log claims and CustomerPsychologyAgent
    accumulate per-customer profiles.
    `strategy_params` is optional and lets NegotiationAgent read tuning values
    the Self-Improvement Engine adjusts based on real close rates.
    `heygen_client` is optional and lets VideoContentAgent generate real UGC
    videos automatically instead of the free manual fallback.
    """
    agents = []
    for cls in AGENT_CLASSES:
        if cls is PaymentAgent:
            vodafone_number = getattr(config, "VODAFONE_CASH_NUMBER", "") if config else ""
            agents.append(PaymentAgent(multi_brain, vodafone_cash_number=vodafone_number or "", store=store))
        elif cls is CustomerPsychologyAgent:
            agents.append(CustomerPsychologyAgent(multi_brain, store=store))
        elif cls is TestimonialsAgent:
            agents.append(TestimonialsAgent(multi_brain, store=store))
        elif cls is NegotiationAgent:
            agents.append(NegotiationAgent(multi_brain, strategy_params=strategy_params))
        elif cls is VideoContentAgent:
            agents.append(VideoContentAgent(multi_brain, heygen_client=heygen_client))
        else:
            agents.append(cls(multi_brain))
    return agents
