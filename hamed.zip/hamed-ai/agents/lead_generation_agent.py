from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class LeadGenerationAgent(BaseAgent):
    """
    Two-sided matching: finds buyers for a seller's product, or suppliers
    for a buyer's need - the brokerage/B2B-matching part of the spec.
    """
    name = "lead_generation_agent"
    capabilities = ["leadgen.find_buyers_for_seller", "leadgen.find_suppliers_for_buyer"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "leadgen.find_buyers_for_seller":
            product = task.get("product", {})
            candidate_buyers: List[Dict[str, Any]] = task.get("candidate_buyers", [])
            matches = [b for b in candidate_buyers if self._matches(product, b.get("needs", {}))]
            return AgentResult(agent_name=self.name, success=True, data={"matches": matches})

        if action == "leadgen.find_suppliers_for_buyer":
            need = task.get("need", {})
            candidate_suppliers: List[Dict[str, Any]] = task.get("candidate_suppliers", [])
            matches = [s for s in candidate_suppliers if self._matches(s.get("offers", {}), need)]
            return AgentResult(agent_name=self.name, success=True, data={"matches": matches})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    @staticmethod
    def _matches(offer: Dict[str, Any], need: Dict[str, Any]) -> bool:
        """
        Simple category + budget match. Replace with embeddings/semantic
        matching once you have enough real data to justify it.
        """
        if not offer or not need:
            return False
        same_category = offer.get("category") == need.get("category")
        within_budget = offer.get("price", 0) <= need.get("max_budget", float("inf"))
        return same_category and within_budget
