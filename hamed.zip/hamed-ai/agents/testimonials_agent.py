from typing import Any, Dict, List, Optional
from agents.base_agent import BaseAgent, AgentResult

# This agent exists specifically to make the "never fabricate testimonials"
# rule in sales_agent.py and marketing_agent.py actually usable in practice:
# those agents refuse to invent social proof, so this agent collects REAL
# customer feedback (with explicit opt-in) that they can reference instead.
FEEDBACK_REQUEST_PERSONA = (
    "You are Hamed, asking a customer for honest feedback after a positive "
    "interaction. Keep it short, warm, and low-pressure. Explicitly ask "
    "whether it's okay to share their feedback publicly - never assume "
    "permission. If they say no, that's completely fine and should be "
    "respected without pushing."
)


class TestimonialsAgent(BaseAgent):
    """
    Collects real customer testimonials (with explicit permission) and makes
    approved ones available to SalesAgent/MarketingAgent as `real_proof` -
    never as fabricated social proof, only as what a customer actually said
    and agreed to share.
    """
    name = "testimonials_agent"
    capabilities = [
        "testimonial.request_feedback",
        "testimonial.record",
        "testimonial.list_approved",
        "testimonial.format_for_marketing",
    ]

    def __init__(self, multi_brain, store=None):
        super().__init__(multi_brain)
        self.store = store  # required for record/list - testimonials must persist

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "testimonial.request_feedback":
            return self._request_feedback(task)
        if action == "testimonial.record":
            return self._record(task)
        if action == "testimonial.list_approved":
            return self._list_approved()
        if action == "testimonial.format_for_marketing":
            return self._format_for_marketing(task)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _request_feedback(self, task: Dict[str, Any]) -> AgentResult:
        context = task.get("context", "the recent interaction")
        prompt = (
            f"{FEEDBACK_REQUEST_PERSONA}\n"
            f"Write a short message asking the customer for their honest "
            f"feedback about: {context}. Explicitly ask if it's ok to share "
            f"their words publicly (e.g. on social media) - make it clear "
            f"saying no is completely fine."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})

    def _record(self, task: Dict[str, Any]) -> AgentResult:
        if self.store is None:
            return AgentResult(
                agent_name=self.name, success=False,
                notes="No store wired in - testimonials need persistence to be reused later.",
            )

        customer_ref = task.get("customer_ref")
        text = task.get("text", "").strip()
        if not customer_ref or not text:
            return AgentResult(agent_name=self.name, success=False, notes="customer_ref and text are both required.")

        # Permission defaults to False (not True) - silence or ambiguity must
        # never be treated as consent to use someone's words publicly.
        permission_granted = bool(task.get("permission_granted", False))
        business_context = task.get("business_context", "")

        record = {
            "customer_ref": customer_ref,
            "text": text,
            "permission_granted": permission_granted,
            "business_context": business_context,
        }
        self.store.insert("testimonials", record)
        return AgentResult(agent_name=self.name, success=True, data=record)

    def _list_approved(self) -> AgentResult:
        if self.store is None:
            return AgentResult(agent_name=self.name, success=True, data={"testimonials": []})
        approved = [e for e in self.store.all("testimonials") if e.get("permission_granted")]
        return AgentResult(agent_name=self.name, success=True, data={"testimonials": approved})

    def _format_for_marketing(self, task: Dict[str, Any]) -> AgentResult:
        approved = self._list_approved().data["testimonials"]
        if not approved:
            return AgentResult(
                agent_name=self.name, success=True,
                data={"real_proof": None},
                notes="No approved testimonials yet - marketing/sales agents will write around the offer's real value instead of inventing one.",
            )

        business_context = task.get("business_context", "")
        candidates = approved
        if business_context:
            matching = [e for e in approved if business_context.lower() in e.get("business_context", "").lower()]
            if matching:
                candidates = matching

        chosen = candidates[-1]  # most recent matching (or most recent overall)
        real_proof = f"\"{chosen['text']}\" - {chosen['customer_ref']}"
        return AgentResult(agent_name=self.name, success=True, data={"real_proof": real_proof, "source": chosen})
