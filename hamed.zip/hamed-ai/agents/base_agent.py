"""
Base class for all Specialist Agents.

The Orchestrator routes tasks by `capability`, not by agent name, so adding
new agents (to go from ~5 agents toward the 80+ target in the spec) never
requires touching the Orchestrator - just implement BaseAgent and register it.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class AgentResult:
    agent_name: str
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    requires_approval: bool = False
    notes: str = ""


class BaseAgent(ABC):
    #: capabilities this agent can handle, e.g. ["sales.close_deal", "sales.followup"]
    capabilities: List[str] = []
    name: str = "base_agent"

    def __init__(self, multi_brain):
        self.multi_brain = multi_brain

    @abstractmethod
    def handle(self, task: Dict[str, Any]) -> AgentResult:
        """Execute the task and return a structured result."""
        raise NotImplementedError

    def think(self, prompt: str) -> str:
        """Convenience wrapper to call the multi-brain with fallback baked in."""
        response = self.multi_brain.ask(prompt)
        return response.text
