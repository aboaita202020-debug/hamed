from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult

UGC_PERSONA = (
    "You are Hamed, writing a UGC-style (user-generated-content) video script - "
    "the kind that looks like a real person talking casually to camera, not a "
    "polished studio ad. Use natural, conversational language, first-person "
    "phrasing ('I tried this...', 'ok so...'), and a hook in the first 2 seconds. "
    "Never invent fake personal experiences, results, or reviews as if they were "
    "real - write it as a script template the business owner or an actor reads, "
    "not as a fabricated testimonial."
)


class VideoContentAgent(BaseAgent):
    """
    Scripts and storyboards for short-form video (ads, product demos, social
    reels), plus optional automated UGC-style AI avatar video generation via
    HeyGen. Without a HeyGen client configured, `video.generate_ugc_video`
    falls back to a free manual path: it hands you the script and clear
    instructions to paste into HeyGen's free web plan (3 videos/month, no
    card needed) yourself - see integrations/heygen_client.py for the cost
    reality on the API tier.
    """
    name = "video_content_agent"
    capabilities = ["video.write_script", "video.suggest_storyboard", "video.generate_ugc_video"]

    def __init__(self, multi_brain, heygen_client=None):
        super().__init__(multi_brain)
        self.heygen_client = heygen_client  # optional - see class docstring

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        product = task.get("product", {})
        platform = task.get("platform", "generic")
        duration_seconds = task.get("duration_seconds", 30)

        if action == "video.write_script":
            prompt = (
                f"Write a {duration_seconds}-second video ad script for '{platform}' "
                f"promoting: {product}. Include spoken lines and short scene directions."
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"script": reply})

        if action == "video.suggest_storyboard":
            prompt = (
                f"Break this into a shot-by-shot storyboard (shot number, visual, "
                f"on-screen text) for a {duration_seconds}s video about: {product}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"storyboard": reply})

        if action == "video.generate_ugc_video":
            return self._generate_ugc_video(task, product, duration_seconds)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _generate_ugc_video(self, task: Dict[str, Any], product: Dict[str, Any], duration_seconds: int) -> AgentResult:
        prompt = (
            f"{UGC_PERSONA}\n"
            f"Write a {duration_seconds}-second UGC-style script promoting: {product}."
        )
        script = self.think(prompt)

        if self.heygen_client is None:
            return AgentResult(
                agent_name=self.name,
                success=True,
                data={
                    "mode": "manual_free",
                    "script": script,
                    "instructions": (
                        "روحي على heygen.com، اعملي حساب مجاني (3 فيديوهات/شهر من غير "
                        "بطاقة ائتمان)، اختاري أفاتار، الصقي السكريبت ده، واختاري صوت "
                        "عربي. هتاخد دقيقتين وتطلعلك فيديو UGC حقيقي - بعلامة مائية في "
                        "الخطة المجانية."
                    ),
                },
            )

        avatar_id = task.get("avatar_id", "default")
        voice_id = task.get("voice_id", "default")
        try:
            result = self.heygen_client.generate_video(script, avatar_id, voice_id)
        except Exception as e:  # noqa: BLE001
            return AgentResult(
                agent_name=self.name, success=False,
                data={"script": script}, notes=f"HeyGen API call failed: {e}",
            )

        if result["status"] == "completed":
            return AgentResult(
                agent_name=self.name, success=True,
                data={"mode": "automated", "script": script, "video_url": result["video_url"]},
            )
        return AgentResult(
            agent_name=self.name, success=False,
            data={"script": script}, notes=f"Video generation {result['status']}: {result.get('reason', '')}",
        )
