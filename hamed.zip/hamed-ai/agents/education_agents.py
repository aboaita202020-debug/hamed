"""
Education Agents (5, per the spec's minimum).

Each specializes in explaining a different kind of information to the
customer, using the shared multi-brain for the actual writing.
"""
from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class _EducationBase(BaseAgent):
    topic_kind = "general"

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        if action != f"education.{self.topic_kind}":
            return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

        subject = task.get("subject", "")
        audience = task.get("audience", "a potential customer")
        prompt = self._build_prompt(subject, audience)
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"explanation": reply})

    def _build_prompt(self, subject: str, audience: str) -> str:
        raise NotImplementedError


class ProductEducationAgent(_EducationBase):
    name = "product_education_agent"
    topic_kind = "product"
    capabilities = ["education.product"]

    def _build_prompt(self, subject, audience):
        return (
            f"Explain this product/feature to {audience} in simple, clear terms, "
            f"focusing on the benefit not just the spec: {subject}"
        )


class OnboardingEducationAgent(_EducationBase):
    name = "onboarding_education_agent"
    topic_kind = "onboarding"
    capabilities = ["education.onboarding"]

    def _build_prompt(self, subject, audience):
        return f"Write a short step-by-step onboarding guide for {audience} covering: {subject}"


class FaqEducationAgent(_EducationBase):
    name = "faq_education_agent"
    topic_kind = "faq"
    capabilities = ["education.faq"]

    def _build_prompt(self, subject, audience):
        return f"Answer this frequently asked question clearly for {audience}: {subject}"


class ObjectionEducationAgent(_EducationBase):
    name = "objection_education_agent"
    topic_kind = "objection"
    capabilities = ["education.objection"]

    def _build_prompt(self, subject, audience):
        return (
            f"Educate {audience} on why this common concern is often a misconception, "
            f"backed by a simple, honest explanation (not a hard sell): {subject}"
        )


class MarketEducationAgent(_EducationBase):
    name = "market_education_agent"
    topic_kind = "market"
    capabilities = ["education.market"]

    def _build_prompt(self, subject, audience):
        return f"Explain this market/industry trend to {audience} and why it matters to them: {subject}"
