from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class AffiliateAgent(BaseAgent):
    """
    Finds and manages affiliate opportunities: matches products/services with
    potential affiliate partners, tracks commission structures, and ranks
    programs by expected payout.
    """
    name = "affiliate_agent"
    capabilities = ["affiliate.find_programs", "affiliate.calc_commission"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "affiliate.find_programs":
            # Plug real affiliate network APIs here (e.g. Amazon Associates,
            # ShareASale, Impact, ClickBank) once you have credentials.
            candidates: List[Dict[str, Any]] = task.get("candidate_programs", [])
            ranked = sorted(
                candidates,
                key=lambda p: p.get("commission_rate", 0) * p.get("avg_order_value", 0),
                reverse=True,
            )
            return AgentResult(agent_name=self.name, success=True, data={"ranked_programs": ranked})

        if action == "affiliate.calc_commission":
            sale_amount = task.get("sale_amount", 0)
            rate = task.get("commission_rate", 0)
            commission = round(sale_amount * rate, 2)
            return AgentResult(
                agent_name=self.name, success=True,
                data={"sale_amount": sale_amount, "rate": rate, "commission": commission},
            )

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
