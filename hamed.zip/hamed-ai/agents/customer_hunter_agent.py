from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class CustomerHunterAgent(BaseAgent):
    """
    Find -> Analyze -> Qualify -> Contact -> Follow-up -> Convert.

    IMPORTANT: per the spec, no platform passwords are ever stored. This
    agent assumes accounts are connected through each platform's official
    OAuth flow (Meta Graph API / Business Login, TikTok for Business API),
    and that outreach uses each platform's official messaging APIs.
    Automated mass-contact that bypasses a platform's terms of service
    (scraping, unsolicited bulk messaging) is out of scope - connect the
    real OAuth token in `access_token` and use the platform's own rate
    limits and messaging permissions.
    """
    name = "customer_hunter_agent"
    capabilities = ["hunter.find_candidates", "hunter.qualify"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "hunter.qualify":
            candidates: List[Dict[str, Any]] = task.get("candidates", [])
            qualified = [c for c in candidates if self._is_qualified(c)]
            return AgentResult(
                agent_name=self.name, success=True, data={"qualified": qualified}
            )

        if action == "hunter.find_candidates":
            platform = task.get("platform")
            access_token = task.get("access_token")
            if not access_token:
                return AgentResult(
                    agent_name=self.name,
                    success=False,
                    notes=(
                        f"No OAuth access_token provided for {platform}. "
                        f"Connect the account via official OAuth first."
                    ),
                )
            # Real implementation: call platform's official Graph/Business API here.
            return AgentResult(agent_name=self.name, success=True, data={"candidates": []})

        return AgentResult(
            agent_name=self.name, success=False, notes=f"Unknown action: {action}"
        )

    @staticmethod
    def _is_qualified(candidate: Dict[str, Any]) -> bool:
        return bool(candidate.get("expressed_interest") or candidate.get("budget", 0) > 0)
