from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class ManufacturingAgent(BaseAgent):
    """
    Evaluates factories/production partners and estimates unit production
    cost at different order volumes (simple economies-of-scale model).
    """
    name = "manufacturing_agent"
    capabilities = ["manufacturing.evaluate_factory", "manufacturing.estimate_unit_cost"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "manufacturing.evaluate_factory":
            factories: List[Dict[str, Any]] = task.get("factories", [])
            scored = []
            for f in factories:
                # Simple weighted score: lower cost, lower MOQ, higher rating = better.
                cost = f.get("unit_cost", 0)
                moq = f.get("moq", 0)
                rating = f.get("rating", 0)  # 0-5
                score = rating * 20 - (cost * 0.5) - (moq * 0.001)
                scored.append({**f, "score": round(score, 2)})
            scored.sort(key=lambda x: x["score"], reverse=True)
            return AgentResult(agent_name=self.name, success=True, data={"ranked_factories": scored})

        if action == "manufacturing.estimate_unit_cost":
            base_cost = task.get("base_unit_cost", 0)
            base_volume = task.get("base_volume", 1)
            order_volume = task.get("order_volume", base_volume)
            # Very simple economies-of-scale curve - replace with real supplier
            # quotes once available.
            discount = min(0.3, 0.05 * (order_volume / base_volume - 1)) if base_volume else 0
            discount = max(discount, 0)
            estimated_unit_cost = round(base_cost * (1 - discount), 4)
            return AgentResult(
                agent_name=self.name, success=True,
                data={"estimated_unit_cost": estimated_unit_cost, "discount_applied": round(discount, 3)},
            )

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
