from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class VerificationAgent(BaseAgent):
    """
    Protection layer: flags suspicious deals/counterparties before they reach
    execution. Complements ApprovalLayer (which gates by amount) by gating
    on risk signals instead (new counterparty + high amount, mismatched
    shipping/billing info, unusually urgent pressure tactics, etc.).
    This agent flags for human review - it never blocks silently or acts
    on the person's behalf.
    """
    name = "verification_agent"
    capabilities = ["verify.check_deal_risk", "verify.check_counterparty"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "verify.check_deal_risk":
            return self._check_deal_risk(task)

        if action == "verify.check_counterparty":
            return self._check_counterparty(task)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _check_deal_risk(self, task: Dict[str, Any]) -> AgentResult:
        amount = task.get("amount", 0)
        is_new_counterparty = task.get("is_new_counterparty", False)
        urgency_flag = task.get("urgency_pressure", False)
        shipping_billing_mismatch = task.get("shipping_billing_mismatch", False)

        flags: List[str] = []
        if is_new_counterparty and amount > task.get("new_counterparty_review_threshold", 200):
            flags.append("New counterparty with an amount above the review threshold.")
        if urgency_flag:
            flags.append("Unusual urgency/pressure detected - common in scam patterns.")
        if shipping_billing_mismatch:
            flags.append("Shipping and billing details don't match.")

        risk_level = "high" if len(flags) >= 2 else "medium" if flags else "low"
        return AgentResult(
            agent_name=self.name,
            success=True,
            requires_approval=(risk_level in ("high", "medium")),
            data={"risk_level": risk_level, "flags": flags},
        )

    def _check_counterparty(self, task: Dict[str, Any]) -> AgentResult:
        counterparty = task.get("counterparty", {})
        prompt = (
            f"Given this counterparty info, list any red flags worth checking "
            f"before doing business with them (don't invent facts, just point out "
            f"what's missing or inconsistent): {counterparty}"
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"review_notes": reply})
