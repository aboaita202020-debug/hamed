from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class ResearchAgent(BaseAgent):
    """
    Opportunity Hunter: ranks leads/opportunities by estimated value and
    closing probability. Actual web/social search calls should be plugged
    into `_search` (this stub keeps the module runnable without network
    access or platform API keys configured).
    """
    name = "research_agent"
    capabilities = ["research.find_opportunities", "research.rank_leads"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "research.rank_leads":
            leads: List[Dict[str, Any]] = task.get("leads", [])
            ranked = sorted(
                leads,
                key=lambda l: l.get("estimated_value", 0) * l.get("close_probability", 0),
                reverse=True,
            )
            return AgentResult(agent_name=self.name, success=True, data={"ranked_leads": ranked})

        if action == "research.find_opportunities":
            query = task.get("query", "")
            results = self._search(query)
            return AgentResult(agent_name=self.name, success=True, data={"results": results})

        return AgentResult(
            agent_name=self.name, success=False, notes=f"Unknown action: {action}"
        )

    def _search(self, query: str) -> List[Dict[str, Any]]:
        """
        Plug in real sources here: web search API, marketplace APIs, or
        official social-platform Business APIs (after OAuth). Left as a stub
        so the module has no hard dependency on network access.
        """
        return []
