from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class FreelanceServicesAgent(BaseAgent):
    """
    Matches freelance talent to projects by skill overlap and budget fit,
    and gives a rough price estimate for a described project.
    """
    name = "freelance_services_agent"
    capabilities = ["freelance.match_talent_to_project", "freelance.estimate_project_price"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "freelance.match_talent_to_project":
            project = task.get("project", {})
            required_skills = set(project.get("required_skills", []))
            candidates: List[Dict[str, Any]] = task.get("candidates", [])

            matches = []
            for c in candidates:
                skills = set(c.get("skills", []))
                overlap = len(required_skills & skills)
                if overlap == 0:
                    continue
                fit_score = overlap / len(required_skills) if required_skills else 0
                within_budget = c.get("rate", 0) <= project.get("max_budget", float("inf"))
                matches.append({**c, "fit_score": round(fit_score, 2), "within_budget": within_budget})

            matches.sort(key=lambda m: (m["within_budget"], m["fit_score"]), reverse=True)
            return AgentResult(agent_name=self.name, success=True, data={"matches": matches})

        if action == "freelance.estimate_project_price":
            project = task.get("project", {})
            prompt = (
                f"Estimate a fair freelance price range (low-high) for this project "
                f"and briefly justify it based on scope and typical market rates: {project}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"estimate": reply})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
