from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class UpsellAgent(BaseAgent):
    """Suggests bundles, upsells, and cross-sells to raise deal value."""
    name = "upsell_agent"
    capabilities = ["upsell.suggest_bundle", "upsell.suggest_cross_sell"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "upsell.suggest_bundle":
            cart: List[Dict[str, Any]] = task.get("cart", [])
            catalog: List[Dict[str, Any]] = task.get("catalog", [])
            cart_categories = {item.get("category") for item in cart}
            complements = [
                p for p in catalog
                if p.get("complements_category") in cart_categories
                and p not in cart
            ]
            return AgentResult(agent_name=self.name, success=True, data={"bundle_suggestions": complements})

        if action == "upsell.suggest_cross_sell":
            product = task.get("product", {})
            prompt = (
                f"A customer just bought/is considering: {product}. "
                f"Suggest one natural cross-sell item and a one-line reason why it "
                f"pairs well, without being pushy."
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"suggestion": reply})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
