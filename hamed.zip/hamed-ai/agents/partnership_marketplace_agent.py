from typing import Any, Dict, List
from agents.base_agent import BaseAgent, AgentResult


class PartnershipMarketplaceAgent(BaseAgent):
    """
    Evaluates potential business partners/marketplace listings by a simple
    alignment score (shared audience, complementary offering, reliability).
    """
    name = "partnership_marketplace_agent"
    capabilities = ["partnership.evaluate_partner", "marketplace.rank_listings"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "partnership.evaluate_partner":
            partner = task.get("partner", {})
            audience_overlap = partner.get("audience_overlap_pct", 0)  # 0-100
            reliability = partner.get("reliability_score", 0)  # 0-5
            complementary = partner.get("complementary", False)

            score = (audience_overlap * 0.3) + (reliability * 10) + (20 if complementary else 0)
            recommendation = "pursue" if score >= 50 else "monitor" if score >= 25 else "pass"

            return AgentResult(
                agent_name=self.name, success=True,
                data={"score": round(score, 1), "recommendation": recommendation},
            )

        if action == "marketplace.rank_listings":
            listings: List[Dict[str, Any]] = task.get("listings", [])
            ranked = sorted(
                listings,
                key=lambda l: l.get("expected_value", 0) * l.get("win_probability", 0),
                reverse=True,
            )
            return AgentResult(agent_name=self.name, success=True, data={"ranked_listings": ranked})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
