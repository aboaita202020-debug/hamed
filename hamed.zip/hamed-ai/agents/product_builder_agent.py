from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class ProductBuilderAgent(BaseAgent):
    """
    Validates a product/SaaS idea against basic viability signals and drafts
    a minimal MVP spec. This is an ideation/planning aid, not a guarantee -
    real validation still needs actual customer conversations.
    """
    name = "product_builder_agent"
    capabilities = ["product.validate_idea", "product.draft_mvp_spec"]

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "product.validate_idea":
            idea = task.get("idea", {})
            prompt = (
                f"Evaluate this product/SaaS idea for basic viability: {idea}. "
                f"Cover: is there a clear painful problem, who exactly has it, "
                f"would they pay, and the biggest risk. Be direct, not encouraging by default."
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"validation": reply})

        if action == "product.draft_mvp_spec":
            idea = task.get("idea", {})
            prompt = (
                f"Draft a minimal MVP spec for this idea: {idea}. Include: "
                f"core feature (just one), what's explicitly out of scope for v1, "
                f"and the single metric that would tell us it's working."
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"mvp_spec": reply})

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")
