from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult


class WebsitelessBusinessAgent(BaseAgent):
    """
    Services for businesses that don't have a website or online store:
    generates landing-page copy, a content brief, a basic e-commerce
    product-catalog structure, and (optionally, for free) real product images.
    """
    name = "websiteless_business_agent"
    capabilities = [
        "website.generate_landing_copy",
        "website.generate_content_brief",
        "store.generate_product_catalog_page",
        "store.generate_product_image",
    ]

    def __init__(self, multi_brain, gemini_image_client=None):
        super().__init__(multi_brain)
        # Optional - reuses the SAME GEMINI_API_KEY as the AI brain, no
        # separate signup needed. See integrations/gemini_image_client.py.
        self.gemini_image_client = gemini_image_client

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        business = task.get("business", {})

        if action == "website.generate_landing_copy":
            prompt = (
                f"Write landing page copy (headline, 3 bullet benefits, one CTA) "
                f"for this business, which currently has no website: {business}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"landing_copy": reply})

        if action == "website.generate_content_brief":
            prompt = (
                f"Create a short content brief (sections + what goes in each) for a "
                f"one-page website for this business: {business}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"brief": reply})

        if action == "store.generate_product_catalog_page":
            products = task.get("products", [])
            prompt = (
                f"Write short, benefit-focused product descriptions (1-2 sentences "
                f"each) for an online store catalog page, for this business "
                f"{business}, products: {products}"
            )
            reply = self.think(prompt)
            return AgentResult(agent_name=self.name, success=True, data={"catalog_copy": reply})

        if action == "store.generate_product_image":
            return self._generate_product_image(task)

        return AgentResult(agent_name=self.name, success=False, notes=f"Unknown action: {action}")

    def _generate_product_image(self, task: Dict[str, Any]) -> AgentResult:
        if self.gemini_image_client is None:
            return AgentResult(
                agent_name=self.name, success=False,
                notes=(
                    "GEMINI_API_KEY not configured - product image generation needs it. "
                    "If you're already using Gemini as your AI brain, this works with "
                    "zero extra signup - just make sure the key is set."
                ),
            )

        product_description = task.get("product_description", "")
        aspect_ratio = task.get("aspect_ratio", "1:1")
        prompt = (
            f"A clean, professional product photo of: {product_description}. "
            f"Simple neutral background, good lighting, e-commerce catalog style."
        )
        try:
            image_base64 = self.gemini_image_client.generate_image_base64(prompt, aspect_ratio)
        except Exception as e:  # noqa: BLE001
            return AgentResult(agent_name=self.name, success=False, notes=f"Image generation failed: {e}")

        return AgentResult(
            agent_name=self.name, success=True,
            data={"image_base64": image_base64, "format": "png"},
        )
