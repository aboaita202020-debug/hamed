from typing import Any, Dict
from agents.base_agent import BaseAgent, AgentResult

# Same idea as SalesAgent's persona: a professional negotiator concedes in
# TRADES (never for free), anchors before conceding, and reframes price
# pushback around value/bundles instead of just dropping the number. No
# fabricated deadlines or fake competing offers - that's manipulation, not
# negotiation, and it erodes trust the moment the customer notices.
NEGOTIATION_PERSONA = (
    "You are Hamed, a professional negotiator representing the business. "
    "Core rules: never concede price without asking for something in return "
    "(a bundle, a longer commitment, a referral, faster payment); reframe "
    "price pushback around the value/outcome delivered, not just the number; "
    "sound calm and confident, never anxious to close; never invent a fake "
    "deadline, a fake competing offer, or fake scarcity to pressure the other side."
)


class NegotiationAgent(BaseAgent):
    name = "negotiation_agent"
    capabilities = ["negotiation.counter_offer", "negotiation.evaluate_offer"]

    def __init__(self, multi_brain, strategy_params=None):
        super().__init__(multi_brain)
        # strategy_params is optional so this agent still works standalone in
        # tests/scripts. When wired (see registry.py), the Self-Improvement
        # Engine can tune how much Hamed concedes based on real close rates.
        self.strategy_params = strategy_params

    def handle(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")

        if action == "negotiation.evaluate_offer":
            return self._evaluate_offer(task)

        if action == "negotiation.counter_offer":
            return self._counter_offer(task)

        return AgentResult(
            agent_name=self.name, success=False, notes=f"Unknown action: {action}"
        )

    def _evaluate_offer(self, task: Dict[str, Any]) -> AgentResult:
        asking_price = task.get("asking_price", 0)
        min_acceptable = task.get("min_acceptable_price", 0)
        offer = task.get("offer", 0)
        concession_ratio = self._get_concession_ratio()

        if offer >= asking_price:
            decision, counter = "accept", None
        elif offer >= min_acceptable:
            decision, counter = "accept", None
        else:
            decision = "counter"
            # concession_ratio=0.5 meets exactly in the middle (old fixed
            # behavior). Closer to 1.0 concedes more toward the offer
            # (closes more deals, thinner margins); closer to 0.0 holds
            # firm near min_acceptable (fewer deals, better margins).
            # The Self-Improvement Engine nudges this based on real outcomes.
            counter = round(offer + (min_acceptable - offer) * (1 - concession_ratio), 2)

        return AgentResult(
            agent_name=self.name,
            success=True,
            data={"decision": decision, "counter_offer": counter, "concession_ratio_used": concession_ratio},
        )

    def _counter_offer(self, task: Dict[str, Any]) -> AgentResult:
        offer = task.get("offer")
        min_acceptable = task.get("min_acceptable_price")
        customer_profile = task.get("customer_profile", "")
        profile_note = f"What we know about this customer: {customer_profile}" if customer_profile else ""

        prompt = (
            f"{NEGOTIATION_PERSONA}\n"
            f"Customer offer: {offer}. Our minimum acceptable price: {min_acceptable}. {profile_note}\n"
            f"Write a short counter-offer message. Do NOT just propose a lower "
            f"number - propose a specific trade (e.g. 'I can do that price if we "
            f"lock in a 3-month commitment' or 'I can add X at that price instead "
            f"of lowering it further'). Keep it warm but firm."
        )
        reply = self.think(prompt)
        return AgentResult(agent_name=self.name, success=True, data={"reply": reply})

    def _get_concession_ratio(self) -> float:
        if self.strategy_params is None:
            return 0.5
        return float(self.strategy_params.get("negotiation.concession_ratio", 0.5))
