"""
HamedOrchestrator: the single entry point tasks flow through.

Fixes the ImportError from the spec's error log by giving this class its own
module and an explicit __init__.py export (see orchestrator/__init__.py).
"""
import logging
from typing import Any, Callable, Dict, List, Optional

from agents.base_agent import AgentResult, BaseAgent
from approvals.approval_layer import ApprovalLayer

logger = logging.getLogger("hamed.orchestrator")


class HamedOrchestrator:
    def __init__(self, agents: List[BaseAgent], approval_layer: Optional[ApprovalLayer] = None):
        self.approval_layer = approval_layer or ApprovalLayer()
        self._capability_map: Dict[str, BaseAgent] = {}
        for agent in agents:
            for capability in agent.capabilities:
                if capability in self._capability_map:
                    logger.warning(
                        "Capability '%s' claimed by both %s and %s - keeping the first.",
                        capability, self._capability_map[capability].name, agent.name,
                    )
                    continue
                self._capability_map[capability] = agent

        # Hook for the Learning Council / analytics layer to observe every result.
        self._on_task_complete_hooks: List[Callable[[Dict[str, Any], AgentResult], None]] = []

    def on_task_complete(self, hook: Callable[[Dict[str, Any], AgentResult], None]) -> None:
        """Register a callback, e.g. for the Learning Council to log outcomes."""
        self._on_task_complete_hooks.append(hook)

    def available_capabilities(self) -> List[str]:
        return sorted(self._capability_map.keys())

    def run(self, task: Dict[str, Any]) -> AgentResult:
        action = task.get("action")
        agent = self._capability_map.get(action)

        if agent is None:
            result = AgentResult(
                agent_name="orchestrator",
                success=False,
                notes=f"No agent registered for action '{action}'.",
            )
            return result

        try:
            result = agent.handle(task)
        except Exception as e:  # noqa: BLE001
            logger.exception("Agent '%s' raised an exception handling '%s'", agent.name, action)
            result = AgentResult(
                agent_name=agent.name, success=False, notes=f"Agent error: {e}"
            )

        result = self.approval_layer.process(result)

        for hook in self._on_task_complete_hooks:
            try:
                hook(task, result)
            except Exception:  # noqa: BLE001
                logger.exception("on_task_complete hook raised an exception")

        return result
