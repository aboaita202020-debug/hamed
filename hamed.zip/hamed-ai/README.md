# Hamed AI — Autonomous Commercial Agent System

هذا هو الأساس التقني (foundation) لمشروع Hamed AI طبقًا لمواصفات الـ Master Spec. المشروع مبني بطريقة قابلة للتوسع
(registry pattern) عشان تقدر تزود عدد الـ Specialist Agents من ٥ لحد ٨٠+ من غير ما تلمس الأساس (Orchestrator,
Multi-Brain, Approval Layer, Communication Layer).

## البنية

```
hamed-ai/
├── bot.py                     # نقطة التشغيل الرئيسية (Telegram + Dashboard)
├── config.py                  # تحميل Environment Variables (Required vs Optional)
├── requirements.txt
├── .env.example
├── orchestrator/
│   └── hamed_orchestrator.py  # HamedOrchestrator: يوزّع المهام على الوكلاء
├── brains/
│   └── multi_brain.py         # OpenAI → Claude → DeepSeek → Gemini → Kimi (Fallback)
├── agents/
│   ├── base_agent.py          # كل وكيل بيرث من هنا
│   ├── sales_agent.py
│   ├── purchasing_agent.py
│   ├── negotiation_agent.py
│   ├── research_agent.py
│   ├── customer_hunter_agent.py
│   ├── affiliate_agent.py
│   ├── marketing_agent.py
│   ├── customer_psychology_agent.py
│   ├── lead_generation_agent.py
│   ├── upsell_agent.py
│   ├── websiteless_business_agent.py  # مواقع + متاجر (landing + catalog)
│   ├── video_content_agent.py
│   ├── import_export_agent.py
│   ├── manufacturing_agent.py
│   ├── freelance_agent.py
│   ├── partnership_marketplace_agent.py
│   ├── market_competitor_agent.py
│   ├── product_builder_agent.py
│   ├── verification_agent.py  # فحص مخاطر الصفقات - حماية وتحقق
│   ├── payment_agent.py       # Vodafone Cash - تأكيد يدوي (مفيش API عام للتحقق الأوتوماتيكي)
│   ├── education_agents.py    # 5 وكلاء: product/onboarding/faq/objection/market
│   ├── social_media_agents.py # 5 وكلاء: facebook/instagram/tiktok/linkedin/twitter
│   └── registry.py            # سجل الوكلاء - ٢٩ وكيل مسجل حاليًا، إضافة وكيل = سطر واحد
├── approvals/
│   └── approval_layer.py      # Safety/Approval Layer للقرارات المالية الكبرى
├── learning/
│   └── learning_council.py    # Learning Council: بيحلل نتائج كل الوكلاء ويطلع توصيات
├── research_team/
│   └── client_research_team.py # Client Research Team: qualify + rank leads
├── management/
│   ├── board.py                # Board/Management layer: بيقسّم Goal لسلسلة مهام (playbooks)
│   ├── revenue_engine.py        # Revenue Engine: بيتتبع الدخل من كل مصدر تجاه هدف $1000/يوم
│   ├── experiment_engine.py     # Scale/Iterate/Kill decisions من metrics حقيقية
│   ├── venture_studio.py        # محفظة مشاريع متعددة، كل واحد بـ Revenue خاص بيه
│   ├── decision_engine.py       # 🧠 التفكير الذاتي: Think→Act→Observe loop يقرر بنفسه الخطوة الجاية
│   ├── self_reflection.py       # يراجع كل run ويطلع درس مختصر - مش مجرد "خلصنا"
│   ├── outreach_queue.py        # بوابة موافقة قبل التواصل مع أي غريب - يحمي الحساب من الحظر
│   ├── hunting_pipeline.py      # ColdOutreachHunter: يدور، يكتب رسالة، يحطها في الـ queue
│   └── sheets_sync.py           # يزامن جداول القاعدة مع Google Sheets عند الطلب
├── channels/
│   ├── whatsapp_channel.py    # WhatsApp عبر Twilio - None تلقائيًا لو مش متظبط
│   └── voice_channel.py       # مكالمات صوتية عبر Twilio - None تلقائيًا لو مش متظبط
├── database/
│   └── db.py                  # طبقة قاعدة بيانات اختيارية (DATABASE_URL optional)
├── server/
│   └── dashboard.py           # FastAPI: /dashboard (بيعرض الـ Revenue Progress) و /health
├── Dockerfile
├── docker-compose.yml
├── .github/workflows/tests.yml # CI + workflow_dispatch (تشغيل يدوي) زي المواصفات
└── tests/
    ├── test_multi_brain_fallback.py
    ├── test_orchestrator.py
    ├── test_agents.py
    ├── test_approval_layer.py
    ├── test_expanded_agents.py   # affiliate/marketing/education/social/learning/research team
    ├── test_management_layer.py  # psychology/leadgen/upsell/websiteless/board/revenue
    ├── test_domain_coverage.py   # video/trade/manufacturing/freelance/partnership/market/product/verification
    ├── test_decision_engine.py   # 🧠 التفكير الذاتي - Think/Act/Observe loop
    ├── test_hunting_and_payments.py  # payment agent + outreach queue + cold outreach hunter
    ├── test_database.py          # SQLite persistence (insert/all/reconnect/unsafe names)
    └── test_google_sheets.py      # SheetsSync + PaymentAgent store logging
├── scripts/
│   └── check_readiness.py     # شغّلها قبل أي Deploy - فحص شامل قبل الرفع
├── integrations/
│   └── google_sheets_client.py   # Google Sheets sync (Service Account)
├── .gitignore
```

**إجمالي دلوقتي: 31 Specialist Agent مسجلين، 72 capability شغالة، Board/Revenue/Experiment/Venture Studio + Decision Engine + Outreach Queue + Google Sheets + Self-Improvement Loop + Proactive Scanner + Voice Calls + WhatsApp الذكي + منهجية بيع/تفاوض/تسويق/شراء احترافية + فيديوهات UGC + شهادات عملاء حقيقية، اتفحصوا كلهم بـ 172 اختبار ناجح 100%.**

## ⭐ شهادات عملاء حقيقية — تكمّل قاعدة "ممنوع الاختلاق"

`sales_agent.py` و `marketing_agent.py` عندهم قاعدة صريحة: **ممنوع اختراع شهادات عملاء وهمية**. المشكلة إنه من غير مصدر حقيقي، كانوا دايمًا هيكتبوا حوالين قيمة العرض بس، مش هيقدروا يستخدموا إثبات اجتماعي خالص. `agents/testimonials_agent.py` بيسدّ الفجوة دي:

- **`testimonial.request_feedback`** — بعد تفاعل ناجح، بيصيغ رسالة لطيفة تسأل العميل عن رأيه، **وبتسأل صراحة لو موافق يتشارك رأيه علنًا** — مفيش افتراض موافقة.
- **`testimonial.record`** — بيسجل رأي العميل الحقيقي، مع علم `permission_granted` **افتراضيًا False** — يعني السكوت أو الغموض مايتفسرش موافقة.
- **`testimonial.list_approved`** — بيرجع بس الآراء اللي فيها موافقة صريحة.
- **`testimonial.format_for_marketing`** — بيجهز الشهادة كـ `real_proof` جاهزة تتمرر مباشرة لـ `marketing_agent.write_ad_copy` أو `sales_agent.present_offer` — نفس نص العميل بالظبط، مش Paraphrase.

النتيجة: أول مرة عميل حقيقي يوافق يشارك رأيه، حامد يقدر يستخدمه فعليًا في التسويق - بدل الاختيار بين "اختلاق" أو "تجاهل الإثبات الاجتماعي خالص".

## 🎬 فيديوهات UGC — مجاني يدويًا، أوتوماتيك لما تحبي تدفعي

`video.generate_ugc_video` قدرة جديدة في `video_content_agent.py` بتكتب سكريبت بأسلوب UGC حقيقي (كأنه شخص عادي بيتكلم قدام الكاميرا، مش إعلان استوديو).

**حقيقة التكلفة اللي لازم تعرفيها:** توليد الفيديو الفعلي بالذكاء الاصطناعي (أفاتار بيتكلم فعليًا) عن طريق API **مش مجاني** — خدمات زي HeyGen شالت الاستخدام المجاني من الـ API بداية فبراير 2026. فبنيناها بطريقة ذكية:

- **من غير `HEYGEN_API_KEY` (الوضع الافتراضي، مجاني تمامًا):** حامد يكتبلك السكريبت، ويديكي تعليمات واضحة تروحي بيها لموقع HeyGen، تعملي حساب مجاني (3 فيديوهات شهريًا بعلامة مائية، من غير بطاقة ائتمان)، تلصقي السكريبت، وتاخدي فيديو UGC حقيقي بنفسك في دقيقتين.
- **مع `HEYGEN_API_KEY` (لما يبقى عندك دخل يغطي التكلفة):** حامد يولّد الفيديو أوتوماتيك بالكامل عن طريق `integrations/heygen_client.py`، ويرجعلك رابط الفيديو الجاهز مباشرة.

نفس مبدأ باقي التكاملات في المشروع: تبدئي مجانًا يدويًا، وتفعّلي الأتمتة لما تستاهل التكلفة.

## 💸 مجاني بالكامل للبداية — صفر جنيه

بعد ما اتسألت عن ده مباشرة، ظبطت النظام كله يشتغل بصفر تكلفة:

| المكوّن | الحل المجاني | ملاحظة |
|---|---|---|
| بوت المحادثة | Telegram (@BotFather) | مجاني 100%، مفيش حد استثناء |
| عقل الذكاء الاصطناعي | **Gemini** (ai.google.dev) أو **Groq** (console.groq.com) | الاتنين بيوفروا Free Tier حقيقي من غير بطاقة ائتمان وقت التسجيل، على حد علمي وقت كتابة الكلام ده — تأكدي من الشروط الحالية وقت التسجيل لأن سياسات الشركات بتتغير |
| الاستضافة | Render.com (الخطة المجانية) | فيها نايم بعد فترة عدم استخدام، بياخد كام ثانية يصحى تاني |
| قاعدة البيانات | SQLite (مدمجة في بايثون) | **تنويه مهم:** خطة Render المجانية معندهاش قرص تخزين دائم، يعني بيانات SQLite ممكن تتصفر لما الخدمة تعيد التشغيل من النوم. لو محتاجة الذاكرة تفضل موجودة دايمًا من غير ما تدفعي، فكري في قاعدة بيانات مجانية سحابية زي Neon أو Supabase (Postgres مجاني) بدل SQLite على Render مجانًا |
| Google Sheets | مجاني (حدود استخدام معقولة لأي حساب Google عادي) | |
| فودافون كاش / واتساب (يدوي) | مجاني تمامًا | التأكيد يدوي، مفيش رسوم بوابة دفع |

**التغيير التقني اللي حصل:** `OPENAI_API_KEY` **مبقاش مطلوب خالص**. المطلوب فعليًا: `TELEGRAM_BOT_TOKEN` + **أي مفتاح واحد بس** من (`GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `DEEPSEEK_API_KEY`, `KIMI_API_KEY`). لو مفيش أي مفتاح، `scripts/check_readiness.py` هيقولك بالظبط إيه المفقود ويقترح عليكي الخيار المجاني.

**اللي هتدفعيه لاحقًا (لما يبقى عندك دخل فعلي):** Twilio (مكالمات/واتساب أوتوماتيكي)، ترقية Render لخطة مدفوعة (تشتغل 24 ساعة من غير ما تنام)، أو مفتاح OpenAI/Claude كـ upgrade لجودة أعلى/redundancy إضافي. أي حاجة من دول مش لازمة عشان تبدئي.

## 🎓 نفس المنهجية الاحترافية اتطبقت على 3 وكلاء تانيين

بعد `sales_agent`، طبقنا نفس مبدأ "شخصية احترافية + قواعد صريحة ضد الحيل الرخيصة" على:

- **`negotiation_agent`** — بقى مبني على مبدأ "مفيش تنازل مجاني". أي تخفيض سعر لازم يكون مقابل حاجة (التزام أطول، دفع أسرع، صفقة أكبر) — مش مجرد "خلاص أقل سعر". وممنوع صراحة يخترع Deadline وهمي أو عرض منافس مش موجود.
- **`marketing_agent`** — بقى فيه قاعدة صريحة: **ممنوع اختراع أرقام أو تقييمات أو نتائج مش حقيقية**. لو مفيش إثبات حقيقي (`real_proof`) اتديله، بيكتب حوالين قيمة العرض نفسه بدل ما يختلق شهادة عميل وهمية. وكمان الـ Content Calendar بقى بيولّد Angle/Hook فعلي لكل يوم، مش بس بيكرر اسم الموضوع.
- **`purchasing_agent`** — كان الوكيل الوحيد اللي معندوش ولا استدعاء LLM واحد (كله حسابات). اتضاف له `purchasing.negotiate_with_supplier` — قدرة تفاوض احترافية فعلية مع الموردين، بتفاوض على القيمة الكاملة (سعر + شروط دفع + مواعيد تسليم) مش السعر بس.

**فحصت كل الـ 30 وكيل بعد كده** للتأكد مفيش "phantom capabilities" (قدرة معلنة بس مش متنفذة، زي المشكلة اللي كانت في `sales.greet` قبل ما تتصلح) — النتيجة نضيفة 100%.

## 🎯 حامد بقى بيّاع خدمات محترف، مش رد جاهز

`agents/sales_agent.py` كان فيه مشكلة حقيقية: `sales.greet` و `sales.followup` كانوا **معلنين كـ capabilities لكن مش متنفذين فعليًا** — أي محاولة استخدامهم كانت ترجع "Unknown action". اتصلحت، وفوق كده اتبنت منهجية بيع احترافية حقيقية:

- **Consultative مش Pitch مباشر:** `sales.greet` بيسأل سؤال واحد يفهم بيه احتياج العميل الأول، **مش بيبدأ يبيع فورًا**. `sales.discover_needs` قدرة جديدة كاملة مخصصة لده.
- **قيمة/نتيجة مش مواصفات:** `sales.present_offer` بيربط العرض بالنتيجة اللي العميل قالها بالظبط، مش قائمة مميزات عامة.
- **تصنيف الاعتراض قبل الرد:** `sales.handle_objection` بيحدد نوع الاعتراض الحقيقي (سعر/ثقة/توقيت/احتياج غير واضح/محتاج موافقة حد تاني) وبيرد بالأسلوب المناسب لكل نوع — مش نفس الرد العام على أي اعتراض.
- **مفيش إلحاح وهمي:** ممنوع صراحة في الـ prompt نفسه إن حامد يخترع ندرة وهمية أو شهادات عملاء مش حقيقية — الثقة هي المنتج الحقيقي في بيع الخدمات.
- **`customer_profile` اختياري في كل الأكشنز** — لو الملف النفسي المتراكم من `customer_psychology_agent` اتمرر، الرد بيتخصص عليه تلقائي.

## 💬 واتساب — رد ذكي + إرسال يدوي

`channels/whatsapp_channel.py` كان بيرد برد ثابت (نفس الـ action كل مرة)، دلوقتي بيستخدم **نفس الـ Decision Engine** بتاع تليجرام والمكالمات — يعني تفكير حقيقي وتفاوض، ولو محتاج موافقة مالية بيقولها صريح بدل ما يكمل لوحده. لو الـ Decision Engine مالقاش رد مناسب، بيرجع تلقائي للـ fallback الثابت بدل ما يسيب العميل من غير رد خالص.

**إرسال رسالة واتساب يدويًا وقت ما تحبي:** `/whatsapp +201xxxxxxxxx نص الرسالة` من حساب الأدمن على تليجرام — مفيدة لما تحبي تبدئي محادثة بنفسك مش تستني العميل يبعت الأول.

## 📞 مكالمات صوتية — دخول وخروج

`channels/voice_channel.py` بيدعم النوعين:

**مكالمات واردة (Inbound):** أي حد يتصل على رقم Twilio بتاعك، حامد بيرد بصوت عربي (`ar-EG`)، يسمع كلامه (Twilio بيحول الصوت لنص تلقائي - مفيش حاجة إضافية تظبطيها)، ويرد عليه **بنفس الـ Decision Engine اللي بيستخدمه في تليجرام وواتساب** — يعني نفس التفكير الذاتي والتفاوض، مش رد ثابت.

**مكالمات صادرة (Outbound):** `/call +201xxxxxxxxx` من حساب الأدمن، وحامد يتصل بالعميل فعليًا. محتاج تحطي `PUBLIC_BASE_URL` في `.env` (رابط تطبيقك على Render) عشان Twilio يعرف يرجعلك وقت الرد.

**حماية مدمجة:**
- لو محدش اتكلم (صمت)، بيطلب منه يعيد بدل ما يفشل بصمت.
- حد أقصى 8 «أدوار» في المكالمة الواحدة (`MAX_TURNS_PER_CALL`) — بعدها بيقفل بأدب ويقول هيتابع تليجرام/واتساب، عشان مكالمة عالقة متكلفكيش فلوس Twilio للأبد.
- لو الموضوع محتاج موافقة مالية، بيقولها في المكالمة نفسها ويحولها لتليجرام بدل ما ياخد قرار بنفسه.

**حدود واقعية لازم تعرفيها:** ده حوار بالدور (يتكلم، يسكت، يرد حامد، يتكلم تاني) مش محادثة متداخلة زي المكالمات البشرية العادية — لو عايزة إحساس "طبيعي" أكتر (مقاطعة، تداخل كلام)، ده محتاج Twilio Media Streams + خدمة صوت متخصصة (زي ElevenLabs)، وده مشروع أكبر بكتير من ميزة مكالمة عادية.

## 🔍 Proactive Scanner — حامد بيدور بنفسه، مش بس بيرد

الفرق الجوهري اللي كنتي عايزاه: قبل كده حامد كان **رد فعل** بس (Reactive) — يستنى رسالة عشان يتصرف. دلوقتي `management/proactive_scanner.py` بيخليه **يدور بنفسه** كل فترة زمنية (افتراضيًا كل 30 دقيقة، تقدري تغيريها بـ `PROACTIVE_SCAN_INTERVAL_MINUTES`)، من غير ما حد يبعتله رسالة أصلاً:

- 💰 **يتابع سرعة الإيراد** مقابل هدف اليوم، ويعلّمك لو انتي "متأخرة عن الوتيرة".
- 🔬 **يفحص كل التجارب المسجلة** (`experiment_engine`) ويطلعلك بس القرارات الجاهزة فعليًا (Scale/Iterate/Kill) — مش هيضايقك بحاجة لسه مبكر عليها.
- 🔎 **يبحث عن فرص جديدة** (لو حطيتي research query).
- 🎯 **يدور على مرشحين جدد في كل منصة سوشيال ميديا عندها access token متظبط** في `.env` (`FACEBOOK_ACCESS_TOKEN`, إلخ) — تلقائي، من غير ما تكتبي `/hunt` كل مرة بنفسك.

**التقرير بيتبعتلك على تليجرام تلقائيًا** كل دورة، وأي مرشح تواصل جديد بيدخل في نفس `OutreachQueue` القديمة — يعني لسه بتاخدي موافقة بضغطة واحدة قبل أي تواصل مع غريب، **الحد ده ما اتغيرش ومش هيتغير**، بس دلوقتي الاكتشاف نفسه بقى تلقائي 100% بدل ما يكون بأمر يدوي.

**تشغيله يدويًا وقت ما تحبي:** `/scan` من حساب الأدمن — بيجيب نفس التقرير فورًا من غير ما تستني الدورة التلقائية.

## 🔁 الحلقة المغلقة: تعليم ذاتي + تطوير تلقائي + فهم عميق للعميل

دي أهم إضافة، وربطت 3 حاجات مع بعض بدل ما تفضل منفصلة:

```
LearningCouncil (يحلل النتائج القديمة)
        ↓
SelfImprovementEngine (يقرر يظبط إيه، جوه حدود آمنة)
        ↓
StrategyParams (يحفظ القيمة الجديدة + السبب)
        ↓
الوكلاء (زي NegotiationAgent) بيقروا القيمة دي في المرة الجاية
        ↓
نتايج جديدة ترجع للـ LearningCouncil من الأول
```

**ليه Rule-Based مش الموديل نفسه بيقرر؟** لأن سيبنا الموديل "يقرر" يغير استراتيجية التسعير من غير قواعد واضحة، ده مخاطرة حقيقية. بدل كده، `management/self_improvement_engine.py` عنده قواعد صريحة وحدود قصوى (`BOUNDS`):
- لو نسبة إغلاق الصفقات (`close_rate`) قلّت عن 20%، يزود `negotiation.concession_ratio` تدريجيًا (يتنازل أكتر عشان يقفل صفقات أكتر).
- لو نسبة الإغلاق عالية جدًا (فوق 70%)، يقلل نفس القيمة (يحافظ على هامش الربح).
- لو وكيل معين نسبة نجاحه واطية باستمرار، يعلّمه "يحتاج مراجعة" — **مش بيقفله لوحده**، بس بيقولك تراجعه.
- **كل تغيير له سبب مسجل** (`StrategyParams.history()`) — تقدري تشوفي إمتى وليه حامد غيّر سلوكه بالظبط.

**⚡ لحظي مش دوري:** الحلقة دي بتشتغل أوتوماتيك **بعد كل مهمة يخلصها أي وكيل** (عن طريق `orchestrator.on_task_complete`) — مش محتاجة تستني يوم كامل ولا تدوسي أمر يدوي. حامد بيتظبط لحظيًا مع كل صفقة، مش على جدول زمني. `/improve` لسه موجود لو حبيتي تشوفي ملخص أو تجبري دورة تحليل فورية بنفسك، لكنه مش الطريقة الوحيدة — التعديل بيحصل تلقائي طول الوقت. (لو حجم المهام يومًا ما وصل لآلاف في الدقيقة، وقتها ينفع تحويلها لـ Cron دوري بدل كل مهمة — لكن لبيزنس بادئ زيك دلوقتي، "أذكى بعد كل تفاعل" أنسب وأرخص فعليًا.)

### 🧠 دراسة نفسية العميل — دلوقتي بتتراكم مش بتتصفر كل مرة
`customer_psychology_agent` بقى عنده `psychology.update_customer_profile` و `psychology.get_customer_profile`. الفرق الجوهري: بدل ما يحلل كل محادثة لوحدها وينساها، دلوقتي بيبني **ملف نفسي متراكم لكل عميل** (حساسية السعر، أسلوب التواصل المفضل، الاعتراضات المتكررة، مستوى الثقة) بيتحدث مع كل تفاعل جديد بدل ما يتصفر. ده اللي بيخلي الرد على عميل تعامل معاه حامد قبل كده مختلف عن الرد على غريب تمامًا.

## 📊 مزامنة Google Sheets

عايزة تشوفي الـ Leads والصفقات والإيرادات والدفعات في شيت عادي بدل ما تفتحي التليجرام كل مرة؟ `integrations/google_sheets_client.py` بيعمل كده.

**ليه Service Account مش تسجيل دخول عادي؟** لأن حامد شغال لوحده على سيرفر، مفيش حد يضغط "Login with Google" كل شوية. الـ Service Account بديل آمن بيشتغل من غير تدخل بشري.

**الإعداد (مرة واحدة، من Google Cloud Console):**
1. اعملي Project جديد، فعّلي "Google Sheets API" و "Google Drive API".
2. اعملي Service Account، واعملي JSON key ليه، ونزّليه.
3. افتحي الشيت بتاعك، اعملي Share، الصقي إيميل الـ Service Account (شكله `xxx@xxx.iam.gserviceaccount.com`)، وادّيله صلاحية Editor.
4. حطي محتوى ملف الـ JSON كامل في `GOOGLE_SHEETS_CREDENTIALS_JSON`، والـ Sheet ID (من رابط الشيت) في `GOOGLE_SHEET_ID`.

**الاستخدام:** ابعتي `/sync_sheets` للبوت (من حساب الأدمن)، وحامد هيزامن جداول `leads`, `deals`, `revenue`, `payments`, `agent_results`, `decision_traces` كلها في شيتات منفصلة. المزامنة يدوية (بضغطة/أمر) مش لحظية بلحظية، عشان Google Sheets API عندها حد أقصى للطلبات في الدقيقة على الخطة المجانية.

**Payment Agent دلوقتي بيسجل كل حالة دفع** (مستني تأكيد / اتأكد / اترفض) في القاعدة، فتقدري تتابعي كل المدفوعات في شيت واحد بدل ما تفوتك حاجة.

## 📱 تشغيل من التليفون بضغطة واحدة (بعد إعداد أول مرة)

`render.yaml` و `Procfile` جاهزين لنشر المشروع على [Render](https://render.com) بضغطة "Deploy" واحدة، كله من متصفح التليفون (Chrome/Safari) من غير ما تحتاجي كمبيوتر أو Terminal. `config.py` دلوقتي بيقرأ `PORT` اللي المنصة بتحطه تلقائيًا (Render/Railway بيحددوا البورت بنفسهم)، فمفيش تعديل يدوي مطلوب.

**دليل خطوة بخطوة كامل (من إنشاء حساب GitHub لحد ما تفتحي تليجرام وتلاقي البوت شغال) موجود في ملف منفصل اتبعتلك معاه: `دليل-التشغيل-من-التليفون.md`.**

بعد أول إعداد (حوالي 15-20 دقيقة، مرة واحدة بس)، الاستخدام اليومي بقى فعلاً: افتحي تليجرام، ابعتي رسالة، خلاص.

## ✅ فحص الجاهزية قبل الرفع (Pre-Launch Readiness Check)

طبقًا لفلسفة "ما نرفعش المشروع قبل ما نعمل Test كامل" من المواصفات الأصلية:

```bash
python scripts/check_readiness.py
```

بيفحص بالترتيب: (1) الـ Environment Variables المطلوبة، (2) كل الموديولات بتتعمل Import صح (يمسك أي `ImportError` زي اللي كان ظاهر قبل كده قبل ما توصل للـ Production)، (3) الـ Agent Registry مفيهوش تعارض Capabilities، (4) توكن التليجرام شغال فعلاً (بيتصل بـ Telegram API الحقيقي، وبيتخطى الفحص بأمان لو مفيش إنترنت بدل ما يفشل)، (5) نظرة عامة على كل الـ Integrations الاختيارية (Database, Twilio, Vodafone Cash, Admin Chat). Exit code 0 = آمن تشغل `bot.py`, 1 = فيه حاجة لازم تتظبط الأول.

## 🔌 Webhooks حقيقية لـ WhatsApp والمكالمات الصوتية

`server/dashboard.py` دلوقتي بيربط فعليًا:
- `POST /webhooks/whatsapp` — دا اللي تحطه في إعدادات Twilio WhatsApp Sandbox/Number، وبيستقبل رسالة العميل ويرد عليه فعليًا عن طريق `AutonomousDecisionEngine` (نفس منطق التليجرام).
- `POST /voice/incoming` و `/voice/handle_speech` — TwiML endpoints لمكالمة صوتية بتتكلم عربي وتفهم رد العميل.

الاتنين بيتفعّلوا تلقائيًا بس لما Twilio يكون متظبط (`has_twilio`)، وغير كده مش بيتسجلوا خالص (مفيش endpoints فاضية بتفشل).

## 🗄️ قاعدة البيانات — دلوقتي حقيقية مش Stub

`database/db.py` كان فيه `NotImplementedError` للـ SQL Store. اتظبطت دلوقتي بـ SQLite حقيقي (`sqlite3` من Python نفسه، صفر مكتبات إضافية):
- حط `DATABASE_URL=sqlite:///hamed.db` في `.env` والبيانات هتفضل موجودة حتى بعد إعادة تشغيل السيرفر.
- من غيرها، النظام شغال بـ In-Memory زي ما كان (تتصفر البيانات عند إعادة التشغيل، بس مفيش توقف).
- Postgres/MySQL محتاجين SQLAlchemy + driver مناسب — مش متضمنين افتراضيًا عشان الـ install يفضل خفيف، والكود بيديك رسالة واضحة لو حطيت `postgresql://` من غيرها.

## 🧠 Multi-Brain — كل المزودين الخمسة شغالين فعليًا

كانت `claude`, `deepseek`, `gemini`, `kimi` عبارة عن Stubs بترمي `NotImplementedError`. اتظبطوا كلهم بـ SDK/API حقيقي:
- **Claude** → Anthropic SDK مباشرة.
- **DeepSeek** و **Kimi (Moonshot)** → بيستخدموا مكتبة `openai` نفسها مع `base_url` مختلف (الاتنين عندهم API متوافق مع OpenAI، فمحتاجوش مكتبة منفصلة).
- **Gemini** → `google-generativeai` SDK.

يعني دلوقتي حط أي مفتاح من الخمسة في `.env` والـ Fallback Chain (`OpenAI → Claude → DeepSeek → Gemini → Kimi`) هيشتغل بمزودين حقيقيين، مش Stub.

## 💰 الدفع (Vodafone Cash) والتواصل (WhatsApp) - جاهزين فعليًا

- **`agents/payment_agent.py`** — بيستخدم رقم الفودافون كاش اللي حطيته في `.env` (`VODAFONE_CASH_NUMBER`). **مهم تعرفه:** مفيش API عام للفودافون كاش الشخصي يتأكد من التحويل أوتوماتيك، فالـ Agent بيعمل النسخة الصادقة: بيدّي العميل كود مرجعي، ويسجل الطلب "مستني تأكيد"، وانت بتأكده يدوي (`payment.confirm`) لما تشوف إشعار التحويل في موبايلك. لو حبيت أتمتة حقيقية بعدين، محتاج تسجيل تجاري + Paymob/Fawry.
- **رقم الواتساب** (`WHATSAPP_CONTACT_NUMBER`) — شغال كرقم تواصل يتعرض للعملاء دلوقتي. الإرسال الأوتوماتيكي عليه فعليًا محتاج الرقم يتربط بـ WhatsApp Business API (عن طريق Twilio أو Meta مباشرة) — مش أي رقم شخصي يشتغل تلقائي، ده قيد حقيقي من واتساب نفسها مش مني.

## 🎯 قنص الفرص (Cold Outreach) - أوتوماتيكي لحد خطوة واحدة بس

**`management/hunting_pipeline.py` (`ColdOutreachHunter`)** — بيدور فعليًا على مرشحين (لما يكون عندك access_token رسمي للمنصة)، يكتب رسالة افتتاحية مخصصة لكل واحد، ويحطهم في **`management/outreach_queue.py`**.

**ليه فيه خطوة موافقة واحدة قبل الإرسال لغريب:** الفرق بين شخص تفاعل مع صفحتك (رد، عمل كومنت، بعتلك) وشخص Hamed لقاه بالبحث ومحدش كلمه قبل كده. الأول حامد بيرد عليه أوتوماتيك 100% (عن طريق `AutonomousDecisionEngine`). التاني (Cold Outreach) بيتبعتلك على تليجرام كـ "فرصة" ومعاها زرار موافقة نصي:

```
/hunt facebook <access_token>     → يدوّر ويبعتلك المرشحين المقترحين
/pending                          → يوريك كل الفرص المستنية
/approve <رقم>                    → يبعت الرسالة فعليًا (واتساب مباشر، باقي المنصات بتديك النص تبعته يدوي لحد ما تربط API رسمي)
/reject <رقم>                     → يرفض الفرصة
/setoffer <وصف قصير للي بتقدمه>   → يستخدمه حامد في صياغة رسايل القنص
```

هدف الخطوة دي إنك تقدر "تقنص" فعليًا 24 ساعة من غير ما تستنى حد يبعتلك، من غير ما يتقفل حسابك بسبب رسايل جماعية مرفوضة من المنصة.

## 🧠 التفكير الذاتي واتخاذ القرارات (Autonomous Decision Engine)

الفرق بين `HamedBoard` والـ `AutonomousDecisionEngine`:

- **`HamedBoard`** — Playbook ثابت (خطوات معروفة مسبقًا بالترتيب). كويس للعمليات المتكررة زي `new_deal_pipeline`.
- **`AutonomousDecisionEngine`** (`management/decision_engine.py`) — **مفيش خطوات ثابتة**. بياخد Goal مفتوح ("رد على العميل ده وحرّك المحادثة")، وبيدخل في حلقة:

  ```
  Think (يسأل الـ Multi-Brain: "الخطوة الجاية إيه؟") 
     → Act (ينفذ الـ action عبر الـ Orchestrator)
     → Observe (يشوف النتيجة)
     → Think again...
  ```

  لحد ما: (أ) الموديل يقول إن الهدف اتحقق، أو (ب) خطوة تحتاج Approval فيوقف فورًا، أو (ج) action غير مسجل فيوقف بدل ما يخمّن، أو (د) يوصل `max_steps`.

**الحماية المهمة:** الـ Decision Engine **مش بيخترع Actions**. كل قرار بيتفحص ضد `orchestrator.available_capabilities()` قبل التنفيذ — يعني "التفكير الذاتي" ده لسه محصور جوه نفس الـ ٥٨ Capability المسجلة، مش قادر يتخطى الـ Approval Layer أو ينفذ حاجة مش موجودة.

**`SelfReflection`** (`management/self_reflection.py`) — بعد كل run، بيسأل الموديل سؤال صريح: "ده فعلاً قرّب من الهدف ولا كان مجرد حركة؟ وإيه حاجة واحدة نغيرها المرة الجاية؟" ويسجّل الإجابة (`reflections` table) عشان الـ Learning Council يشوف الأنماط عبر الوقت، مش run واحد بس.

الـ Telegram bot (`bot.py`) دلوقتي بيستخدم الـ Decision Engine مباشرة على أي رسالة تجيله، بدل الـ routing الثابت اللي كان موجود قبل كده، وبيعمل Reflection في الخلفية بعد كل رد.

## خريطة التغطية مقابل رؤية حامد الكاملة

| الفئة | التغطية |
|---|---|
| 🧠 عقول وAgents متعددة | `brains/multi_brain.py` + 29 وكيل في `agents/` |
| 👥 عملاء ومبيعات | `sales_agent.py`, `negotiation_agent.py`, `customer_hunter_agent.py`, `research_team/` |
| 📣 تسويق وإعلانات | `marketing_agent.py` |
| 🎬 فيديو ومحتوى | `video_content_agent.py` |
| 🌐 مواقع ومتاجر | `websiteless_business_agent.py` (landing pages + product catalog copy) |
| 🛒 شراء وتوريد | `purchasing_agent.py` |
| 🌍 استيراد وتصدير | `import_export_agent.py` (تقدير تكلفة، مش استشارة جمركية) |
| 🏭 مصانع وصناعة | `manufacturing_agent.py` |
| 💼 Freelance وخدمات | `freelance_agent.py` |
| 💰 Revenue & Affiliate | `management/revenue_engine.py` + `affiliate_agent.py` |
| 🤝 شراكات وMarketplace | `partnership_marketplace_agent.py` |
| 📊 تحليل سوق ومنافسين | `market_competitor_agent.py` |
| 🚀 بناء منتجات وSaaS | `product_builder_agent.py` |
| 🔬 تجارب Scale/Kill | `management/experiment_engine.py` |
| 🧬 تعلم ذاتي واكتشاف فرص | `learning/learning_council.py` + `research_agent.py` (Opportunity Hunter) |
| 🌐 شبكة عملاء وموردين وشركاء | `lead_generation_agent.py` + `partnership_marketplace_agent.py` |
| 🏢 Venture Studio | `management/venture_studio.py` |
| 🛡️ حماية وتحقق وصلاحيات | `approvals/approval_layer.py` (حدود مالية) + `verification_agent.py` (فحص مخاطر) |

كل الـ ١٨ فئة ليها module حقيقي وشغّال ومتفحوص - مش مجرد أسماء فاضية.

## ليه البنية دي بالذات

- **Config لا يوقف التشغيل بسبب متغيرات اختيارية**: `TELEGRAM_BOT_TOKEN` و `OPENAI_API_KEY` مطلوبين فقط.
  `DATABASE_URL`, `TWILIO_*`, `PAYMOB_*` اختياريين تمامًا — النظام يشتغل بدونهم (in-memory fallback).
- **Multi-Brain مع Fallback حقيقي**: لو `openai` رمى `RateLimitError` أو أي استثناء، النظام يجرب `claude` بعده
  تلقائيًا، وهكذا حسب الترتيب `OpenAI → Claude → DeepSeek → Gemini → Kimi`. الترتيب والمزودين قابلين للتوسيع في
  `brains/multi_brain.py`.
- **Approval Layer منفصل عن الوكلاء**: أي قرار يتخطى حد مالي (`MAX_AUTONOMOUS_AMOUNT`) يتحول لـ "pending approval"
  بدل ما ينفذ تلقائيًا. العمليات التشغيلية العادية بتتنفذ Autonomous زي ما اتطلب بالظبط.
- **Registry pattern للوكلاء**: عشان توسّع من ٥ وكلاء لـ ٨٠+ من غير إعادة هيكلة، كل وكيل جديد هو كلاس صغير يرث من
  `BaseAgent` ويتسجل في `agents/registry.py`.
- **Social Media Hunting عبر OAuth رسمي فقط**: `customer_hunter_agent.py` مبني على افتراض استخدام الـ Official
  Graph/Business APIs (بعد ما تربط الحساب بـ OAuth) — مفيش أي تخزين لباسورد حسابات، وده اللي كنت طلبته.
  لاحظ إن أي automation فعلي للتواصل مع ناس على المنصات دي لازم يتوافق مع Platform Policies بتاعت
  Meta/TikTok (مافيش scraping أو رسائل جماعية غير مصرح بيها) — الكود هنا بيوفر الـ interface والمنطق
  (Find → Analyze → Qualify → Contact → Follow-up)، لكن التفعيل الفعلي محتاج App Review + Permissions حقيقية
  من كل منصة.

## التشغيل

```bash
cp .env.example .env   # املأ TELEGRAM_BOT_TOKEN و OPENAI_API_KEY على الأقل
pip install -r requirements.txt --break-system-packages
python bot.py
```

الـ Dashboard: `http://127.0.0.1:8000/dashboard`
الـ Health: `http://127.0.0.1:8000/health`

## الاختبارات

```bash
pytest tests/ -v
```

بتغطي: Multi-Brain Fallback، Orchestrator routing، الوكلاء الأساسيين، Approval Layer (رفض/قبول العمليات المالية).

## خطوة التوسع التالية

عشان توصل لـ ٨٠+ وكيل زي في المواصفات:
1. كل تخصص (Affiliate, Education x5, Social Media x5, Marketing...) بياخد ملف زي `agents/sales_agent.py`.
2. تسجّله في `agents/registry.py` بسطر واحد: `register("affiliate_finder", AffiliateFinderAgent)`.
3. الـ Orchestrator مش محتاج تعديل — هو أصلاً بيوزّع حسب الـ `capability` مش حسب اسم الوكيل.
4. Learning Council و Client Research Team كطبقات إضافية فوق الـ Registry — أضفهم كـ "meta-agents" بياخدوا
   نتائج باقي الوكلاء كـ input (الملف `orchestrator/hamed_orchestrator.py` فيه hook جاهز لده: `on_task_complete`).

هذا الأساس بيطبق كل القرارات المعمارية اللي في المواصفات (Multi-Brain order، Approval boundaries، Optional env
vars، Autonomous vs Approval-required operations) من غير ما يحاول يدّعي إنه نفّذ الـ ٨٠ وكيل والـ WhatsApp
والـ Voice في نفس الخطوة — دول محتاجين API keys وحسابات فعلية (Twilio, Meta Business, إلخ) مش ممكن أجهزها
نيابة عنك.
