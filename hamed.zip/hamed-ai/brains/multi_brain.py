"""
Multi-Brain Architecture with Automatic Fallback.

Order from the spec: OpenAI -> Claude -> DeepSeek -> Gemini -> Kimi.
If a provider raises ANY exception (RateLimitError, timeout, auth error, etc.),
the system moves to the next provider instead of stopping Hamed entirely.
"""
import logging
from dataclasses import dataclass
from typing import Callable, List, Optional

logger = logging.getLogger("hamed.multi_brain")

BRAIN_ORDER = ["gemini", "groq", "openai", "claude", "deepseek", "kimi"]
# Free-tier options (Gemini, Groq) are tried first since they're the
# recommended zero-cost starting point - see config.py's docstring. Paid
# options come after for extra redundancy once you've added them.


@dataclass
class BrainResponse:
    text: str
    provider: str
    attempts: List[str]


class BrainProvider:
    """Wraps a single AI provider. Subclass or instantiate with a `call_fn`."""

    def __init__(self, name: str, call_fn: Callable[[str], str], enabled: bool = True):
        self.name = name
        self.call_fn = call_fn
        self.enabled = enabled

    def call(self, prompt: str) -> str:
        if not self.enabled:
            raise RuntimeError(f"{self.name} is not configured (missing API key)")
        return self.call_fn(prompt)


class MultiBrain:
    """
    Tries providers in order until one succeeds. Never raises unless ALL
    configured providers fail - that failure is reported clearly instead of
    silently swallowed.
    """

    def __init__(self, providers: List[BrainProvider]):
        # Keep only providers that are enabled, but preserve BRAIN_ORDER
        by_name = {p.name: p for p in providers}
        self.providers = [by_name[n] for n in BRAIN_ORDER if n in by_name]

    def ask(self, prompt: str) -> BrainResponse:
        attempts = []
        last_error: Optional[Exception] = None

        for provider in self.providers:
            attempts.append(provider.name)
            try:
                text = provider.call(prompt)
                if attempts[:-1]:
                    logger.warning(
                        "Brain fallback: %s failed, succeeded with %s",
                        ", ".join(attempts[:-1]), provider.name,
                    )
                return BrainResponse(text=text, provider=provider.name, attempts=attempts)
            except Exception as e:  # noqa: BLE001 - intentionally broad: any failure -> fallback
                logger.warning("Brain '%s' failed: %s", provider.name, e)
                last_error = e
                continue

        raise RuntimeError(
            f"All configured AI brains failed: {attempts} - last error: {last_error}"
        )


def build_default_multi_brain(config) -> MultiBrain:
    """Builds the MultiBrain using whichever API keys are present in config."""
    providers = []

    if config.GEMINI_API_KEY:
        providers.append(BrainProvider("gemini", _make_gemini_call(config.GEMINI_API_KEY)))
    if config.GROQ_API_KEY:
        providers.append(BrainProvider("groq", _make_groq_call(config.GROQ_API_KEY)))
    if config.OPENAI_API_KEY:
        providers.append(BrainProvider("openai", _make_openai_call(config.OPENAI_API_KEY)))
    if config.ANTHROPIC_API_KEY:
        providers.append(BrainProvider("claude", _make_claude_call(config.ANTHROPIC_API_KEY)))
    if config.DEEPSEEK_API_KEY:
        providers.append(BrainProvider("deepseek", _make_deepseek_call(config.DEEPSEEK_API_KEY)))
    if config.KIMI_API_KEY:
        providers.append(BrainProvider("kimi", _make_kimi_call(config.KIMI_API_KEY)))

    return MultiBrain(providers)


def _make_openai_call(api_key: str) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content

    return call


def _make_claude_call(api_key: str) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        from anthropic import Anthropic
        client = Anthropic(api_key=api_key)
        resp = client.messages.create(
            model="claude-sonnet-5",  # adjust to whichever Claude model you have access to
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text

    return call


def _make_deepseek_call(api_key: str) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        # DeepSeek exposes an OpenAI-compatible API, so we reuse the openai SDK
        # with a different base_url instead of a separate client library.
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")
        resp = client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content

    return call


def _make_gemini_call(api_key: str) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-1.5-flash")
        resp = model.generate_content(prompt)
        return resp.text

    return call


def _make_groq_call(api_key: str) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        # Groq exposes an OpenAI-compatible API with a genuinely free tier
        # (fast inference on open models like Llama) - reuse the openai SDK
        # with a different base_url instead of a separate client library.
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url="https://api.groq.com/openai/v1")
        resp = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content

    return call


def _make_kimi_call(api_key: str) -> Callable[[str], str]:
    def call(prompt: str) -> str:
        # Kimi/Moonshot also exposes an OpenAI-compatible API.
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url="https://api.moonshot.cn/v1")
        resp = client.chat.completions.create(
            model="moonshot-v1-8k",
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.choices[0].message.content

    return call
