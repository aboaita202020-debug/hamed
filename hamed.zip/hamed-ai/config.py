"""
Config loader for Hamed AI.

TELEGRAM_BOT_TOKEN is always required. For the AI brain, you need AT LEAST
ONE of the brain keys below - it does NOT have to be OpenAI. Gemini and Groq
both offer genuinely free API tiers (no credit card needed to start), so
Hamed can run at zero cost while you're just getting started; add a paid
key (OpenAI/Anthropic/DeepSeek) later for extra fallback redundancy once
you have paying customers.

Everything else (DATABASE_URL, TWILIO_*, PAYMOB_*, other brain keys) is
fully optional - their absence must never crash or block startup.
"""
import os
import sys
from typing import Dict
from dotenv import load_dotenv

load_dotenv()

REQUIRED_VARS = ["TELEGRAM_BOT_TOKEN"]
# At least one of these must be set - checked separately from REQUIRED_VARS
# because it's an "at least one of" rule, not "all of these".
BRAIN_KEY_VARS = [
    "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY",
    "GEMINI_API_KEY", "GROQ_API_KEY", "KIMI_API_KEY",
]


class Config:
    # Required
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

    # AI brains - need at least one. GEMINI_API_KEY and GROQ_API_KEY both have
    # genuinely free tiers as of this writing - start with either of those at
    # zero cost, add OPENAI_API_KEY/ANTHROPIC_API_KEY later as paid upgrades.
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
    DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    KIMI_API_KEY = os.getenv("KIMI_API_KEY")

    # Optional - database
    DATABASE_URL = os.getenv("DATABASE_URL")  # None => in-memory store is used

    # Optional - channels / payments
    TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID")
    TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN")
    TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER")
    PAYMOB_API_KEY = os.getenv("PAYMOB_API_KEY")
    PAYMOB_INTEGRATION_ID = os.getenv("PAYMOB_INTEGRATION_ID")

    # Optional - manual payment / contact channels (no gateway API required)
    VODAFONE_CASH_NUMBER = os.getenv("VODAFONE_CASH_NUMBER")
    WHATSAPP_CONTACT_NUMBER = os.getenv("WHATSAPP_CONTACT_NUMBER")

    # Optional - your own Telegram chat id, so Hamed can send YOU one-tap
    # outreach approvals instead of contacting strangers with no human check.
    ADMIN_TELEGRAM_CHAT_ID = os.getenv("ADMIN_TELEGRAM_CHAT_ID")

    # Optional - Google Sheets sync (leads/deals/revenue/payments as a live sheet)
    GOOGLE_SHEETS_CREDENTIALS_JSON = os.getenv("GOOGLE_SHEETS_CREDENTIALS_JSON")
    GOOGLE_SHEET_ID = os.getenv("GOOGLE_SHEET_ID")

    # Optional - HeyGen (automated UGC-style AI avatar video). Costs money on
    # the API tier - without this, video.generate_ugc_video falls back to a
    # free manual path (script + instructions to paste into HeyGen's free
    # web plan yourself). See integrations/heygen_client.py.
    HEYGEN_API_KEY = os.getenv("HEYGEN_API_KEY")

    # Optional - social platform access tokens (from official OAuth, never
    # passwords) so the Proactive Scanner can hunt automatically without you
    # re-typing a token into /hunt every time.
    FACEBOOK_ACCESS_TOKEN = os.getenv("FACEBOOK_ACCESS_TOKEN")
    INSTAGRAM_ACCESS_TOKEN = os.getenv("INSTAGRAM_ACCESS_TOKEN")
    TIKTOK_ACCESS_TOKEN = os.getenv("TIKTOK_ACCESS_TOKEN")
    LINKEDIN_ACCESS_TOKEN = os.getenv("LINKEDIN_ACCESS_TOKEN")
    TWITTER_ACCESS_TOKEN = os.getenv("TWITTER_ACCESS_TOKEN")

    # How often the Proactive Scanner runs automatically, in minutes.
    PROACTIVE_SCAN_INTERVAL_MINUTES = int(os.getenv("PROACTIVE_SCAN_INTERVAL_MINUTES", "30"))

    # Optional - your deployed app's public URL (e.g. https://hamed-ai.onrender.com),
    # needed only for placing OUTBOUND voice calls (Twilio needs a full URL to
    # call back to, not a relative path). Not needed for inbound calls or WhatsApp.
    PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")

    # Autonomy / approval boundaries
    MAX_AUTONOMOUS_AMOUNT = float(os.getenv("MAX_AUTONOMOUS_AMOUNT", "100"))
    DEFAULT_CURRENCY = os.getenv("DEFAULT_CURRENCY", "USD")

    # Dashboard - cloud platforms (Render/Railway) inject PORT automatically;
    # DASHBOARD_PORT is the local-dev fallback name for the same thing.
    DASHBOARD_HOST = os.getenv("DASHBOARD_HOST", "127.0.0.1")
    DASHBOARD_PORT = int(os.getenv("PORT", os.getenv("DASHBOARD_PORT", "8000")))

    @property
    def has_database(self) -> bool:
        return bool(self.DATABASE_URL)

    @property
    def has_twilio(self) -> bool:
        return bool(self.TWILIO_ACCOUNT_SID and self.TWILIO_AUTH_TOKEN)

    @property
    def has_paymob(self) -> bool:
        return bool(self.PAYMOB_API_KEY)

    @property
    def has_vodafone_cash(self) -> bool:
        return bool(self.VODAFONE_CASH_NUMBER)

    @property
    def has_whatsapp_contact(self) -> bool:
        return bool(self.WHATSAPP_CONTACT_NUMBER)

    @property
    def has_admin_chat(self) -> bool:
        return bool(self.ADMIN_TELEGRAM_CHAT_ID)

    @property
    def has_google_sheets(self) -> bool:
        return bool(self.GOOGLE_SHEETS_CREDENTIALS_JSON and self.GOOGLE_SHEET_ID)

    @property
    def has_heygen(self) -> bool:
        return bool(self.HEYGEN_API_KEY)

    def configured_platform_tokens(self) -> Dict[str, str]:
        """Returns {platform: access_token} for every social platform that has a token set."""
        pairs = {
            "facebook": self.FACEBOOK_ACCESS_TOKEN,
            "instagram": self.INSTAGRAM_ACCESS_TOKEN,
            "tiktok": self.TIKTOK_ACCESS_TOKEN,
            "linkedin": self.LINKEDIN_ACCESS_TOKEN,
            "twitter": self.TWITTER_ACCESS_TOKEN,
        }
        return {platform: token for platform, token in pairs.items() if token}

    def available_brains(self):
        """
        Returns which AI brains have keys configured, in fallback order.
        Free-tier options (Gemini, Groq) are listed first since they're the
        recommended zero-cost starting point; paid options come after for
        redundancy once you add them.
        """
        order = [
            ("gemini", self.GEMINI_API_KEY),
            ("groq", self.GROQ_API_KEY),
            ("openai", self.OPENAI_API_KEY),
            ("claude", self.ANTHROPIC_API_KEY),
            ("deepseek", self.DEEPSEEK_API_KEY),
            ("kimi", self.KIMI_API_KEY),
        ]
        return [name for name, key in order if key]

    def validate(self):
        """Fail fast only on truly required vars. Never fail on optional ones."""
        missing = [v for v in REQUIRED_VARS if not getattr(self, v)]
        if missing:
            print(f"[Hamed AI] Missing required environment variables: {missing}",
                  file=sys.stderr)
            print("[Hamed AI] Set them in your .env file. See .env.example.",
                  file=sys.stderr)
            return False

        if not any(getattr(self, v) for v in BRAIN_KEY_VARS):
            print("[Hamed AI] No AI brain key set. Set AT LEAST ONE of: "
                  f"{BRAIN_KEY_VARS}", file=sys.stderr)
            print("[Hamed AI] Free options to start with zero cost: "
                  "GEMINI_API_KEY (ai.google.dev) or GROQ_API_KEY (console.groq.com).",
                  file=sys.stderr)
            return False

        # Informational only - these never block startup
        if not self.has_database:
            print("[Hamed AI] DATABASE_URL not set - running with in-memory store.")
        if not self.has_twilio:
            print("[Hamed AI] Twilio not configured - voice/SMS channel disabled.")
        if not self.has_paymob:
            print("[Hamed AI] Paymob not configured - payment processing disabled.")
        if not self.has_google_sheets:
            print("[Hamed AI] Google Sheets not configured - /sync_sheets will be unavailable.")
        if len(self.available_brains()) < 2:
            print("[Hamed AI] WARNING: only one AI brain configured - "
                  "fallback chain has no redundancy yet.")
        return True


config = Config()
