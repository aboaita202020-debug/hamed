"""
Optional persistence layer. DATABASE_URL is optional per the spec - when it's
not set, Hamed runs fine using an in-memory store (data is lost on restart,
but nothing crashes or blocks startup).

Real persistence uses Python's built-in `sqlite3` (no extra dependency) for
`sqlite:///path/to/file.db` URLs. For Postgres/MySQL, install SQLAlchemy +
the matching driver and extend `SqlStore` - kept out of the default
requirements so a fresh install doesn't need a DB driver it isn't using.
"""
import json
import sqlite3
import threading
from typing import Any, Dict, List


class InMemoryStore:
    def __init__(self):
        self.tables: Dict[str, List[Dict[str, Any]]] = {
            "customers": [], "leads": [], "deals": [], "conversations": [],
            "suppliers": [], "products": [], "agent_results": [],
        }

    def insert(self, table: str, record: Dict[str, Any]) -> None:
        self.tables.setdefault(table, []).append(record)

    def all(self, table: str) -> List[Dict[str, Any]]:
        return self.tables.get(table, [])


class SqliteStore:
    """
    Real persistence backed by SQLite. Every `table` becomes its own SQLite
    table with a single JSON blob column - this mirrors InMemoryStore's
    schema-less design so agents don't need migrations for every new field.
    Safe for a single-process deployment (uses a lock around writes);
    for multi-process/multi-server deployments, move to Postgres instead.
    """
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._lock = threading.Lock()
        # check_same_thread=False: bot.py runs the dashboard in a background
        # thread while the Telegram bot polls in the main thread.
        self._conn = sqlite3.connect(db_path, check_same_thread=False)

    def _ensure_table(self, table: str) -> None:
        safe_table = self._safe_table_name(table)
        self._conn.execute(
            f"CREATE TABLE IF NOT EXISTS {safe_table} "
            f"(id INTEGER PRIMARY KEY AUTOINCREMENT, data TEXT NOT NULL)"
        )

    def insert(self, table: str, record: Dict[str, Any]) -> None:
        with self._lock:
            self._ensure_table(table)
            safe_table = self._safe_table_name(table)
            self._conn.execute(
                f"INSERT INTO {safe_table} (data) VALUES (?)",
                (json.dumps(record, default=str),),
            )
            self._conn.commit()

    def all(self, table: str) -> List[Dict[str, Any]]:
        with self._lock:
            self._ensure_table(table)
            safe_table = self._safe_table_name(table)
            rows = self._conn.execute(f"SELECT data FROM {safe_table} ORDER BY id").fetchall()
        return [json.loads(row[0]) for row in rows]

    @staticmethod
    def _safe_table_name(table: str) -> str:
        # Table names come from our own code (e.g. "agent_results", "revenue"),
        # never from user input, but validate anyway before string-formatting SQL.
        if not table.replace("_", "").isalnum():
            raise ValueError(f"Unsafe table name: {table!r}")
        return f'"{table}"'


def build_store(config):
    if not config.has_database:
        return InMemoryStore()

    url = config.DATABASE_URL
    if url.startswith("sqlite:///"):
        return SqliteStore(url[len("sqlite:///"):])

    raise NotImplementedError(
        f"DATABASE_URL scheme not supported yet: {url!r}. "
        f"Use 'sqlite:///path/to/file.db' for built-in support, or install "
        f"SQLAlchemy + a Postgres/MySQL driver and extend database/db.py."
    )
