"""
HeyGen client for automated UGC-style AI avatar video generation.

HONEST COST NOTE: HeyGen's website has a free plan (3 watermarked videos a
month, no card needed) - but as of this writing, HeyGen removed free credits
from its API tier, so calling the API programmatically (what this module
does) requires a paid HeyGen plan. This is why `video.generate_ugc_video`
in video_content_agent.py falls back to a free MANUAL path (script/storyboard
you paste into HeyGen's website yourself) when this client isn't configured -
you shouldn't need to pay anything to get your first UGC videos.

Add HEYGEN_API_KEY once you have revenue and want this automated.
"""
import logging
import time
from typing import Any, Dict, Optional

logger = logging.getLogger("hamed.heygen")

HEYGEN_API_BASE = "https://api.heygen.com"
POLL_INTERVAL_SECONDS = 5
MAX_POLL_ATTEMPTS = 60  # ~5 minutes max wait for a video to render


class HeyGenClient:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def _headers(self) -> Dict[str, str]:
        return {"X-Api-Key": self.api_key, "Content-Type": "application/json"}

    def generate_video(self, script: str, avatar_id: str, voice_id: str) -> Dict[str, Any]:
        """
        Submits a video generation job and polls until it's ready (or times
        out). Returns {"status": "completed", "video_url": "..."} or
        {"status": "failed"/"timeout", "reason": "..."}.
        """
        import requests

        payload = {
            "video_inputs": [{
                "character": {"type": "avatar", "avatar_id": avatar_id, "avatar_style": "normal"},
                "voice": {"type": "text", "input_text": script, "voice_id": voice_id},
            }],
            "dimension": {"width": 720, "height": 1280},  # vertical, UGC/Reels-style
        }

        resp = requests.post(f"{HEYGEN_API_BASE}/v2/video/generate", json=payload, headers=self._headers())
        resp.raise_for_status()
        video_id = resp.json()["data"]["video_id"]

        return self._poll_for_result(video_id)

    def _poll_for_result(self, video_id: str) -> Dict[str, Any]:
        import requests

        for _ in range(MAX_POLL_ATTEMPTS):
            resp = requests.get(
                f"{HEYGEN_API_BASE}/v1/video_status.get",
                params={"video_id": video_id}, headers=self._headers(),
            )
            resp.raise_for_status()
            data = resp.json().get("data", {})
            status = data.get("status")

            if status == "completed":
                return {"status": "completed", "video_url": data.get("video_url")}
            if status == "failed":
                return {"status": "failed", "reason": data.get("error", "unknown error")}

            time.sleep(POLL_INTERVAL_SECONDS)

        return {"status": "timeout", "reason": f"No result after {MAX_POLL_ATTEMPTS * POLL_INTERVAL_SECONDS}s"}


def build_heygen_client(config) -> Optional[HeyGenClient]:
    if not getattr(config, "HEYGEN_API_KEY", None):
        logger.info("HeyGen not configured - UGC video generation will use the free manual path instead.")
        return None
    return HeyGenClient(config.HEYGEN_API_KEY)
