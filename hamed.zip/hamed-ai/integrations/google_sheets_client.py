"""
Google Sheets sync — lets you see leads/deals/revenue/payments in a normal
spreadsheet instead of only the Telegram bot or /dashboard.

Uses a Google Cloud SERVICE ACCOUNT (not interactive OAuth) because Hamed
runs unattended on a server with nobody available to click through a login
popup. Setup (one-time, from Google Cloud Console):
  1. Create a project -> enable "Google Sheets API" and "Google Drive API".
  2. Create a Service Account -> create a JSON key -> download it.
  3. Open your Google Sheet -> Share -> paste the service account's email
     (looks like xxx@xxx.iam.gserviceaccount.com) -> give it Editor access.
  4. Put the JSON file's full content in GOOGLE_SHEETS_CREDENTIALS_JSON,
     and the sheet's ID (from its URL) in GOOGLE_SHEET_ID.

Without these two env vars, `build_sheets_client` returns None and every
caller in this codebase checks for that before using it - same optional
pattern as Twilio/Database elsewhere in the project.
"""
import json
import logging
from typing import Any, Dict, List

logger = logging.getLogger("hamed.google_sheets")

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive.file",
]


class GoogleSheetsClient:
    def __init__(self, credentials_json: str, sheet_id: str):
        import gspread
        from google.oauth2.service_account import Credentials

        creds_dict = json.loads(credentials_json)
        credentials = Credentials.from_service_account_info(creds_dict, scopes=SCOPES)
        self._client = gspread.authorize(credentials)
        self._spreadsheet = self._client.open_by_key(sheet_id)

    def _get_or_create_worksheet(self, name: str, num_cols: int = 20):
        try:
            return self._spreadsheet.worksheet(name)
        except Exception:  # noqa: BLE001 - gspread raises its own WorksheetNotFound
            return self._spreadsheet.add_worksheet(title=name, rows=1000, cols=num_cols)

    def sync_table(self, worksheet_name: str, records: List[Dict[str, Any]]) -> int:
        """
        Full rewrite of a worksheet from a list of dicts: header row = union
        of all keys seen, then one row per record. Simple and predictable -
        avoids partial/duplicate rows from incremental appends.
        """
        if not records:
            return 0

        headers: List[str] = []
        for record in records:
            for key in record.keys():
                if key not in headers:
                    headers.append(key)

        rows = [headers]
        for record in records:
            rows.append([str(record.get(h, "")) for h in headers])

        worksheet = self._get_or_create_worksheet(worksheet_name, num_cols=max(len(headers), 1))
        worksheet.clear()
        worksheet.update(rows)
        return len(records)

    def append_row(self, worksheet_name: str, record: Dict[str, Any]) -> None:
        """Cheaper than a full sync for a single new record - appends one row."""
        worksheet = self._get_or_create_worksheet(worksheet_name)
        existing_headers = worksheet.row_values(1)
        if not existing_headers:
            headers = list(record.keys())
            worksheet.append_row(headers)
        else:
            headers = existing_headers
        worksheet.append_row([str(record.get(h, "")) for h in headers])


def build_sheets_client(config) -> "GoogleSheetsClient | None":
    if not config.has_google_sheets:
        logger.info("Google Sheets not configured - sync disabled.")
        return None
    try:
        return GoogleSheetsClient(config.GOOGLE_SHEETS_CREDENTIALS_JSON, config.GOOGLE_SHEET_ID)
    except Exception as e:  # noqa: BLE001
        logger.warning("Google Sheets client failed to initialize: %s", e)
        return None
