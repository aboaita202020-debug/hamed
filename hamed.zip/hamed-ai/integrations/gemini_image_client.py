"""
Gemini Image Generation ("Nano Banana") - genuinely free, and reuses the
SAME GEMINI_API_KEY you already set for the AI brain. No new account, no
new signup, no new key needed if you already picked Gemini as your brain.

Uses the newer `google-genai` SDK (different package from the
`google-generativeai` one used for text in brains/multi_brain.py) - Google
ships image generation through this separate, newer client library.
Free tier: roughly 50 image requests/day per Google AI Studio's published
limits as of this writing - check ai.google.dev for current numbers, since
free-tier limits are the kind of thing providers adjust over time.
"""
import base64
import logging
from typing import Optional

logger = logging.getLogger("hamed.gemini_image")

IMAGE_MODEL = "gemini-2.5-flash-image"  # "Nano Banana" - fast, good for product/ad images


class GeminiImageClient:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def generate_image(self, prompt: str, aspect_ratio: str = "1:1") -> bytes:
        """Returns raw PNG image bytes, or raises if generation failed."""
        from google import genai
        from google.genai import types

        client = genai.Client(api_key=self.api_key)
        response = client.models.generate_content(
            model=IMAGE_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                response_modalities=["IMAGE"],
                image_config=types.ImageConfig(aspect_ratio=aspect_ratio),
            ),
        )

        for part in response.candidates[0].content.parts:
            if part.inline_data is not None:
                return part.inline_data.data  # already raw bytes

        raise RuntimeError("Gemini returned no image data - the prompt may have been blocked by safety filters.")

    def generate_image_base64(self, prompt: str, aspect_ratio: str = "1:1") -> str:
        """Convenience wrapper - returns a base64 string instead of raw bytes,
        easier to pass around inside AgentResult.data dicts."""
        image_bytes = self.generate_image(prompt, aspect_ratio)
        return base64.b64encode(image_bytes).decode("ascii")


def build_gemini_image_client(config) -> Optional[GeminiImageClient]:
    """
    Deliberately reuses config.GEMINI_API_KEY (the SAME key used for the AI
    brain) rather than a separate env var - if you already picked Gemini as
    your free brain, image generation comes along for free with zero extra setup.
    """
    if not getattr(config, "GEMINI_API_KEY", None):
        logger.info("GEMINI_API_KEY not set - product image generation disabled (no separate signup needed if you add it).")
        return None
    return GeminiImageClient(config.GEMINI_API_KEY)
