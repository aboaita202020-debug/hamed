"""
WhatsApp channel via Twilio. Optional - if TWILIO_* env vars are not set,
`build_whatsapp_channel` returns None and the caller should simply skip
starting this channel (checked in bot.py-style startup code).
"""
import logging

logger = logging.getLogger("hamed.channels.whatsapp")


class WhatsAppChannel:
    def __init__(self, account_sid: str, auth_token: str, from_number: str, orchestrator,
                 decision_engine=None, self_reflection=None):
        from twilio.rest import Client  # imported lazily - only needed if Twilio is configured
        self.client = Client(account_sid, auth_token)
        self.from_number = from_number
        self.orchestrator = orchestrator
        # Optional - when wired, WhatsApp gets the same "think, act, observe"
        # reasoning as Telegram/Voice instead of one fixed action.
        self.decision_engine = decision_engine
        self.self_reflection = self_reflection

    def send_message(self, to_number: str, body: str):
        return self.client.messages.create(
            from_=f"whatsapp:{self.from_number}",
            to=f"whatsapp:{to_number}",
            body=body,
        )

    def handle_incoming(self, from_number: str, body: str) -> str:
        """Call this from your Twilio webhook route (e.g. a FastAPI POST endpoint)."""
        if self.decision_engine is not None:
            goal = f"Respond helpfully on WhatsApp to this customer message and move the conversation forward: {body}"
            trace = self.decision_engine.run(goal, {"channel": "whatsapp", "phone": from_number}, max_steps=4)

            reply = None
            for step in reversed(trace.steps):
                if step.result and step.result.success:
                    reply = step.result.data.get("reply") or step.result.data.get("explanation")
                    if reply:
                        break
                if step.result and step.result.requires_approval:
                    reply = "الطلب ده محتاج موافقتي الأول، هراجعه وأرد عليك بسرعة."
                    break

            if self.self_reflection is not None:
                try:
                    self.self_reflection.reflect(trace)
                except Exception:  # noqa: BLE001
                    logger.exception("WhatsApp self-reflection failed - continuing anyway.")

            if reply:
                return reply
            # Decision engine found nothing usable - fall through to the fixed fallback below.

        result = self.orchestrator.run({"action": "sales.handle_objection", "message": body, "chat_id": from_number})
        if result.success:
            return result.data.get("reply") or str(result.data)
        if result.requires_approval:
            return "This needs approval before I can proceed - flagging it for review."
        return f"Sorry, something went wrong: {result.notes}"


def build_whatsapp_channel(config, orchestrator, decision_engine=None, self_reflection=None):
    if not config.has_twilio:
        logger.info("Twilio not configured - WhatsApp channel disabled.")
        return None
    return WhatsAppChannel(
        config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN, config.TWILIO_PHONE_NUMBER, orchestrator,
        decision_engine=decision_engine, self_reflection=self_reflection,
    )
