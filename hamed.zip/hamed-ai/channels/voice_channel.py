"""
Voice channel via Twilio. Handles inbound AND outbound calls with TwiML.
Optional - disabled cleanly if Twilio isn't configured.

Speech-to-text and text-to-speech are handled by Twilio itself (<Gather
input="speech"> and <Say>) - no separate STT/TTS provider needed for basic
conversation. This is turn-based (caller speaks -> pause -> Hamed replies ->
caller speaks again), not real-time overlapping speech - that would need
Twilio Media Streams + a streaming speech provider, a meaningfully bigger
project than a phone call feature justifies at this stage.
"""
import logging
from typing import Optional

logger = logging.getLogger("hamed.channels.voice")

MAX_TURNS_PER_CALL = 8  # safety cap so a stuck loop can't run forever on Twilio's dime


class VoiceChannel:
    def __init__(self, account_sid: str, auth_token: str, from_number: str, orchestrator,
                 decision_engine=None, self_reflection=None):
        from twilio.rest import Client
        self.client = Client(account_sid, auth_token)
        self.from_number = from_number
        self.orchestrator = orchestrator
        # Optional - when wired, voice calls get the same "think, act, observe"
        # reasoning as Telegram/WhatsApp instead of one fixed action.
        self.decision_engine = decision_engine
        self.self_reflection = self_reflection

    def place_call(self, to_number: str, twiml_webhook_url: str):
        """
        `twiml_webhook_url` must be a full public URL (e.g.
        https://your-app.onrender.com/voice/incoming) - Twilio calls this URL
        the moment the person picks up, so it can't be a relative path here
        (unlike the in-call <Gather action="..."> which Twilio resolves
        relative to the current request automatically).
        """
        return self.client.calls.create(to=to_number, from_=self.from_number, url=twiml_webhook_url)

    def initial_twiml(self, greeting: str = "أهلاً، أنا حامد، إزاي أقدر أساعدك؟") -> str:
        """Returns TwiML to greet the caller and gather speech input."""
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" language="ar-EG" action="/voice/handle_speech" method="POST" speechTimeout="auto">
    <Say language="ar-EG">{greeting}</Say>
  </Gather>
  <Say language="ar-EG">معلش، مسمعتش حاجة. اتصل تاني لما تكون جاهز.</Say>
</Response>"""

    def handle_speech_result(self, speech_text: str, turn_count: int = 0) -> str:
        """Call this from your /voice/handle_speech webhook with the transcribed text."""
        if not speech_text.strip():
            return self._reprompt("معلش مسمعتش، ممكن تعيد تاني؟", turn_count)

        if turn_count >= MAX_TURNS_PER_CALL:
            return """<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say language="ar-EG">شكرًا على مكالمتك، هتواصل معاك تليجرام أو واتساب بالتفاصيل. مع السلامة.</Say>
  <Hangup/>
</Response>"""

        reply_text = self._get_reply(speech_text)
        return self._reprompt(reply_text, turn_count)

    def _get_reply(self, speech_text: str) -> str:
        if self.decision_engine is not None:
            goal = f"Respond helpfully on a phone call to what the caller just said: {speech_text}"
            trace = self.decision_engine.run(goal, {"channel": "voice"}, max_steps=3)
            for step in reversed(trace.steps):
                if step.result and step.result.success:
                    reply = step.result.data.get("reply") or step.result.data.get("explanation")
                    if reply:
                        if self.self_reflection is not None:
                            try:
                                self.self_reflection.reflect(trace)
                            except Exception:  # noqa: BLE001
                                logger.exception("Voice call self-reflection failed - continuing anyway.")
                        return reply
                if step.result and step.result.requires_approval:
                    return "الطلب ده محتاج موافقة مني الأول، هبعتلك تفاصيله على تليجرام."
            return "معلش، ممكن تقولها بطريقة تانية؟"

        # Fallback when no decision engine is wired - fixed action, kept for
        # standalone testing/backward compatibility.
        result = self.orchestrator.run({"action": "sales.handle_objection", "message": speech_text})
        return result.data.get("reply") if result.success else "معلش، ممكن تعيد تاني؟"

    @staticmethod
    def _reprompt(text: str, turn_count: int) -> str:
        next_action = f"/voice/handle_speech?turn={turn_count + 1}"
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" language="ar-EG" action="{next_action}" method="POST" speechTimeout="auto">
    <Say language="ar-EG">{text}</Say>
  </Gather>
  <Say language="ar-EG">معلش، هقفل المكالمة دلوقتي. اتصل تاني لو حابب تكمل.</Say>
</Response>"""


def build_voice_channel(config, orchestrator, decision_engine=None, self_reflection=None):
    if not config.has_twilio:
        logger.info("Twilio not configured - Voice channel disabled.")
        return None
    return VoiceChannel(
        config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN, config.TWILIO_PHONE_NUMBER, orchestrator,
        decision_engine=decision_engine, self_reflection=self_reflection,
    )
