"""
Hamed AI - main entry point.

Run with: python bot.py
Starts the Telegram bot (blocking polling loop) and, in a background thread,
the FastAPI dashboard/health server.
"""
import logging
import sys
import threading

from config import config
from brains.multi_brain import build_default_multi_brain
from agents.registry import build_agents
from orchestrator import HamedOrchestrator
from approvals.approval_layer import ApprovalLayer
from database.db import build_store
from server.dashboard import build_app
from learning.learning_council import LearningCouncil
from research_team.client_research_team import ClientResearchTeam
from management.board import HamedBoard
from management.revenue_engine import RevenueEngine
from management.experiment_engine import ExperimentEngine
from management.venture_studio import VentureStudio
from management.decision_engine import AutonomousDecisionEngine
from management.self_reflection import SelfReflection
from management.outreach_queue import OutreachQueue
from management.hunting_pipeline import ColdOutreachHunter
from management.strategy_params import StrategyParams
from management.self_improvement_engine import SelfImprovementEngine
from management.proactive_scanner import ProactiveScanner
from channels.whatsapp_channel import build_whatsapp_channel
from channels.voice_channel import build_voice_channel
from integrations.google_sheets_client import build_sheets_client
from integrations.heygen_client import build_heygen_client
from management.sheets_sync import SheetsSync

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(levelname)s %(message)s")
logger = logging.getLogger("hamed.bot")


def build_hamed():
    """Wires all components together. Reused by tests and by main()."""
    multi_brain = build_default_multi_brain(config)
    store = build_store(config)
    strategy_params = StrategyParams(store)
    heygen_client = build_heygen_client(config)
    agents = build_agents(multi_brain, config=config, store=store, strategy_params=strategy_params, heygen_client=heygen_client)
    approval_layer = ApprovalLayer()
    orchestrator = HamedOrchestrator(agents, approval_layer)

    # Log every completed task so the Learning Council can mine it for
    # "what worked / what didn't".
    def log_result(task, result):
        store.insert("agent_results", {"task": task, "result": result.__dict__})

    orchestrator.on_task_complete(log_result)

    learning_council = LearningCouncil(store)
    self_improvement_engine = SelfImprovementEngine(learning_council, strategy_params, store=store)

    # REAL-TIME self-improvement: run a tuning cycle after every single
    # completed task, not on a daily schedule. The engine itself only reads
    # already-in-memory/SQLite records (no network calls), so this stays
    # fast even at real-world small-business volume. If this project ever
    # handles thousands of tasks per minute, swap this for a periodic cron
    # call to self_improvement_engine.run_cycle() instead - but for a
    # business just getting started, "smarter after every interaction" is
    # both correct and cheap.
    def auto_improve(task, result):
        try:
            self_improvement_engine.run_cycle()
        except Exception:  # noqa: BLE001
            logger.exception("Self-improvement cycle failed - continuing without blocking the reply.")

    orchestrator.on_task_complete(auto_improve)

    client_research_team = ClientResearchTeam(orchestrator)
    board = HamedBoard(orchestrator)
    revenue_engine = RevenueEngine(store, daily_goal=1000.0, currency=config.DEFAULT_CURRENCY)
    experiment_engine = ExperimentEngine(store)
    venture_studio = VentureStudio(store, default_daily_goal=100.0, currency=config.DEFAULT_CURRENCY)
    decision_engine = AutonomousDecisionEngine(orchestrator, multi_brain, store=store)
    self_reflection = SelfReflection(multi_brain, store=store)
    outreach_queue = OutreachQueue()
    cold_outreach_hunter = ColdOutreachHunter(orchestrator, multi_brain, outreach_queue)
    proactive_scanner = ProactiveScanner(
        orchestrator, cold_outreach_hunter, revenue_engine, experiment_engine, outreach_queue,
    )

    # Optional channels - None if not configured, callers must check before use.
    whatsapp_channel = build_whatsapp_channel(config, orchestrator, decision_engine=decision_engine, self_reflection=self_reflection)
    voice_channel = build_voice_channel(config, orchestrator, decision_engine=decision_engine, self_reflection=self_reflection)
    sheets_client = build_sheets_client(config)
    sheets_sync = SheetsSync(store, sheets_client)

    return {
        "multi_brain": multi_brain,
        "orchestrator": orchestrator,
        "approval_layer": approval_layer,
        "store": store,
        "learning_council": learning_council,
        "self_improvement_engine": self_improvement_engine,
        "strategy_params": strategy_params,
        "client_research_team": client_research_team,
        "board": board,
        "revenue_engine": revenue_engine,
        "experiment_engine": experiment_engine,
        "venture_studio": venture_studio,
        "decision_engine": decision_engine,
        "self_reflection": self_reflection,
        "outreach_queue": outreach_queue,
        "cold_outreach_hunter": cold_outreach_hunter,
        "proactive_scanner": proactive_scanner,
        "whatsapp_channel": whatsapp_channel,
        "voice_channel": voice_channel,
        "sheets_client": sheets_client,
        "heygen_client": heygen_client,
        "sheets_sync": sheets_sync,
    }


def run_dashboard(orchestrator, approval_layer, revenue_engine=None, store=None,
                   whatsapp_channel=None, voice_channel=None):
    import uvicorn
    app = build_app(config, orchestrator, approval_layer, revenue_engine, store,
                     whatsapp_channel, voice_channel)
    uvicorn.run(app, host=config.DASHBOARD_HOST, port=config.DASHBOARD_PORT, log_level="warning")


def run_telegram_bot(orchestrator, decision_engine, self_reflection, outreach_queue, cold_outreach_hunter,
                      whatsapp_channel=None, sheets_sync=None, self_improvement_engine=None,
                      proactive_scanner=None, voice_channel=None):
    import telebot
    import threading
    import time

    bot = telebot.TeleBot(config.TELEGRAM_BOT_TOKEN)
    current_offer = {"description": ""}  # set via /setoffer, used as context when hunting

    def _is_admin(message) -> bool:
        if not config.has_admin_chat:
            return False
        return str(message.chat.id) == str(config.ADMIN_TELEGRAM_CHAT_ID)

    def _run_scan_and_notify():
        if proactive_scanner is None:
            return
        report = proactive_scanner.scan(
            offer_context={"description": current_offer["description"]},
            platform_tokens=config.configured_platform_tokens(),
        )
        if config.has_admin_chat:
            bot.send_message(config.ADMIN_TELEGRAM_CHAT_ID, proactive_scanner.format_summary(report))
            for item in outreach_queue.list_pending():
                bot.send_message(config.ADMIN_TELEGRAM_CHAT_ID, outreach_queue.format_admin_notification(item))

    def _background_scan_loop():
        interval_seconds = max(config.PROACTIVE_SCAN_INTERVAL_MINUTES, 1) * 60
        while True:
            time.sleep(interval_seconds)
            try:
                _run_scan_and_notify()
            except Exception:  # noqa: BLE001
                logger.exception("Proactive scan cycle failed - will retry next interval.")

    if proactive_scanner is not None:
        threading.Thread(target=_background_scan_loop, daemon=True).start()
        logger.info(
            "Proactive Scanner running automatically every %s minutes.",
            config.PROACTIVE_SCAN_INTERVAL_MINUTES,
        )

    @bot.message_handler(commands=["whatsapp"])
    def whatsapp_send_command(message):
        if not _is_admin(message):
            return
        if whatsapp_channel is None:
            bot.reply_to(message, "WhatsApp channel مش متظبط (محتاج Twilio).")
            return
        parts = message.text.split(maxsplit=2)
        if len(parts) < 3:
            bot.reply_to(message, "استخدم: /whatsapp <رقم بالكود الدولي زي +201xxxxxxxxx> <نص الرسالة>")
            return
        to_number, text = parts[1], parts[2]
        try:
            whatsapp_channel.send_message(to_number, text)
            bot.reply_to(message, f"تمام، اتبعتت لـ {to_number} على واتساب.")
        except Exception as e:  # noqa: BLE001
            bot.reply_to(message, f"فشل الإرسال: {e}")

    @bot.message_handler(commands=["call"])
    def call_command(message):
        if not _is_admin(message):
            return
        if voice_channel is None:
            bot.reply_to(message, "Voice channel مش متظبط (محتاج Twilio).")
            return
        parts = message.text.split()
        if len(parts) != 2:
            bot.reply_to(message, "استخدم: /call <رقم الموبايل بالكود الدولي زي +201xxxxxxxxx>")
            return
        if not config.PUBLIC_BASE_URL:
            bot.reply_to(
                message,
                "لازم تحطي PUBLIC_BASE_URL في الإعدادات الأول (رابط السيرفر بتاعك على Render مثلًا) "
                "عشان Twilio يعرف يرجع لحامد وقت المكالمة.",
            )
            return
        to_number = parts[1]
        try:
            voice_channel.place_call(to_number, f"{config.PUBLIC_BASE_URL}/voice/incoming")
            bot.reply_to(message, f"تمام، بتصل بـ {to_number} دلوقتي.")
        except Exception as e:  # noqa: BLE001
            bot.reply_to(message, f"فشلت المكالمة: {e}")

    @bot.message_handler(commands=["scan"])
    def scan_command(message):
        if not _is_admin(message):
            return
        if proactive_scanner is None:
            bot.reply_to(message, "Proactive Scanner مش متظبط.")
            return
        bot.reply_to(message, "بادور دلوقتي على كل حاجة... ثانية.")
        _run_scan_and_notify()

    @bot.message_handler(commands=["setoffer"])
    def set_offer(message):
        if not _is_admin(message):
            return
        text = message.text.partition(" ")[2].strip()
        if not text:
            bot.reply_to(message, "استخدم: /setoffer <وصف قصير للي بتقدمه> - ده اللي حامد هيستخدمه في رسايل القنص.")
            return
        current_offer["description"] = text
        bot.reply_to(message, "تمام، اتسجل. دلوقتي استخدم /hunt <platform> <access_token>.")

    @bot.message_handler(commands=["hunt"])
    def hunt_command(message):
        if not _is_admin(message):
            return
        parts = message.text.split(maxsplit=2)
        if len(parts) < 3:
            bot.reply_to(
                message,
                "استخدم: /hunt <facebook|instagram|tiktok|linkedin|twitter> <access_token>\n"
                "لازم الـ access_token يكون من OAuth رسمي للحساب - مفيش سكرابينج ولا باسوردات.",
            )
            return
        platform, access_token = parts[1], parts[2]
        queued = cold_outreach_hunter.hunt(platform, access_token, {"description": current_offer["description"]})

        if not queued:
            bot.reply_to(message, f"مفيش مرشحين اتلقوا على {platform} دلوقتي (أو الـ access_token مش شغال).")
            return

        bot.reply_to(message, f"لقيت {len(queued)} فرصة على {platform}. هبعتهملك واحدة واحدة للموافقة:")
        for item in queued:
            bot.send_message(message.chat.id, outreach_queue.format_admin_notification(item))

    @bot.message_handler(commands=["improve"])
    def improve_command(message):
        if not _is_admin(message):
            return
        if self_improvement_engine is None:
            bot.reply_to(message, "Self-Improvement Engine مش متظبط.")
            return
        summary = self_improvement_engine.run_cycle()
        if not summary["changes_made"]:
            bot.reply_to(
                message,
                f"شغّلت دورة تحسين. {summary['analysis_summary']}\n"
                f"مفيش تغييرات دلوقتي - إما مفيش بيانات كفاية أو الأداء مستقر.",
            )
        else:
            changes_text = "\n".join(f"- {c}" for c in summary["changes_made"])
            bot.reply_to(message, f"شغّلت دورة تحسين. التغييرات:\n{changes_text}")

    @bot.message_handler(commands=["sync_sheets"])
    def sync_sheets_command(message):
        if not _is_admin(message):
            return
        if sheets_sync is None or sheets_sync.sheets_client is None:
            bot.reply_to(
                message,
                "Google Sheets مش متظبط. حط GOOGLE_SHEETS_CREDENTIALS_JSON و GOOGLE_SHEET_ID في الإعدادات الأول.",
            )
            return
        try:
            results = sheets_sync.sync_all()
            lines = [f"- {table}: {count if count >= 0 else 'فشل'}" for table, count in results.items()]
            bot.reply_to(message, "تمام، اتزامن:\n" + "\n".join(lines))
        except Exception as e:  # noqa: BLE001
            bot.reply_to(message, f"حصل خطأ في المزامنة: {e}")

    @bot.message_handler(commands=["pending"])
    def list_pending(message):
        if not _is_admin(message):
            return
        items = outreach_queue.list_pending()
        if not items:
            bot.reply_to(message, "مفيش فرص Cold Outreach مستنية موافقة دلوقتي.")
            return
        for item in items:
            bot.send_message(message.chat.id, outreach_queue.format_admin_notification(item))

    @bot.message_handler(commands=["approve"])
    def approve_outreach(message):
        if not _is_admin(message):
            return
        parts = message.text.split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "استخدم: /approve <رقم الفرصة>")
            return
        item = outreach_queue.approve(int(parts[1]))
        if not item:
            bot.reply_to(message, "مفيش فرصة بالرقم ده أو اتراجعت قبل كده.")
            return

        # Only WhatsApp has a real send path wired (via Twilio). Other platforms
        # (Facebook/Instagram/TikTok/etc.) need each platform's own approved
        # Business API token before Hamed can send for real - until then, the
        # approved message is handed back to you to send manually.
        if item.platform == "whatsapp" and whatsapp_channel is not None:
            phone = item.candidate.get("phone")
            if phone:
                whatsapp_channel.send_message(phone, item.draft_message)
                outreach_queue.mark_sent(item.id)
                bot.reply_to(message, f"✅ اتبعتت #{item.id} على واتساب.")
                return

        outreach_queue.mark_sent(item.id)
        bot.reply_to(
            message,
            f"✅ اتوافق عليها #{item.id}. لسه معنديش صلاحية إرسال مباشر على {item.platform} "
            f"(محتاج Business API Token معتمد للمنصة دي). ابعتها انت يدويًا:\n\n{item.draft_message}",
        )

    @bot.message_handler(commands=["reject"])
    def reject_outreach(message):
        if not _is_admin(message):
            return
        parts = message.text.split()
        if len(parts) != 2 or not parts[1].isdigit():
            bot.reply_to(message, "استخدم: /reject <رقم الفرصة>")
            return
        item = outreach_queue.reject(int(parts[1]))
        bot.reply_to(message, f"❌ اترفضت #{item.id}." if item else "مفيش فرصة بالرقم ده.")

    @bot.message_handler(func=lambda m: True)
    def handle_message(message):
        goal = f"Respond helpfully to this customer message and move the conversation forward: {message.text}"
        context = {"chat_id": message.chat.id, "raw_message": message.text}

        trace = decision_engine.run(goal, context, max_steps=4)

        reply = None
        for step in reversed(trace.steps):
            if step.result and step.result.success:
                reply = step.result.data.get("reply") or step.result.data.get("explanation") \
                    or step.result.data.get("analysis") or str(step.result.data)
                break
            if step.result and step.result.requires_approval:
                reply = "الطلب ده محتاج موافقتك لأنه يتخطى الحد المسموح تلقائيًا. (approval_id: {})".format(
                    step.result.data.get("approval_id")
                )
                break

        if reply is None:
            # Decision engine couldn't find/execute a useful action - fall back to
            # a direct, simple response instead of leaving the user without a reply.
            fallback = orchestrator.run({
                "action": "sales.handle_objection", "message": message.text, "chat_id": message.chat.id,
            })
            reply = fallback.data.get("reply") if fallback.success else "معلش، مش قادر أساعد في الطلب ده دلوقتي."

        bot.reply_to(message, reply)

        # Self-reflection runs in the background of the conversation - it doesn't
        # block the reply, just logs a lesson for the Learning Council.
        try:
            self_reflection.reflect(trace)
        except Exception:  # noqa: BLE001
            logger.exception("Self-reflection failed for this message - continuing anyway.")

    logger.info("Telegram bot polling started.")
    bot.infinity_polling()


def main():
    if not config.validate():
        sys.exit(1)

    hamed = build_hamed()
    orchestrator = hamed["orchestrator"]
    approval_layer = hamed["approval_layer"]
    revenue_engine = hamed["revenue_engine"]
    decision_engine = hamed["decision_engine"]
    self_reflection = hamed["self_reflection"]

    dashboard_thread = threading.Thread(
        target=run_dashboard,
        args=(orchestrator, approval_layer, revenue_engine, hamed["store"],
              hamed["whatsapp_channel"], hamed["voice_channel"]),
        daemon=True,
    )
    dashboard_thread.start()
    logger.info(
        "Dashboard: http://%s:%s/dashboard  Health: http://%s:%s/health",
        config.DASHBOARD_HOST, config.DASHBOARD_PORT,
        config.DASHBOARD_HOST, config.DASHBOARD_PORT,
    )
    logger.info("WhatsApp channel: %s", "enabled" if hamed["whatsapp_channel"] else "disabled (no Twilio config)")
    logger.info("Voice channel: %s", "enabled" if hamed["voice_channel"] else "disabled (no Twilio config)")
    logger.info("Capabilities available: %s", len(orchestrator.available_capabilities()))

    run_telegram_bot(
        orchestrator, decision_engine, self_reflection,
        hamed["outreach_queue"], hamed["cold_outreach_hunter"], hamed["whatsapp_channel"],
        hamed["sheets_sync"], hamed["self_improvement_engine"], hamed["proactive_scanner"],
        hamed["voice_channel"],
    )


if __name__ == "__main__":
    main()
